<?php
  //--------------------------------------------------------------------------------//
  //                                                                                //
  // Wirecard Checkout Toolkit light                                                //
  //                                                                                //
  // Copyright (c) 2013                                                             //
  // Wirecard Central Eastern Europe GmbH                                           //
  // www.wirecard.at                                                                //
  //                                                                                //
  // THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
  // KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
  // IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
  // PARTICULAR PURPOSE.                                                            //
  //                                                                                //
  //--------------------------------------------------------------------------------//
  // THIS EXAMPLE IS FOR DEMONSTRATION PURPOSES ONLY!                               //
  //--------------------------------------------------------------------------------//
  // Please read the integration documentation before modifying this file.          //
  //--------------------------------------------------------------------------------//

  // loads the merchant specific parameters from the config file
	require_once("config.inc.php");

  // loads the required PHP functions
  require_once("functions.inc.php");

  // the command to execute received from the form
  $command = $_POST["command"];

  // the order number received from the form
  $orderNumber = isset($_POST["orderNumber"]) ? $_POST["orderNumber"] : "";

  // the source order number received from the form
  $sourceOrderNumber = isset($_POST["sourceOrderNumber"]) ? $_POST["sourceOrderNumber"] : "";

  // the payment number received from the form
  $paymentNumber = isset($_POST["paymentNumber"]) ? $_POST["paymentNumber"] : "";

  // the credit number received from the form
  $creditNumber = isset($_POST["creditNumber"]) ? $_POST["creditNumber"] : "";

  // the order description received from the form
  $orderDescription = isset($_POST["orderDescription"]) ? $_POST["orderDescription"] : "";

  // the amount received from the form
  $amount = isset($_POST["amount"]) ? $_POST["amount"] : "";

  // the curency of the amount received from the form
  $currency = isset($_POST["currency"]) ? $_POST["currency"] : "";

  // the fund transfer type
  $customerStatement  = isset($_POST["customerStatement"]) ? $_POST["customerStatement"] : "";

  // the fund transfer type
  $fundTransferType  = isset($_POST["fundTransferType"]) ? $_POST["fundTransferType"] : "";

  // the email-address of the consumer
  $consumerEmail = isset($_POST["consumerEmail"]) ? $_POST["consumerEmail"] : "";

	// computes the fingerprint based on the request parameters and depending on the command
  $requestFingerprint = "";
  if ($command == "approveReversal") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber);
  }
  if ($command == "deposit") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber,
                                             $amount, $currency);
  }
  if ($command == "depositReversal") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber,
                                             $paymentNumber);
  }
  if ($command == "getOrderDetails") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber);
  }
  if ($command == "recurPayment") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber,
                                             $sourceOrderNumber, $orderDescription,
                                             $amount, $currency);
  }
  if ($command == "refund") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber,
                                             $amount, $currency);
  }
  if ($command == "refundReversal") {
    $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                             $secret, $command,
                                             $language, $orderNumber,
                                             $creditNumber);
  }
  if ($command == "transferFund") {
    if ($fundTransferType == "SKRILLWALLET") {
    //  customerId, (shopId), toolkitPassword, secret, command, language, (orderNumber),
    // (creditNumber), orderDescription, amount, currency, (orderReference), customerStatement, fundTransferType and consumerEmail
      $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                               $secret, $command,
                                               $language,
                                               $orderDescription,
                                               $amount, $currency,
                                               $customerStatement,
                                               $fundTransferType,
                                               $consumerEmail);
    }
    if ($fundTransferType == "EXISTINGORDER") {
      $requestFingerprint = computeFingerprint($customerId, $toolkitPassword,
                                               $secret, $command,
                                               $language, 
                                               $orderDescription,
                                               $amount, $currency,
                                               $customerStatement,
                                               $fundTransferType,
                                               $sourceOrderNumber);
    }
  }

  // sets all request parameters as assoziative array
  // which are required for all commands
  $request = array(
               "customerId" => $customerId,
               "toolkitPassword" => $toolkitPassword,
               "command" => $command,
               "language" => $language,
               "requestFingerprint" => $requestFingerprint
             );

  // sets all request parameters which are depending on the selected command
  if ($orderNumber != "") $request = array_merge($request, array("orderNumber" => $orderNumber));
  if ($sourceOrderNumber != "") $request = array_merge($request, array("sourceOrderNumber" => $sourceOrderNumber));
  if ($paymentNumber != "") $request = array_merge($request, array("paymentNumber" => $paymentNumber));
  if ($creditNumber != "") $request = array_merge($request, array("creditNumber" => $creditNumber));
  if ($orderDescription != "") $request = array_merge($request, array("orderDescription" => $orderDescription));
  if ($amount != "") $request = array_merge($request, array("amount" => $amount));
  if ($currency != "") $request = array_merge($request, array("currency" => $currency));
  if ($customerStatement != "") $request = array_merge($request, array("customerStatement" => $customerStatement));
  if ($fundTransferType != "") $request = array_merge($request, array("fundTransferType" => $fundTransferType));
  if ($consumerEmail != "") $request = array_merge($request, array("consumerEmail" => $consumerEmail));

  $response = serverToServerRequest($URL_WIRECARD_CHECKOUT_TOOLKIT_LIGHT, $request);
?>
<html>
  <head>
    <title>Wirecard Checkout Toolkit light</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
  </head>
  <body>
    <h1>Wirecard Checkout Toolkit light</h1>
    <p>This is a very simple example of the Wirecard Checkout Toolkit light for demonstration purposes only.</p>
   <?php
      printRequestParameters($request);
      printResponseParameters($response);
    ?>
    <p><center><a href="index.php">Back to list of available commands</a></center></p>
  </body>
</html>
