<?php
//--------------------------------------------------------------------------------//
//                                                                                //
// Wirecard Checkout Seamless Example                                             //
//                                                                                //
// Copyright (c)                                                                  //
// Wirecard Central Eastern Europe GmbH                                           //
// www.wirecard.at                                                                //
//                                                                                //
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
// PARTICULAR PURPOSE.                                                            //
//                                                                                //
//--------------------------------------------------------------------------------//
// THIS EXAMPLE IS FOR DEMONSTRATION PURPOSES ONLY!                               //
//--------------------------------------------------------------------------------//
// Please read the integration documentation before modifying this file.          //
//--------------------------------------------------------------------------------//

// loads the merchant specific parameters from the config file
require_once("../config.inc.php");

session_start();
$_SESSION["amount"] = 30;
$_SESSION["currency"] = "EUR";

?>
<html>
<head>
    <title>Wirecard Checkout Seamless Example</title>
    <link rel="stylesheet" type="text/css" href="../styles.css">
</head>
<body>
<form name="form" action="init.php" method="post">
    <table border="1" bordercolor="lightgray" cellpadding="10" cellspacing="0">
        <tr>
            <td colspan="2"><b>Your order details for this demo payment</b></td>
        </tr>
        <tr>
            <td align="right"><b>Amount:</b></td>
            <td><?php echo $_SESSION["currency"] . " " . $_SESSION["amount"]; ?></td>
        </tr>
        <tr>
            <td align="right"><b>Order ident:</b></td>
            <td><?php echo $_SESSION["orderIdent"]; ?></td>
        </tr>
        <tr>
            <td align="right"><b>Payment type:</b></td>
            <td>
                <select name="paymentType">
                    <option value="BANCONTACT_MISTERCASH">Bancontact/MisterCash</option>
                    <option value="CCARD" selected>Credit Card</option>
                    <option value="EKONTO">eKonto</option>
                    <option value="SEPA-DD">SEPA Direct Debit</option>
                    <option value="EPS">eps Online Bank Transfer</option>
                    <option value="GIROPAY">giropay</option>
                    <option value="IDL">iDEAL</option>
                    <option value="INSTALLMENT">Installment</option>
                    <option value="INVOICE">Invoice</option>
                    <option value="MAESTRO">Maestro SecureCode</option>
                    <option value="MONETA">Moneta.ru</option>
                    <option value="MPASS">mpass</option>
                    <option value="PRZELEWY24">Przelewy24</option>
                    <option value="PAYPAL">PayPal</option>
                    <option value="PBX">Paybox</option>
                    <option value="POLI">POLi</option>
                    <option value="PSC">Paysafecard</option>
                    <option value="QUICK">Quick</option>
                    <option value="SKRILLDIRECT">Skrill Direct</option>
                    <option value="SKRILLWALLET">Skrill Digital Wallet</option>
                    <option value="SOFORTUEBERWEISUNG">sofortueberweisung</option>
                    <option value="TRUSTLY">Trustly</option>
                    <option value="VOUCHER">Voucher</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="right"><input type="submit" value="Checkout"/></td>
        </tr>
    </table>
</form>
</body>
</html>
