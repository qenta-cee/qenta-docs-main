<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head><script type="text/javascript">
        function setResponse(response) {
            if (typeof parent.WirecardCEE_Fallback_Request_Object == 'object') {
                parent.WirecardCEE_Fallback_Request_Object.setResponseText(response);
            }
            else {
                console.log('Not a valid fallback call.');
            }
        }
    </script></head><body onload="setResponse(&quot;&lt;?php echo addslashes($response); ?>&quot;);"/></html>