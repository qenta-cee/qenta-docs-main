<?php

defined ('_JEXEC') or die();

?>

    <div style="margin-left: 20px; width: 100%;">

        <?php
        foreach ($viewData['paymenttypes'] as $pt)
        {
        ?>
        <div style="width: 200px;">
        <input class="wirecard_paymenttype" id="wirecard_<?php echo strtolower($pt['value']) ?>" type="radio" name="wirecard_paymenttype"
               value="<?php echo strtolower($pt['value']) ?>" <?php if ($viewData['paymenttype_selected'] == strtolower($pt['value'])) echo ' checked="checked"' ?> />
        <label for="wirecard_<?php echo strtolower($pt['value'])?>">
            <?php echo $pt['title'] ?>
        </label>
        </div>
        <?php } ?>

    </div>

<script type="text/javascript">
    jQuery('.wirecard_paymenttype').each(function() {
        jQuery(this).change(function(evt) {
            jQuery('#payment_id_<?php echo $viewData['paymentmethod_id'] ?>').prop('checked', true);
        });
    });
</script>

