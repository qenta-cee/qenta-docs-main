<?php
namespace GuzzleHttp\Exception;

interface GuzzleException {}
