# ClientLibrary

[![License](https://img.shields.io/badge/license-GPLv2-blue.svg)](https://raw.githubusercontent.com/wirecard/ClientLibrary/master/LICENSE)
[![PHP v5.5](https://img.shields.io/badge/php-v5.5-yellow.svg)](http://www.php.net)
[![PHP v5.6](https://img.shields.io/badge/php-v5.6-yellow.svg)](http://www.php.net)
[![PHP v7.0](https://img.shields.io/badge/php-v7.0-yellow.svg)](http://www.php.net)
[![PHP v7.1](https://img.shields.io/badge/php-v7.1-yellow.svg)](http://www.php.net)

Client library used by Wirecard Checkout Page and Seamless plugins for payment processing.

