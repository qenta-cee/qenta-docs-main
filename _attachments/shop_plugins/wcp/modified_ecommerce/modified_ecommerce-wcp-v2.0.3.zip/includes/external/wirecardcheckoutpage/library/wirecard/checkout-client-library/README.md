# ClientLibrary

[![License](https://img.shields.io/badge/license-GPLv2-blue.svg)](https://raw.githubusercontent.com/wirecard/ClientLibrary/master/LICENSE)
[![PHP v5.3](https://img.shields.io/badge/php-v5.5-yellow.svg)](http://www.php.net)

Client library used by Wirecard Checkout Page and Seamless plugins for payment processing.

