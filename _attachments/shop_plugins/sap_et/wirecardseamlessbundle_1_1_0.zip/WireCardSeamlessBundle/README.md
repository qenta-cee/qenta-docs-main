# README #

Wirecard payment gateway for the SAP Event Ticketing (SAPET) system.

### What is this repository for? ###

* Quick summary  
This repository provides the sources of the Wirecard payment gateway for the SAPET system as a Symfony bundle.
* Version
* [Wiki documentation](https://bitbucket.org/clicht/sapetwirecardbundle/wiki)

### How do I get set up? ###

* Summary of set up  
      The WireCardSeamlessBundle directory must be zipped, uploaded and configured in the SAPET system.
* Configuration  
      The payment gateway itself can be configured using the extension manager.  
      The parameters of each provided service can be configured via 'Elektron. Zahlungsmethode'
* Dependencies
* Database configuration
* How to run tests  
      In order to test the integration of Wirecard Checkout Page (or Wirecard Checkout Seamless) in a shop Wirecard offers a demo mode with payment method specific demo data to check if an integration fulfills the requirements of the Wirecard Checkout interfaces.  
      During demo mode there will be no communication to the financial providers, the checkout process is only simulated and no money is transferred. Additionally, the executed payments are not displayed in the Wirecard Payment Center.
* Implementation steps
   1. Implement the empty method-stubs of the generated provider classes (*Provider.php)
   2. Delete SAP-folder to avoid conflicts with Event Ticketing core system.
* Deployment instructions  
   1. pack all sources (root-folder should be *Bundle) into a ZIP-archive  
   2. Upload the archive to the Event Ticketing via the Extension manager import functionality.  
   3. Configure the gateway via Stammdaten->Firma->Zahlungskonfiguration->Elektron. Zahlungsmethode  
   4. Add the payment method via Stammdaten->Firma->Zahlungskonfiguration->Zusätzliche Zahlungswege  

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin  
Christoph Lichtmannegger
* Other community or team contact  
schwaar GmbH