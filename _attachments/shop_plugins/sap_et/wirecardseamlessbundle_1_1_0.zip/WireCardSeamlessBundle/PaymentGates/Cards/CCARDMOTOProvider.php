<?php

namespace WireCardSeamlessBundle\PaymentGates\Cards;


use WireCardSeamlessBundle\PaymentGates\Cards\CCARDProvider;

class CCARDMOTOProvider extends CCARDProvider{

	static protected $paymentType = "CCARD-MOTO";
}