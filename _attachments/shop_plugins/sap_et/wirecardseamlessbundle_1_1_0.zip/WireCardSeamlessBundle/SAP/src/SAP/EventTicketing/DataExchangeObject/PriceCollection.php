<?php
namespace SAP\EventTicketing\DataExchangeObject;

use SAP\EventTicketing\DataExchangeObject\AbstractCollection;

/**
 * Collection object for Price objects
 * @webserializable
 */
class PriceCollection extends AbstractCollection
{
}
