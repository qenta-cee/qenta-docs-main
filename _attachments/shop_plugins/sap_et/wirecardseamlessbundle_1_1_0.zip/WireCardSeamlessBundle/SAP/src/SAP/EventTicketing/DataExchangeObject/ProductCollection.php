<?php
namespace SAP\EventTicketing\DataExchangeObject;

use SAP\EventTicketing\DataExchangeObject\AbstractCollection;

/**
 * Collection object for Product objects
 * @webserializable
 */
class ProductCollection extends AbstractCollection
{
}
