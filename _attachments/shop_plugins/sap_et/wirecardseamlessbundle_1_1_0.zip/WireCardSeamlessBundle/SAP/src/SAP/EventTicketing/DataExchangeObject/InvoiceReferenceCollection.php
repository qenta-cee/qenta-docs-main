<?php
namespace SAP\EventTicketing\DataExchangeObject;

use SAP\EventTicketing\DataExchangeObject\AbstractCollection;

/**
 * Collection object for InvoicePayment objects
 * @webserializable
 */
class InvoiceReferenceCollection extends AbstractCollection
{
}
