<?php
namespace SAP\EventTicketing\DataExchangeObject;

use SAP\EventTicketing\DataExchangeObject\AbstractCollection;

/**
 * Collection object for Cost objects
 * @webserializable
 */
class ChargeCollection extends AbstractCollection
{
}
