<?php
namespace SAP\EventTicketing\DataExchangeObject;

use SAP\EventTicketing\DataExchangeObject\AbstractCollection;

/**
 * Collection object for Extra objects
 * @webserializable
 */
class ExtraCollection extends AbstractCollection
{
}
