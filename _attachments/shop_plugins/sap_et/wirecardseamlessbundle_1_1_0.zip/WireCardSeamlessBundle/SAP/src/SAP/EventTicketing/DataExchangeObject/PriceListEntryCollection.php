<?php
namespace SAP\EventTicketing\DataExchangeObject;

use SAP\EventTicketing\DataExchangeObject\AbstractCollection;

/**
 * Collection object for PriceListEntry objects
 * @webserializable
 */
class PriceListEntryCollection extends AbstractCollection
{
}
