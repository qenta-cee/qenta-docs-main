<html><head><script language="JavaScript" type="text/JavaScript">
              if(confirm("Do you want to remove the Wirecard Checkout Page transactions-table from your system?") == true)
              {
                  window.location.href = "";
              }
              else
              {
                  window.location.href = "";
              }
          </script></head><body/></html>