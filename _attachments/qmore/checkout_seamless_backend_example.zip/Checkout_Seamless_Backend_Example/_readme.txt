//--------------------------------------------------------------------------------//
//                                                                                //
// Wirecard Checkout Seamless Commands                                            //
//                                                                                //
// Copyright (c) 2013                                                             //
// Wirecard Central Eastern Europe GmbH                                           //
// www.wirecard.at                                                                //
//                                                                                //
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
// PARTICULAR PURPOSE.                                                            //
//                                                                                //
//--------------------------------------------------------------------------------//
// THIS EXAMPLE IS FOR DEMONSTRATION PURPOSES ONLY!                               //
//--------------------------------------------------------------------------------//
// Please read the integration documentation before modifying this file.          //
//--------------------------------------------------------------------------------//



INSTALLING AND RUNNING THE EXAMPLE
==================================

This example shows you the usage of the Wirecard Checkout Seamless Backend and
the available commands.

You can test this example in a "demo mode" by copying all files of this folder
to your web server via ftp and then access them via your web browser.


Steps to get this example running on your web server for testing purposes
------------------------------------------------------------------------

 1) ensure that you have access via ftp or any other tool to upload the files
    to your web server
 2) ensure that an up-to-date version PHP is enabled on your web server
 3) copy this folder or at least all files in this folder to a proper folder
    on your web server
 4) navigate with your favorite web browser to that folder on your web server
    and open the file with the correspondig command name within your web browser



SECURITY RECOMMENDATION
=======================

For production mode we strongly recommend that you only use
https in your web shop and update all components of your web server regulary
whenever security updates are published from your vendors.



WHERE TO GET HELP AND ADDITIONAL INFORMATION?
=============================================

If you have any questions or troubles to get this example up and running
in your web server environment, please do not hesitate to contact
our Support Team: support@wirecard.at
