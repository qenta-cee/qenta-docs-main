<?php
/**
    Shop System Plugins - Terms of use

    This terms of use regulates warranty and liability between Wirecard
    Central Eastern Europe (subsequently referred to as WDCEE) and it's
    contractual partners (subsequently referred to as customer or customers)
    which are related to the use of plugins provided by WDCEE.

    The Plugin is provided by WDCEE free of charge for it's customers and
    must be used for the purpose of WDCEE's payment platform integration
    only. It explicitly is not part of the general contract between WDCEE
    and it's customer. The plugin has successfully been tested under
    specific circumstances which are defined as the shopsystem's standard
    configuration (vendor's delivery state). The Customer is responsible for
    testing the plugin's functionality before putting it into production
    enviroment.
    The customer uses the plugin at own risk. WDCEE does not guarantee it's
    full functionality neither does WDCEE assume liability for any
    disadvantage related to the use of this plugin. By installing the plugin
    into the shopsystem the customer agrees to the terms of use. Please do
    not use this plugin if you do not agree to the terms of use!
*/

$sMetadataVersion = '1.0';

/**
 * Module information
 */
$aModule = array(
    'id'            => 'dd_wirecard',
    'title'         => 'Wirecard Checkout Seamless',
    'description'   => 'Wirecard Checkout Seamless Payment Module for the Oxid eShop',
    'thumbnail'     => 'picture.jpg',
    'version'       => '1.2.2',
    'author'        => 'Wirecard CEE',
    'email'         => 'support@wirecard.at',
    'url'           => 'http://www.wirecard.at',
    'blocks'        => array(
        0    => array(
            'template'    => 'page/checkout/order.tpl',
            'position'    => 1,
            'block'       => 'checkout_order_main',
            'file'        => 'orderIframe',
        ),
        1    => array(
            'template'    => 'page/checkout/payment.tpl',
            'position'    => 1,
            'block'       => 'select_payment',
            'file'        => 'paymentSelector',
        )
    ),
    'extend'    => array(
        'order'            => 'dd_wirecard/views/dd_wirecard_order',
        'payment'          => 'dd_wirecard/views/dd_wirecard_payment',
        'thankyou'         => 'dd_wirecard/views/dd_wirecard_thankyou',
        'oxorder'          => 'dd_wirecard/core/dd_wirecard_oxorder',
        'oxpaymentgateway' => 'dd_wirecard/core/dd_wirecard_oxpaymentgateway',
        'oxpaymentlist'    => 'dd_wirecard/core/dd_wirecard_oxpaymentlist',
        'oxemail'          => 'dd_wirecard/core/dd_wirecard_oxemail',
    ),
    'files'    => array(
        'out/admin/de/dd_wirecard__lang.php'        => 'dd_wirecard/out/admin/de/dd_wirecard__lang.php',
        'out/admin/en/dd_wirecard__lang.php'        => 'dd_wirecard/out/admin/en/dd_wirecard__lang.php',
        'out/lang/de/dd_wirecard__lang.php'         => 'dd_wirecard/out/lang/de/dd_wirecard__lang.php',
        'out/lang/en/dd_wirecard__lang.php'         => 'dd_wirecard/out/lang/en/dd_wirecard__lang.php',
    ),

    'templates' => array(
        'wcs_settings.tpl'      => 'dd_wirecard/out/admin/tpl/wcs_settings.tpl',
        'wcs_formparams.tpl'    => 'dd_wirecard/out/admin/tpl/wcs_formparams.tpl',
        'wcs_list.tpl'          => 'dd_wirecard/out/admin/tpl/wcs_list.tpl',
        'wcs_parameters.tpl'    => 'dd_wirecard/out/admin/tpl/wcs_parameters.tpl',
        'wcs_shopsettings.tpl'  => 'dd_wirecard/out/admin/tpl/wcs_shopsettings.tpl',
        'wcs_termsofuse.tpl'    => 'dd_wirecard/out/admin/tpl/wcs_termsofuse.tpl',
	),
);