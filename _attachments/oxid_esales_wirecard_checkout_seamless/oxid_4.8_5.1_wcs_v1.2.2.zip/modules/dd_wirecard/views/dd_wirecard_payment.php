<?php
/**
    Shop System Plugins - Terms of use

    This terms of use regulates warranty and liability between Wirecard
    Central Eastern Europe (subsequently referred to as WDCEE) and it's
    contractual partners (subsequently referred to as customer or customers)
    which are related to the use of plugins provided by WDCEE.

    The Plugin is provided by WDCEE free of charge for it's customers and
    must be used for the purpose of WDCEE's payment platform integration
    only. It explicitly is not part of the general contract between WDCEE
    and it's customer. The plugin has successfully been tested under
    specific circumstances which are defined as the shopsystem's standard
    configuration (vendor's delivery state). The Customer is responsible for
    testing the plugin's functionality before putting it into production
    enviroment.
    The customer uses the plugin at own risk. WDCEE does not guarantee it's
    full functionality neither does WDCEE assume liability for any
    disadvantage related to the use of this plugin. By installing the plugin
    into the shopsystem the customer agrees to the terms of use. Please do
    not use this plugin if you do not agree to the terms of use!
*/

/**
 * payment view extended class
 * overloads render function and validation
 */
class dd_wirecard_payment extends dd_wirecard_payment_parent {
    /**
     * internal Id for Wirecard Storage
     * Should be returned by WirecardCEE_Client_DataStorage_Request_Initiation
     *
     * @var string
     */
    protected $_blUseWirecardFallback = false;

    /**
     * internal Id for Wirecard Storage
     * Should be returned by WirecardCEE_Client_DataStorage_Request_Initiation
     *
     * @var string
     */
    protected $_sWirecardStorageId = null;

    /**
     * url to wirecard JS Library for cross domain request.
     * Should be returned by WirecardCEE_Client_DataStorage_Request_Initiation
     *
     * @var string
     */
    protected $_sWirecardStorageJsUrl = null;

    /**
     * Initiated WirecardCEE_Client_DataStorage_Request_Initiation
     *
     * @var WirecardCEE_Client_DataStorage_Request_Initiation
     */
    protected $_oWirecardStorageRequest = null;

    /**
     * Last Response Object
     * Initiated WirecardCEE_Client_DataStorage_Response_Initiation
     *
     * @var WirecardCEE_Client_DataStorage_Response_Initiation
     */
    protected $_oWirecardStorageResponse = null;

    /**
     * array of Issue years
     *
     * @var array
     */
    protected $_aCreditIssueYears = null;

    /**
     * array of country elv codes
     *
     * @var array
     */
    protected $_aElvCountries = null;

    /**
     * init hook
     */
    public function init() {
        parent::init();
    }

    /**
     * Execute parent render()
     * Set View parameters
     * init WirecardDataStorage to display right forms and storage.js
     * call _unsetPaymentErrors to unset session Errors and
     *
     * @return template _sThisTemplate
     */
    public function render() {
        // parent::render(); to retrieve template
        $sReturn = parent::render();
        // init WirecardDataStorage
        $dataStorageInit = $this->_dd_getWirecardDataStorage();
        // set fallback Parameter
        $this->_aViewData['dd_wirecard_usefallback'] = $this->_blUseWirecardFallback;
        // retrieve and set error Messages
        $this->_unsetPaymentErrors();
        return $this->_sThisTemplate;
    }

    /**
     * get Wirecard Data Storage
     * initiate Library and get already set PaymentData or show Errors
     *
     * @return WirecardCEE_Client_DataStorage_Request_Initiation
     */
    protected function _dd_getWirecardDataStorage() {
        if ($this->_oWirecardStorageRequest === null) {
            try {
                $iDDRefNr = dd_orderrefnr::getInstance()->getDDRefNr();
                // getWirecardDataStore
                $this->_oWirecardStorageRequest = dd_wirecard_utils::getInstance()->getWirecardDataStore();
                // get PaymentData for ReferenceNr
                $oResponse = $this->_oWirecardStorageRequest->initiate($iDDRefNr);
                // success handler
                if ($oResponse->getStatus() == WirecardCEE_Client_DataStorage_Response_Initiation::STATE_SUCCESS) {
                    // set retrieved storage Data to internal variables
                    $this->_sWirecardStorageId = $oResponse->getStorageId();
                    $this->_sWirecardStorageJsUrl = $oResponse->getJavascriptUrl();
                    dd_wirecard_utils::getInstance()->setWirecardStorageId($this->_sWirecardStorageId);
                    // oxSession::setVar( 'dd_wc_orderId', $iDDRefNr );
                    // get Storage Response
                    $this->_oWirecardStorageResponse = dd_wirecard_utils::getInstance()->getWirecardDataStoreReaderResponse();
                    // TEST
                    /*
                     * $sPaymenttype = $this->getCheckedPaymentId();
                     * dumpVar($this->dd_getWirecardPaymentData($sPaymenttype));
                     */
                }
                else {
                    $dsErrors = $oResponse->getErrors();
                    $sErrorMessages = '';
                    if (!empty($dsErrors)) {
                        foreach($dsErrors as $error) {
                            // errormessage should come from shop translation
                            // db.
                            $sErrorMessages .= 'showError("DataStorage: ' . $error->getConsumerMessage() . '", "APPEND");';
                        }
                    }
                    oxSession::setVar('payerror', -1);
                    oxSession::setVar('payerrortext', $sErrorMessages);
                    $this->aViewData['dd_wc_errors'] = $sErrorMessages;
                    // TODO: Add a Template Block for displaying errormessages
                    // if neccessary
                    // echo '<script type="text/javascript">';
                    // echo '</script>';
                }
            } catch (Exception $e) {
                oxSession::setVar('payerror', -1);
                oxSession::setVar('payerrortext', $e->getMessage());
                // echo '<script type="text/javascript">';
                // echo 'showError("DataStorage: ' . $e->getMessage() . '",
                // "APPEND");';
                // echo '</script>';
                // communication with dataStorage failed. dataStorage fallback
                $this->_blUseWirecardFallback = true;
                return;
            }
        }
        return $this->_oWirecardStorageRequest;
    }

    /**
     * check if selected payment is a wirecard payment method
     *
     * @param string $sPaymenttype
     * @return bool
     */
    public function dd_isWirecardPaymentType($sPaymenttype = null) {
        if (!$sPaymenttype) {
            $sPaymenttype = $this->getCheckedPaymentId();
        }
        // TODO handle not retrievable PaymentId
        if (!$sPaymenttype) {
			/** @var oxException $oEx */
            $oEx = oxNew('oxException');
            $oLang = oxLang::getInstance();
            $oEx->setMessage('dd_wirecard_payment dd_isWirecardPaymentType did not retrieve a valid paymentId');
            throw $oEx;
        }
        return dd_wirecard_utils::getInstance()->dd_isWirecardPaymentType($sPaymenttype);
    }

    /**
     * check if selected payment has stored Data
     *
     * @param string $sPaymenttype
     *
     * @return string $bResponse
     */
    public function dd_hasWirecardPaymentData($sPaymenttype = null) {
        if (!$sPaymenttype) {
            return false;
        }
        if (!is_object($this->_oWirecardStorageResponse)) {
            return false;
        }

        $sWirecardPaymentType = dd_wirecard_utils::getInstance()->dd_getWirecardPaymentName($sPaymenttype);
        return $this->_oWirecardStorageResponse->hasPaymentInformation($sWirecardPaymentType);
    }

    /**
     * get stored paymentData for selected payment
     *
     * @param string $sPaymenttype
     *
     * @return array $aResponse
     */
    public function dd_getWirecardPaymentData($sPaymenttype = null) {
        $aResponse = array ();
        if (!$sPaymenttype) {
            return $aResponse;
        }
        else if($sPaymenttype == 'dd_wirecard_creditcard_moto') {
            //CCARD-MOTO is stored in the same store as CCARD, so we have to use sPaymenttype CCARD for reading here
            $sPaymenttype = 'dd_wirecard_creditcard';
        }
        if (!is_object($this->_oWirecardStorageResponse)) {
            return $aResponse;
        }
        $sWirecardPaymentType = dd_wirecard_utils::getInstance()->dd_getWirecardPaymentName($sPaymenttype);
        if ($this->_oWirecardStorageResponse->hasPaymentInformation($sWirecardPaymentType)) {
            $aResponse = $this->_oWirecardStorageResponse->getPaymentInformation($sWirecardPaymentType);
            // dumpVar(oxSession::getVar( 'dynvalue') );
            // dumpVar( $sWirecardPaymentType );
            // dumpVar( $aResponse );
        }
        return $aResponse;
    }

    /**
     * get stored paymentData for selected payment in dd_wirecard format
     * the wirecard fields are mapped to oxid field names
     *
     * @param string $sPaymenttype
     *
     * @return array $aResponse
     */
    public function dd_getDDWirecardPaymentData($sPaymenttype = null) {
        $aResponse = array ();
        $aPaymentInformation = $this->dd_getWirecardPaymentData($sPaymenttype);
        if (is_array($aPaymentInformation) && !empty($aPaymentInformation)) {
            switch($sPaymenttype) {
                case 'dd_wirecard_creditcard':
                case 'dd_wirecard_creditcard_moto':
                    $sExpiry = $aPaymentInformation['expiry'];
                    $aExpiry = explode('/', $sExpiry);
                    if (!empty($aExpiry)) {
                        if (isset($aExpiry[0]))
                            $aResponse['kkmonth'] = (string) $aExpiry[0];
                        if (isset($aExpiry[1]))
                            $aResponse['kkyear'] = (string) $aExpiry[1];
                    }
                    $aResponse['kkname'] = (string) $aPaymentInformation['cardholdername'];
                    $aResponse['kknumber'] = (string) $aPaymentInformation['maskedPan'];
                    $aResponse['kkbrand'] = (string) $aPaymentInformation['brand'];
                    $aResponse['kktype'] = (string) $aPaymentInformation['financialInstitution'];
                    $aResponse['kkcvc'] = ($aPaymentInformation['cardVerifyCode']) ? (string) $aPaymentInformation['cardVerifyCode'] : '****';
                    break;
                case 'dd_wirecard_debit':
                    $aResponse['lsktoinhaber'] = (string) $aPaymentInformation['accountOwner'];
                    if(isset($aPaymentInformation['bankAccount']))
                    {
                        $aResponse['lsbankname'] = (string) $aPaymentInformation['bankName'];
                        $aResponse['lsbankcountry'] = (string) $aPaymentInformation['bankCountry'];
                        $aResponse['lsblz'] = (string) $aPaymentInformation['bankNumber'];
                        $aResponse['lsktonr'] = (string) $aPaymentInformation['bankAccount'];
                    }
                    else
                    {
                        $aResponse['lsbic'] = (string) $aPaymentInformation['bankBic'];
                        $aResponse['lsiban'] = (string) $aPaymentInformation['bankAccountIban'];
                    }
                    break;
                case 'dd_wirecard_giropay':
                    $aResponse['giropay_banknumber'] = (string) $aPaymentInformation['bankNumber'];
                    $aResponse['giropay_bankaccount'] = (string) $aPaymentInformation['bankAccount'];
                    $aResponse['giropay_accountowner'] = (string) $aPaymentInformation['accountOwner'];
                    break;
                default:
                    break;
            }
        }
        if (!$aResponse['lsbankcountry'])
            $aResponse['lsbankcountry'] = 'de';
        $this->_aDynValue = $aResponse;

        $this->_assignWirecardDebitNoteParams();

        return $this->_aDynValue;
    }

    protected function _assignWirecardDebitNoteParams()
    {
        // #701A
        $oUserPayment = oxNew( 'oxuserpayment');
        //such info available ?
        if ( $oUserPayment->getPaymentByPaymentType( $this->getUser(), 'dd_wirecard_debit' ) ) {
            $aAddPaymentData = oxRegistry::getUtils()->assignValuesFromText( $oUserPayment->oxuserpayments__oxvalue->value );

            //checking if some of values is already set in session - leave it
            foreach ( $aAddPaymentData as $oData ) {
                if ( !isset( $this->_aDynValue[$oData->name] ) ||
                    (  isset( $this->_aDynValue[$oData->name] ) && !$this->_aDynValue[$oData->name] ) ) {
                    $this->_aDynValue[$oData->name] = $oData->value;
                }
            }
        }
    }

    /**
     * Check if the payment type has any input fields for user to enter
     * IMPORTANT: PayPal doesn't have any input fields but to be able to show the PayPal image
     * it had to be added to this array
     *
     * @param string $sPaymentType
     * @return boolean
     */
    public function dd_PaymentTypeHasInputFields($sPaymentType) {
        $aPaymentTypesWithInputFields = Array (
                'dd_wirecard_creditcard',
                'dd_wirecard_creditcard_moto',
                'dd_wirecard_click2pay',
                'dd_wirecard_giropay',
                'dd_wirecard_mobileinvoice',
                'dd_wirecard_debit',
                'dd_wirecard_ideal',
                'dd_wirecard_eps');

        return (bool) (array_key_exists($sPaymentType, dd_wirecard_utils::getInstance()->_sWirecardPaymentList) && in_array($sPaymentType, $aPaymentTypesWithInputFields));
    }

    /**
     * check if CreditCard CVC Field should be shown
     *
     * @return bool
     */
    public function dd_showCCCVCField() {
        return (bool) dd_wirecard_utils::getInstance()->getConfigParam('WCS_SHOW_CREDITCARD_CVC');
    }

    /**
     * check if CreditCard Issue Number Field should be shown
     *
     * @return bool
     */
    public function dd_showCCIssueNumber() {
        return (bool) dd_wirecard_utils::getInstance()->getConfigParam('WCS_SHOW_CREDITCARD_ISSUENR');
    }

    /**
     * check if CreditCard Issue Date Field should be shown
     *
     * @return bool
     */
    public function dd_showCCIssueDate() {
        return (bool) dd_wirecard_utils::getInstance()->getConfigParam('WCS_SHOW_CREDITCARD_ISSUEDATE');
    }

    /**
     * check if CreditCard Issue Date Field should be shown
     *
     * @return bool
     */
    public function dd_showELVIbanBic() {
        return (bool) dd_wirecard_utils::getInstance()->getConfigParam('WCS_SHOW_ELV_IBANBIC');
    }

    /**
     * return Wirecard Storage Id
     *
     * @return string
     */
    public function dd_getWirecardStorageId() {
        return $this->_sWirecardStorageId;
    }

    /**
     * return Wirecard JS Url
     *
     * @return string
     */
    public function dd_getWirecardStorageJsUrl() {
        return $this->_sWirecardStorageJsUrl;
    }

    /**
     * Checks if the given payment type has any financial intitutions
     * and if so returns them in an array (for paymentSelector.tpl)
     *
     * @param string $paymentType
     * @return Array
     * @author Ante Drnasin
     */
    public function dd_getFinancialInstitutions($sPaymentType) {
        require_once ('WirecardCEE/Client/QPay/Request/Initiation/PaymentType.php');
        $sPaymentType = dd_wirecard_utils::getInstance()->dd_getWirecardPaymentName($sPaymentType);
        if (WirecardCEE_Client_QPay_Request_Initiation_PaymentType::hasFinancialInstitutions($sPaymentType)) {
            return WirecardCEE_Client_QPay_Request_Initiation_PaymentType::getFinancialInstitutions($sPaymentType);
        }
        else {
            return Array ();
        }
    }

    /**
     * ValidatePayment is called from saferpay after registerind card details.
     * Two parameters are set: "type" and "dd_status".
     *
     *
     * @return string
     */
    public function validatePayment() {
        $sPaymentId = oxConfig::getParameter('paymentid');
        $myConfig = $this->getConfig();
        /**
         * Case of Iframe Fallback.
         * Data isnt posted with ajax but iframe. so we need submit form to
         * validation WITH paymentid
         * TODO: maybe make this available over a own template
         */
        if (oxConfig::getParameter('blWirecardIframeFallback')) {
            if (!$sPaymentId) {
                $sFallbackResponse = oxConfig::getParameter('response');
                if ($sFallbackResponse) {
                    $sRedirectUrl = $myConfig->getShopCurrentUrl() . '?cl=payment&validatePayment';
                    echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <script type="text/javascript">
            function setResponse(response)
            {
                if(typeof parent.WirecardCEE_Fallback_Request_Object == "object")
                {
                    parent.WirecardCEE_Fallback_Request_Object.setResponseText(response);
                }
                else
                {
                    console.log("Not a valid seamless fallback call.");
                }
            }
        </script>
    </head>
    <body onload=\'setResponse("' . addslashes(html_entity_decode($sFallbackResponse)) . '");\'>

    </body>
</html>';
                }
            }
            exit();
        }
        $parentResult = parent::validatePayment();

        // standard procedure with other payments
        if (!$this->dd_isWirecardPaymentType($sPaymentId)) {
            return $parentResult;
        }

        $aDynvalue = oxConfig::getParameter('dynvalue');
        if (!is_array($aDynvalue))
            $aDynvalue = array ();
        switch($sPaymentId) {
            case 'dd_wirecard_creditcard':
            case 'dd_wirecard_creditcard_moto':
                // Default way to get anonymous data
                $sExpiry = oxConfig::getParameter('expiry');
                $aExpiry = explode('/', $sExpiry);
                if (!empty($aExpiry)) {
                    if (isset($aExpiry[0]))
                        $aDynvalue['kkmonth'] = (string) $aExpiry[0];
                    if (isset($aExpiry[1]))
                        $aDynvalue['kkyear'] = (string) $aExpiry[1];
                }
                $aDynvalue['kkname'] = (string) oxConfig::getParameter('cardholdername');
                $aDynvalue['kknumber'] = (string) oxConfig::getParameter('maskedPan');
                $aDynvalue['kkbrand'] = (string) oxConfig::getParameter('brand');
                $aDynvalue['kktype'] = (string) oxConfig::getParameter('financialInstitution');
                $aDynvalue['kkeci'] = (string) oxConfig::getParameter('authenticated');
                $aDynvalue['kkcvc'] = (oxConfig::getParameter('cardVerifyCode')) ? (string) oxConfig::getParameter('cardVerifyCode') : '****';

                // fallback, get variables through Reader
                if (!$aDynvalue['kkname'] || !$aDynvalue['kknumber']) {
                    // init Response Reader and get Response
                    $this->_oWirecardStorageResponse = dd_wirecard_utils::getInstance()->getWirecardDataStoreReaderResponse();
                    // retrieve payment Info ind oxid format by paymentid
                    $aPaymentInformation = $this->dd_getDDWirecardPaymentData($sPaymentId);
                    if (is_array($aPaymentInformation) && !empty($aPaymentInformation)) {
                        $aDynvalue = array_merge($aDynvalue, $aPaymentInformation);
                    }
                }
                if (!$aDynvalue['kkname'] || !$aDynvalue['kknumber']) {
                    return false;
                }
                break;
            case 'dd_wirecard_debit':
                $aDynvalue['lsbankname'] = (string) oxConfig::getParameter('bankName');
                $aDynvalue['lsbankcountry'] = (string) oxConfig::getParameter('bankCountry');
                $aDynvalue['lsblz'] = (string) oxConfig::getParameter('bankNumber');
                $aDynvalue['lsktonr'] = (string) oxConfig::getParameter('bankAccount');
                $aDynvalue['lsbic'] = (string) oxConfig::getParameter('bankBic');
                $aDynvalue['lsiban'] = (string) oxConfig::getParameter('bankAccountIban');
                $aDynvalue['lsktoinhaber'] = (string) oxConfig::getParameter('accountOwner');
                // fallback, get variables through Reader
                if ((!$aDynvalue['lsblz'] || !$aDynvalue['lsktonr']) && (!$aDynvalue['lsbic'] || !$aDynvalue['lsiban'])) {
                    // init Response Reader and get Response
                    $this->_oWirecardStorageResponse = dd_wirecard_utils::getInstance()->getWirecardDataStoreReaderResponse();

                    // retrieve payment Info ind oxid format by paymentid
                    $aPaymentInformation = $this->dd_getDDWirecardPaymentData($sPaymentId);
                    if (is_array($aPaymentInformation) && !empty($aPaymentInformation)) {
                        $aDynvalue = array_merge($aDynvalue, $aPaymentInformation);
                    }
                }
                // still no complete ELV data
                if ((!$aDynvalue['lsblz'] || !$aDynvalue['lsktonr']) && (!$aDynvalue['lsbic'] || !$aDynvalue['lsiban'])) {
                    return false;
                }
                break;
            case 'dd_wirecard_giropay':
                $aDynvalue['giropay_banknumber'] = (string) oxConfig::getParameter('bankNumber');
                $aDynvalue['giropay_bankaccount'] = (string) oxConfig::getParameter('bankAccount');
                $aDynvalue['giropay_accountowner'] = (string) oxConfig::getParameter('accountOwner');
                break;
            case 'dd_wirecard_click2pay':
            case 'dd_wirecard_invoice':
            case 'dd_wirecard_installment':
            case 'dd_wirecard_paypal':
            case 'dd_wirecard_sofort':
            case 'dd_wirecard_mobileinvoice':
            case 'dd_wirecard_psc':
            case 'dd_wirecard_quick':
            case 'dd_wirecard_bmc':
            case 'dd_wirecard_poli':
            case 'dd_wirecard_moneta':
            case 'dd_wirecard_przelewy24':
            case 'dd_wirecard_ekonto':
            case 'dd_wirecard_instantbank':
            case 'dd_wirecard_skrilldirect':
            case 'dd_wirecard_skrillwallet':
            case 'dd_wirecard_mpass':
                break;
            case 'dd_wirecard_eps':
                $aDynvalue['financialInstitution'] = (string) oxConfig::getParameter('eps_financialInstitution');
                break;
            case 'dd_wirecard_ideal':
                $aDynvalue['financialInstitution'] = (string) oxConfig::getParameter('ideal_financialInstitution');
                break;
            default:
                oxSession::setVar('payerror', 1);
                return;
                break;
        }

        oxSession::setVar('dynvalue', $aDynvalue);
        return $parentResult;
    }

    /**
     * Template variable getter.
     * Returns array of years for credit cards issue date
     *
     * @return array
     */
    public function getCreditIssueYears() {
        if ($this->_aCreditIssueYears === null) {
            $this->_aCreditIssueYears = range(date('Y') - 10, date('Y'));
        }
        return $this->_aCreditIssueYears;
    }

    /**
     * Template variable getter.
     * Returns array of countrycodes for elv banks
     *
     * @return array
     */
    public function getElvCountries() {
        if ($this->_aElvCountries === null) {
            // passing country list
            $oCountryList = oxNew('oxcountrylist');
            $oListObject = $oCountryList->getBaseObject();
            $sViewName = $oListObject->getViewName();
            $sQ = "select " . $sViewName . ".oxisoalpha2, " . $sViewName . ".oxtitle from " . $oListObject->getViewName();
            $sQ .= " where " . $sViewName . ".oxisoalpha2 IN ('DE', 'AT', 'NL') ";
            if ($sActiveSnippet = $oListObject->getSqlActiveSnippet()) {
                $sQ .= " AND " . $sActiveSnippet;
            }
            $oCountryList->selectString($sQ);
            $this->_aElvCountries = $oCountryList->getArray();
        }
        return $this->_aElvCountries;
    }
}
?>