<?php
/**
    Shop System Plugins - Terms of use

    This terms of use regulates warranty and liability between Wirecard
    Central Eastern Europe (subsequently referred to as WDCEE) and it's
    contractual partners (subsequently referred to as customer or customers)
    which are related to the use of plugins provided by WDCEE.

    The Plugin is provided by WDCEE free of charge for it's customers and
    must be used for the purpose of WDCEE's payment platform integration
    only. It explicitly is not part of the general contract between WDCEE
    and it's customer. The plugin has successfully been tested under
    specific circumstances which are defined as the shopsystem's standard
    configuration (vendor's delivery state). The Customer is responsible for
    testing the plugin's functionality before putting it into production
    enviroment.
    The customer uses the plugin at own risk. WDCEE does not guarantee it's
    full functionality neither does WDCEE assume liability for any
    disadvantage related to the use of this plugin. By installing the plugin
    into the shopsystem the customer agrees to the terms of use. Please do
    not use this plugin if you do not agree to the terms of use!
*/

/**
 * order view extended class
 * overloads execute function and adds notification methods
 */
class dd_wirecard_order extends dd_wirecard_order_parent
{
    /**
     * Initiated WirecardCEE_Client_QPay_Return Object
     *
     * @var WirecardCEE_Client_QPay_Return
     */
    protected $_oQPAYReturn = null;

    /**
     * init hook
     *
     */
    public function init()
    {
        return parent::init();
    }

    /**
     * Execute parent render()
     * check if qpayIframe parameter is set and check value
     * add view Param for Iframe Block
     * update ReferenceNr Status
     *
     * @return template _sThisTemplate
     */
    public function render()
    {
        // parent::render(); to retrieve template
        $sReturn = parent::render();
        // set qpay iframe parameters
        $this->_aViewData['dd_wirecard_useiframe'] = oxConfig::getParameter( 'wcs_use_iframe' );
        $this->_aViewData['dd_wirecard_iframeurl'] = urldecode( oxConfig::getParameter( 'wcs_iframe_url' ) );
        if (!(bool)oxConfig::getParameter( 'wcs_use_iframe' ))
        {
            //update referencenumber add payment info and oxbasket object
            dd_orderrefnr::getInstance()->updateDDRefNrObjectsOrderView();
        }
        return $this->_sThisTemplate;
    }

    /**
     * Overridden parent::getPayment()
     *
     * In case of a payment with payment method that requires from user
     * to choose financial institution this will append the name of the fin. institution to the payment method value.
     *
     * This is used on the order overview page (front end) - after the user chooses payment method
     *
     * @see views/order.php
     * @return object
     */
    public function getPayment() {
        $oPayment = parent::getPayment();
        $aDynvalue = oxSession::getVar('dynvalue');

        if(isset($aDynvalue['financialInstitution']) && !empty($aDynvalue['financialInstitution'])) {
            require_once('modules/dd_wirecard/library/WirecardCEE/Client/QPay/Request/Initiation/PaymentType.php');
            $sFinancialInstitutionFullName = WirecardCEE_Client_QPay_Request_Initiation_PaymentType::getFinancialInstitutionFullName($aDynvalue['financialInstitution']);

            //for some reason without strstr the value appears twice ie. iDEAL (Wirecard) - Postbank - Postbank
            if(!strstr($oPayment->oxpayments__oxdesc->value, $sFinancialInstitutionFullName)) {
                $oPayment->oxpayments__oxdesc->value .= " - {$sFinancialInstitutionFullName}";
            }
        }

        return $oPayment;
    }

    /**
     * check if selected payment is a wirecard payment method
     *
     * @param string $sPaymenttype
     * @return bool
     */
    public function dd_isWirecardPaymentType($sPaymenttype = null)
    {
        if(!$sPaymenttype)
        {
            if ($oPayment = $this->getPayment())
            {
                $sPaymenttype = $oPayment->getId();
            }
            elseif ($this->getBasket())
            {
                $sPaymenttype = $this->getBasket()->getPaymentId();
            }
        }

        if (!$sPaymenttype)
        {
			/** @var oxEception $oEx */
            $oEx = oxNew( 'oxException' );
            $oLang = oxLang::getInstance();
            $oEx->setMessage( 'dd_wirecard_order dd_isWirecardPaymentType did not retrieve a valid paymentId' );
            throw $oEx;
        }
        return dd_wirecard_utils::getInstance()->dd_isWirecardPaymentType($sPaymenttype);
    }

    /**
     * Executed by wirecard notify url.
     * Server2server.
     * This function should be executed before users client is redirected to successurl.
     * if customer returns, an order check will be done to shorten process
     *
     */
    public function WirecardNotify()
    {
        $blWCreturn = oxConfig::getParameter('blWirecardReturn');
        //$myConfig = $this->getConfig();
        //$iDDRefNr     = dd_orderrefnr::getInstance()->getDDRefNr();
		$iDDRefNr = null;
        if ($blWCreturn)
        {
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("wirecardnotify");
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(".$blWCreturn."): rToken: ".oxSession::getInstance()->getRemoteAccessToken()." ");
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(".$blWCreturn."): rTokenParam: ".oxConfig::getParameter('rtoken')." ");
            //dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(".$blWCreturn."): ddrefNr: ".$iDDRefNr." ");
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(".$blWCreturn."): GET_DATA: ".var_export($_GET, true)." ");
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(".$blWCreturn."): POST_DATA: ".var_export($_POST, true)." ");
        }

        // check if order is already existing if customer returns to this view
        if (!$blWCreturn)
        {
            try {
                $oOrder = oxNew( 'oxorder' );
                $blExists = $oOrder->dd_wirecard_checkOrderExists();
                if ($blExists)
                {
                    return $this->_getNextStep( oxorder::ORDER_STATE_ORDEREXISTS );
                }
            }
            catch (Exception $e)
            {
                 dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(".$blWCreturn."): {$e->getMessage()}");
            }
        }



        // init QPAYRequestObject
        $this->_oQPAYReturn = dd_wirecard_utils::getInstance()->getQPAYReturn();
        if($this->_oQPAYReturn->validate())
        {
            // be sure to have correct refnr
            oxSession::setVar('iDDrefNr', $this->_oQPAYReturn->ddrefnr);

            switch($this->_oQPAYReturn->getPaymentState())
            {
                case 'SUCCESS':
                    if(dd_orderrefnr::getInstance()->getStatus($iDDRefNr) === dd_orderrefnr::$ORDERSTATUS_PENDING)
                    {
                        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_PAID);
                        return $this->_dd_wirecard_updateFinalizedOrder($this->_oQPAYReturn);
                    }
                    else
                    {
                        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_PAID);
                        return $this->_dd_wirecard_finalizeOrder($this->_oQPAYReturn);
                    }
                    break;
                case 'CANCEL':
                    dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_CANCELED);
                    return ;
                    break;
                case 'FAILURE':
                    $aFormattedErrors = array();
                    foreach($this->_oQPAYReturn->getErrors() AS $error)
                    {
                        $aFormattedErrors[] = $error->getConsumerMessage();
                    }
                    $this->_handleFailedPayment(-1, $aFormattedErrors );
                    break;
                case 'PENDING':
                    dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_PENDING);
                    return $this->_dd_wirecard_finalizeOrder($this->_oQPAYReturn, true);
                    break;
                default:
                    $confirmResponse = WirecardCEE_Client_QPay_Return::generateConfirmResponseString('Unknown paymentState: ' . $this->_oQPAYReturn->getPaymentState());
                    $aFormattedErrors[] = $confirmResponse;
                    $aFormattedErrors[] = 'Unknown QPAY paymentState: ' . $this->_oQPAYReturn->getPaymentState();
                    $this->_handleFailedPayment(-1, $aFormattedErrors );
                    break;
            }
        }
        else
        {
            $aFormattedErrors[] = 'No Valid CONFIRM response';
            $this->_handleFailedPayment(-1, $aFormattedErrors );
        }
        return ;

        /*dumpVar('order->WirecardNotify');
        dumpVar($confirmResponse);
        dumpVar($this->_oQPAYReturn);
        exit;*/
        //die;

    }

    /**
     * Error Handler for Return
     *
     * @return bool
     */
    public function WirecardCancel()
    {
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("WirecardCancel");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::WirecardCancel(): GET_DATA: ".var_export($_GET, true)." ");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::WirecardCancel(): POST_DATA: ".var_export($_POST, true)." ");
        // set Failed Status
        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_CANCELED);
        $myConfig = $this->getConfig();
        $redirectUrl =  $myConfig->getShopSecureHomeUrl().'cl=payment';
        // user Redirect for Iframe
        dd_wirecard_utils::getInstance()->dd_wirecardIframeRedirect($redirectUrl);
        return;
    }

    /**
     * Error Handler for Return
     *
     * @return bool
     */
    public function WirecardFail()
    {
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("wirecardfail");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardfail(): GET_DATA: ".var_export($_GET, true)." ");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardfail(): POST_DATA: ".var_export($_POST, true)." ");
        // set Failed Status
        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_FAILED);
        $myConfig = $this->getConfig();
        $redirectUrl =  $myConfig->getShopSecureHomeUrl().'cl=payment';
        oxSession::setVar( 'payerror', -1 );
        // user Redirect for Iframe
        dd_wirecard_utils::getInstance()->dd_wirecardIframeRedirect($redirectUrl);
        return;
    }

    /**
     * Pending Handler for Return
     * @return bool
     */
    public function WirecardPending()
    {
        $myConfig = $this->getConfig();
        $iDDRefNr     = dd_orderrefnr::getInstance()->getDDRefNr();
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("wirecardpending");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardpending(): ddrefNr: ".$iDDRefNr." ");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardpending(): GET_DATA: ".var_export($_GET, true)." ");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardpending(): POST_DATA: ".var_export($_POST, true)." ");
        // check if order is already existing if customer returns to this view
        try
        {
            $oOrder = oxNew( 'oxorder' );
            $blExists = $oOrder->dd_wirecard_checkOrderExists();
            if ($blExists)
            {
                // everything fine
                return $this->_getNextStep( oxorder::ORDER_STATE_OK ).'&pending=1';
            }
        }
        catch (Exception $e)
        {

        }

        // worst case: user returned on Succes but order has not yet been saved!!!
        $oEx = oxNew( 'oxSystemComponentException' );
        $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
        $oEx->setComponent( 'module dd_wirecard WirecardPending' );
        $oEx->setMessage( 'order::WirecardPending: Customer returned but order was not closed yet: ReferenceNumber: '.$iDDRefNr.( ($e) ? ' Exception:'.$e->getMessage() : '' ) );
        $oEx->debugOut();
        // set Failed Status
        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_FAILED);
        return $this->_getNextStep( oxorder::ORDER_STATE_PAYMENTERROR  );
    }

    /**
     * Success Handler for Return
     * @return Redirecturl
     */
    public function WirecardSuccess()
    {
        $myConfig = $this->getConfig();
        $iDDRefNr     = dd_orderrefnr::getInstance()->getDDRefNr();
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("wirecardsuccess");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardnotify(): ddrefNr: ".$iDDRefNr." ");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardsuccess(): GET_DATA: ".var_export($_GET, true)." ");
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::wirecardsuccess(): POST_DATA: ".var_export($_POST, true)." ");
        // check if order is already existing if customer returns to this view
        try
        {
            $oOrder = oxNew( 'oxorder' );
            $blExists = $oOrder->dd_wirecard_checkOrderExists();
            if ($blExists)
            {
                // everything fine
                return $this->_getNextStep( oxorder::ORDER_STATE_OK );
            }
        }
        catch (Exception $e)
        {

        }

        // worst case: user returned on Succes but order has not yet been saved!!!
        $oEx = oxNew( 'oxSystemComponentException' );
        $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
        $oEx->setComponent( 'module dd_wirecard WirecardSuccess' );
        $oEx->setMessage( 'order::WirecardSuccess: Customer returned but order was not closed yet: ReferenceNumber: '.$iDDRefNr.( ($e) ? ' Exception:'.$e->getMessage() : '' ) );
        $oEx->debugOut();
        // set Failed Status
        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_FAILED);
        return $this->_getNextStep( oxorder::ORDER_STATE_PAYMENTERROR  );
    }

    /**
     * parent:execute
     * Checks for order rules confirmation ("ord_agb", "ord_custinfo" form values)(if no
     * rules agreed - returns to order view), loads basket contents (plus applied
     * price/amount discount if available - checks for stock, checks user data (if no
     * data is set - returns to user login page). Stores order info to database
     * (oxorder::finalizeOrder()). According to sum for items automatically assigns user to
     * special user group ( oxuser::onOrderExecute(); if this option is not disabled in
     * admin). Finally you will be redirected to next page (order::_getNextStep()).
     *
     * dd execute:
     * Log that order ist submitted and save user / basket / order Object to dd_refnrobjects
     *
     * @return string
     */
    function execute()
    {
        // parent:execute if paymenttype is not a wirecard payment
        if (!$this->dd_isWirecardPaymentType()) {
			// purge dd_orderrefobjects for non wirecard payments
			$iDDRefNr = dd_orderrefnr::getInstance()->getDDRefNr();
			dd_orderrefnr::getInstance()->deleteDDrefObjects($iDDRefNr);
			return parent::execute();
		}
        $myConfig = oxConfig::getInstance();
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::execute(): entering execute ");
        return parent::execute();
    }

    /**
     *
     *
     * @return string
     */
    public function _dd_wirecard_updateFinalizedOrder($oQpayReturn)
    {
        $blWCreturn = oxConfig::getParameter('blWirecardReturn');
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::_dd_wirecard_updateFinalizedOrder(".$blWCreturn."): WirecardCEE_Client_QPay_Return: ".var_export($oQpayReturn, true)." ");

        $myConfig = $this->getConfig();
        $iDDRefNr     = dd_orderrefnr::getInstance()->getDDRefNr();

        try
        {
            $oOrder = oxNew('oxorder');

            $sSql = "SELECT oxid from oxorder where dd_wirecard_cardref='".$iDDRefNr."';" ;
            $iDDrefOxid = oxDB::getDb()->GetOne($sSql);

            if ($oOrder->load($iDDrefOxid))
            {
                if ($oOrder->oxorder__oxpayid->value == "PENDING")
                {
                    $oOrder->oxorder__dd_wirecard_cardref        = new oxField( $iDDRefNr, oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_avscode        = new oxField( (string)$oQpayReturn->getAvsResponseCode(), oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_avsmessage     = new oxField( (string)$oQpayReturn->getAvsResponseMessage(), oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_contractnr     = new oxField( (string)$oQpayReturn->getGatewayContractNumber(), oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_financialinst  = new oxField( (string)$oQpayReturn->getFinancialInstitution(), oxField::T_RAW );
                    $oOrder->oxorder__oxpayid                    = new oxField( (string)$oQpayReturn->getOrderNumber(), oxField::T_RAW );
                    $oOrder->oxorder__oxtransid                  = new oxField( (string)$oQpayReturn->getGatewayReferenceNumber(), oxField::T_RAW );
                    $oOrder->oxorder__oxpaid                     = new oxField( date('Y-m-d H:i:s'), oxField::T_RAW );
                    $oOrder->oxorder__oxtransstatus              = new oxField( "PAID", oxField::T_RAW );
                    $blOrderSaved = $oOrder->save();

                    if ($blOrderSaved)
                    {
                        $oxEmail = oxnew('oxemail');
                        $oxEmail->sendWCSPaidMail($oOrder);
                    }
                }
                else
                {
                    dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::_dd_wirecard_updateFinalizedOrder(".$blWCreturn."): WRONG ORDER, not in PENDING state");
                    $oEx = oxNew( 'oxSystemComponentException' );
                    $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                    $oEx->setComponent( 'module dd_wirecard' );
                    $oEx->setMessage( 'order::_dd_wirecard_updateFinalizedOrder('.$blWCreturn.'):  WRONG ORDER, not in PENDING state, ReferenceNumber: '.$iDDRefNr);
                    $oEx->debugOut();
                }
            }
            else
            {
                dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::_dd_wirecard_updateFinalizedOrder(".$blWCreturn."): ORDER NOT FOUND");
                $oEx = oxNew( 'oxSystemComponentException' );
                $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                $oEx->setComponent( 'module dd_wirecard' );
                $oEx->setMessage( 'order::_dd_wirecard_updateFinalizedOrder('.$blWCreturn.'): ORDER NOT FOUND, ReferenceNumber: '.$iDDRefNr);
                $oEx->debugOut();
            }

            // destroy referencenumber instance
            dd_orderrefnr::getInstance()->destroy();
            // also reset storageId
            dd_wirecard_utils::getInstance()->setWirecardStorageId( null );

            exit;
        }
        catch (Exception $e)
        {
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::_dd_wirecard_updateFinalizedOrder(".$blWCreturn."): EXCEPTION on ORDER SAVING");
            if ( $e instanceof oxException )
            {
                $oEx = oxNew( 'oxSystemComponentException' );
                $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                $oEx->setComponent( 'module dd_wirecard' );
                $oEx->setMessage( 'order::_dd_wirecard_updateFinalizedOrder('.$blWCreturn.'): EXCEPTION on ORDER SAVING, ReferenceNumber: '.$iDDRefNr);
                $oEx->debugOut();
                $e->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                $e->debugOut();
            }
        }
    }

    /**
     * loads basket contents (plus applied price/amount discount if available - checks for stock, checks user data
     * (if no data is set - returns to user login page). Stores order info to database
     * (oxorder::finalizeOrder()). According to sum for items automatically assigns user to
     * special user group ( oxuser::onOrderExecute(); if this option is not disabled in
     * admin). Finally you will be redirected to next page (order::_getNextStep()).
     *
     * On Internal Shop Exception we still try to save an order.
     * Else all serialized data will be stored in dd_orderrefobjects
     *
     * @return string
     */
    public function _dd_wirecard_finalizeOrder($oQpayReturn, $blPending = false)
    {
        if (!$this->getSession()->checkSessionChallenge())
        {
            return;
        }

        $blWCreturn = oxConfig::getParameter('blWirecardReturn');
        dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::_dd_wirecard_finalizeOrder(".$blWCreturn."): WirecardCEE_Client_QPay_Return: ".var_export($oQpayReturn, true)." ");

        $myConfig = $this->getConfig();
        $iDDRefNr     = dd_orderrefnr::getInstance()->getDDRefNr();

        // usual finalization of oxorder
        try
        {
            // try to get User Object
            if (!$oUser= $this->getUser())
            {
                $oObjects = dd_orderrefnr::getInstance()->getDDrefObjects();
                $oUser = unserialize($oObjects->dd_orderrefobjects__oxuser->rawValue);
                if (!$oUser)
                {
					/** @var oxSystemComponentException $oEx */
                    $oEx = oxNew( 'oxSystemComponentException' );
                    $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                    $oEx->setComponent( 'module dd_wirecard WirecardSuccess' );
                    $oEx->setMessage( 'dd_wirecard_order _dd_wirecard_finalizeOrder could not retrieve a valid oxuser' );
                    $oEx->debugOut();
                    throw $oEx;
                }
            }
            // get basket contents
            $oBasket  = $this->getSession()->getBasket();
            if ( !$oBasket )
            {
                $oObjects = dd_orderrefnr::getInstance()->getDDrefObjects();
                $oBasket = unserialize($oObjects->dd_orderrefobjects__oxbasket->rawValue);
                if (!$oBasket)
                {
					/** @var oxSystemComponentException $oEx */
                    $oEx = oxNew( 'oxSystemComponentException' );
                    $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                    $oEx->setComponent( 'module dd_wirecard WirecardSuccess' );
                    $oEx->setMessage( 'dd_wirecard_order _dd_wirecard_finalizeOrder could not retrieve a valid oxbasket' );
                    $oEx->debugOut();
                    throw $oEx;
                }
            }

            if ($oBasket->getProductsCount())
            {
                try
                {
                    $oOrder = oxNew( 'oxorder' );
                    // set wirecard params to Order Table
                    $oOrder->oxorder__dd_wirecard_cardref        = new oxField( $iDDRefNr, oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_avscode        = new oxField( (string)$oQpayReturn->getAvsResponseCode(), oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_avsmessage     = new oxField( (string)$oQpayReturn->getAvsResponseMessage(), oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_contractnr     = new oxField( (string)$oQpayReturn->getGatewayContractNumber(), oxField::T_RAW );
                    $oOrder->oxorder__dd_wirecard_financialinst  = new oxField( (string)$oQpayReturn->getFinancialInstitution(), oxField::T_RAW );
                    $oOrder->oxorder__oxtransid                  = new oxField( (string)$oQpayReturn->getGatewayReferenceNumber(), oxField::T_RAW );

                    if ($blPending)
                    {
                        $oOrder->oxorder__oxpayid                    = new oxField( "PENDING", oxField::T_RAW );
                        $oOrder->oxorder__oxpaid                     = new oxField( "0000-00-00 00:00:00", oxField::T_RAW );
                    }
                    else
                    {
                        $oOrder->oxorder__oxpayid                    = new oxField( (string)$oQpayReturn->getOrderNumber(), oxField::T_RAW );
                        $oOrder->oxorder__oxpaid                     = new oxField( date('Y-m-d H:i:s'), oxField::T_RAW );
                    }

                    // shoud be PENDING or PAID ... gets overwritten by $oOrder->finalizeOrder()?
                    $oOrder->oxorder__oxtransstatus              = new oxField( "OK", oxField::T_RAW );

                    //store mandateInformation for ELV
                    if($oQpayReturn instanceof WirecardCEE_Client_QPay_Return_Success_Elv)
                    {
                        // copying payment info fields
                        $aDynvalue = oxSession::getVar( 'dynvalue' );
                        $aDynvalue = $aDynvalue ? $aDynvalue : oxConfig::getParameter( 'dynvalue' );
                        $aDynvalue['lsmandateid'] = $oQpayReturn->getMandateId();
                        $aDynvalue['lsmandatesignaturedate'] = $oQpayReturn->getMandateSignatureDate();
                        $aDynvalue['lscreditorid'] = $oQpayReturn->getCreditorId();
                        $aDynvalue['lsduedate'] = $oQpayReturn->getDueDate();

                        oxSession::setVar('dynvalue', $aDynvalue);
                    }

                    // finalizing ordering process (validating, storing order into DB, executing payment, setting status ...)
                    $iSuccess = $oOrder->finalizeOrder( $oBasket, $oUser );
                    dd_orderrefnr::getInstance()->setOrdernr($oOrder->oxorder__oxordernr->value);
                    dd_orderrefnr::getInstance()->deleteDDrefObjects($iDDRefNr);
                    // performing special actions after user finishes order (assignment to special user groups)
                    $oUser->onOrderExecute( $oBasket, $iSuccess );

                    if (!$blPending && $iSuccess === oxOrder::ORDER_STATE_OK)
                    {
                        $oxEmail = oxnew('oxemail');
                        $oxEmail->sendWCSPaidMail($oOrder);
                    }

                    // proceeding to next view
                    return $this->_getNextStep( $iSuccess );
                }
                catch (oxOutOfStockException $oEx)
                {
                    oxUtilsView::getInstance()->addErrorToDisplay( $oEx, false, true, 'basket' );
                    throw $oEx;
                }
                catch ( oxNoArticleException $oEx )
                {
                    oxUtilsView::getInstance()->addErrorToDisplay( $oEx );
                    throw $oEx;
                }
                catch ( oxArticleInputException $oEx )
                {
                    oxUtilsView::getInstance()->addErrorToDisplay( $oEx );
                    throw $oEx;
                }
            }
        }
        catch (Exception $e)
        {
            // in case some stock Exception happens or Basket / User invalidity
            // VERY ROUGH Order Fallback
            // This Part isnt tested well.
            // Oxorder will be written in ERROR Status
            // first logging
            dd_wirecard_utils::getInstance()->dd_WirecardFileLog("order::_dd_wirecard_finalizeOrder(".$blWCreturn."): EXCEPTION on ORDER SAVING ");
            if ( $e instanceof oxException )
            {
                $oEx = oxNew( 'oxSystemComponentException' );
                $oEx->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                $oEx->setComponent( 'module dd_wirecard' );
                $oEx->setMessage( 'order::_dd_wirecard_finalizeOrder('.$blWCreturn.'): EXCEPTION on ORDER SAVING' );
                $oEx->debugOut();
                $e->setLogFileName( 'DD_WIRECARD_EXCEPTION.txt' );
                $e->debugOut();
            }
            // retrieve saved oxorder object
            $oObjects = dd_orderrefnr::getInstance()->getDDrefObjects();
            $oOrder = unserialize($oObjects->dd_orderrefobjects__oxorder->rawValue);
            // set wirecard params
            $oOrder->oxorder__dd_wirecard_cardref       = new oxField( $iDDRefNr, oxField::T_RAW );
            $oOrder->oxorder__dd_wirecard_avscode       = new oxField( (string)$oQpayReturn->getAvsResponseCode(), oxField::T_RAW );
            $oOrder->oxorder__dd_wirecard_avsmessage    = new oxField( (string)$oQpayReturn->getAvsResponseMessage(), oxField::T_RAW );
            $oOrder->oxorder__dd_wirecard_contractnr    = new oxField( (string)$oQpayReturn->getGatewayContractNumber(), oxField::T_RAW );
            $oOrder->oxorder__dd_wirecard_financialinst = new oxField( (string)$oQpayReturn->getFinancialInstitution(), oxField::T_RAW );
            $oOrder->oxorder__oxpayid                   = new oxField( (string)$oQpayReturn->getOrderNumber(), oxField::T_RAW );
            $oOrder->oxorder__oxtransid                 = new oxField( (string)$oQpayReturn->getGatewayReferenceNumber(), oxField::T_RAW );
            $oOrder->oxorder__oxpaid                    = new oxField( date('Y-m-d H:i:s'), oxField::T_RAW );
            $oOrder->oxorder__oxtransstatus             = new oxField( "ERROR", oxField::T_RAW );

            // hard Save without usual finalize Order
            $blOrderSaved = $oOrder->save();

            if ($blOrderSaved)
            {
                dd_orderrefnr::getInstance()->setOrdernr($oOrder->oxorder__oxordernr->value);
                dd_orderrefnr::getInstance()->deleteDDrefObjects($iDDRefNr);
                return $this->_getNextStep( oxOrder::ORDER_STATE_OK );
            }
            // if workaroud did not work. show error to wirecard request
            oxSession::setVar( 'payerror', 1 );
            oxSession::setVar( 'payerrortext', $e->getMessage() );
            return $this->_getNextStep( oxOrder::ORDER_STATE_PAYMENTERROR );
        }
    }

    /**
     * Failed Payment Handler
     * Save Errors and redirect to payment view
     * @param $iPaymentError - Error Code.
     * @param $aFormattedErrors array of formatted Error strings.
     */
    protected function _handleFailedPayment($iPaymentError = -1, $aFormattedErrors = array())
    {
        $myConfig = $this->getConfig();
        $blWCreturn = oxConfig::getParameter('blWirecardReturn');
        // set Failed Status
        dd_orderrefnr::getInstance()->setStatus(dd_orderrefnr::$ORDERSTATUS_FAILED);
        // reset of reference. get a new number
        dd_orderrefnr::getInstance()->resetDDRefNr();
        // also reset storageId
        dd_wirecard_utils::getInstance()->setWirecardStorageId( null );
        // Save Errors and redirect to payment view
        oxSession::setVar( 'payerror', $iPaymentError );
        oxSession::setVar( 'payerrortext', implode('<br/>', $aFormattedErrors) );
        if ($blWCreturn)
        {
            // show wirecard head for server2server
            return $this->_getNextStep( 99 ); //oxOrder::ORDER_STATE_PAYMENTERROR
        }
        $redirectUrl =  $myConfig->getShopSecureHomeUrl().'cl=payment';
        // usere Redirect for Iframe
        dd_wirecard_utils::getInstance()->dd_wirecardIframeRedirect($redirectUrl);
        //oxUtils::getInstance()->redirect($redirectUrl);
        exit;
    }

    /**
     * Returns next order step.
     * If its a confirmUrl call we will Send a Cofiramtion HTML Block and exit
     *
     * @param integer $iSuccess status code
     *
     */
    protected function _getNextStep( $iSuccess )
    {
        // parent:_executeNewAction if paymenttype is not a wirecard payment
        if (!$this->dd_isWirecardPaymentType())  return parent::_getNextStep( $iSuccess );

        $blWCreturn = oxConfig::getParameter('blWirecardReturn');
        if ($blWCreturn)
        {
            //little trick with switch for multiple cases
            switch ( true )
            {
                case ( $iSuccess === oxOrder::ORDER_STATE_MAILINGERROR ):
                case ( $iSuccess === oxOrder::ORDER_STATE_ORDEREXISTS ):
                    oxUtils::getInstance()->showMessageAndExit( '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head></head><body>'.dd_wirecard_utils::getInstance()->generateQPayConfirmResponseString('', true).'</body></html>');
                    exit;
                    break;
                case ( $iSuccess === oxOrder::ORDER_STATE_PAYMENTERROR ):
                case ( is_numeric( $iSuccess ) && $iSuccess > 3 ):
                case ( !is_numeric( $iSuccess ) && $iSuccess ):
                    $sErrorMessage = oxSession::getVar( 'payerrortext' );
                    // just return an error message if its not a wirecard problem
                    if ($iSuccess == 99)
                    {
                        $sErrorMessage = '';
                    }
                    oxUtils::getInstance()->showMessageAndExit( '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head></head><body>'.dd_wirecard_utils::getInstance()->generateQPayConfirmResponseString($sErrorMessage, true).'</body></html>');
                    exit;
                    break;
                default:
                    oxUtils::getInstance()->showMessageAndExit( '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html><head></head><body>'.dd_wirecard_utils::getInstance()->generateQPayConfirmResponseString('', true).'</body></html>');
                    exit;
                    break;
            }
        }
        else {
            return parent::_getNextStep( $iSuccess );
        }
    }

    /**
     * Formats header for new controller action
     *
     * Input example: "view_name?param1=val1&param2=val2" => "cl=view_name&param1=val1&param2=val2"
     *
     * @param string $sNewAction new action params
     *
     * @return string
     */
    protected function _executeNewAction( $sNewAction = null )
    {
        // parent:_executeNewAction if paymenttype is not a wirecard payment
        if (!$this->dd_isWirecardPaymentType())  parent::_executeNewAction( $sNewAction );

        // overwrite redirect for IFrame Compatibility
        if ( $sNewAction )
        {
            $myConfig  = $this->getConfig();
            // page parameters is the part which goes after '?'
            $aParams = explode( '?', $sNewAction );
            // action parameters is the part before '?'
            $sPageParams = isset( $aParams[1] )?$aParams[1]:null;
            // looking for function name
            $aParams    = explode( '/', $aParams[0] );
            $sClassName = $aParams[0];
            // building redirect path ...
            $sHeader  = ( $sClassName )?"cl=$sClassName&":'';  // adding view name
            $sHeader .= ( $sPageParams )?"$sPageParams&":'';   // adding page params
            $sHeader .= $this->getSession()->sid();            // adding session Id
            $sUrl = $myConfig->getCurrentShopUrl($this->isAdmin());
            $sUrl = "{$sUrl}index.php?{$sHeader}";
            $sUrl = oxUtilsUrl::getInstance()->processUrl($sUrl);
            // here we changed the Redirect method
            dd_wirecard_utils::getInstance()->dd_wirecardIframeRedirect($sUrl);

            //#M341 do not add redirect parameter
            //oxUtils::getInstance()->redirect( $sUrl, (bool) oxConfig::getParameter( 'redirected' ), 302 );
        }
    }
}