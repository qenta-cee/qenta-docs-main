
package de.hmmh.wirecard.strategies;

import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.order.strategies.CartValidator;
import de.hybris.platform.order.strategies.CreateOrderFromCartStrategy;
import de.hybris.platform.order.strategies.ordercloning.CloneAbstractOrderStrategy;
import de.hybris.platform.servicelayer.keygenerator.KeyGenerator;

import org.apache.log4j.Logger;


/**
 * The CreateOrderFromCartStrategy is needed to set the right (designated)OrderCode from the cart into the new Order.
 * 
 * @author joern.ketelsen
 * 
 */
public class WirecardCreateOrderFromCartStrategy implements CreateOrderFromCartStrategy
{

	private static final Logger LOG = Logger.getLogger(WirecardCreateOrderFromCartStrategy.class);

	private CartValidator cartValidator;
	private CloneAbstractOrderStrategy cloneAbstractOrderStrategy;
	private KeyGenerator keyGenerator;

	/**
	 * Generates a new order code
	 * 
	 * @return the generated code
	 */
	public String generateOrderCode()
	{
		return (String) keyGenerator.generate();
	}

	/**
	 * Creates order from given cart and pregenerated orderCode
	 * 
	 * @param cart
	 * @param orderCode
	 * @return the order model
	 * @throws InvalidCartException
	 */
	public OrderModel createOrderFromCart(final CartModel cart, final String orderCode) throws InvalidCartException
	{

		if (cartValidator != null)
		{
			cartValidator.validateCart(cart);
		}
		LOG.debug("Creating order with given code: " + orderCode);
		final OrderModel res = cloneAbstractOrderStrategy.clone(null, null, cart, orderCode, OrderModel.class,
				OrderEntryModel.class);

		return res;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hybris.platform.order.strategies.CreateOrderFromCartStrategy#
	 * createOrderFromCart(de.hybris.platform.core.model.order.CartModel)
	 */
	@Override
	public OrderModel createOrderFromCart(final CartModel cart) throws InvalidCartException
	{
		if (cartValidator != null)
		{
			cartValidator.validateCart(cart);
		}
		LOG.debug("Creating order with given code: " + cart.getDesignatedOrderCode());
		final OrderModel res = cloneAbstractOrderStrategy.clone(null, null, cart, cart.getDesignatedOrderCode(), OrderModel.class,
				OrderEntryModel.class);

		return res;
	}

	/**
	 * @param cartValidator
	 *           the cartValidator to set
	 */
	public void setCartValidator(final CartValidator cartValidator)
	{
		this.cartValidator = cartValidator;
	}

	/**
	 * @param cloneAbstractOrderStrategy
	 *           the cloneAbstractOrderStrategy to set
	 */
	public void setCloneAbstractOrderStrategy(final CloneAbstractOrderStrategy cloneAbstractOrderStrategy)
	{
		this.cloneAbstractOrderStrategy = cloneAbstractOrderStrategy;
	}

	/**
	 * @param keyGenerator
	 *           the keyGenerator to set
	 */
	public void setKeyGenerator(final KeyGenerator keyGenerator)
	{
		this.keyGenerator = keyGenerator;
	}

}
