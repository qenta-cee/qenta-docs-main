/**
 * 
 */
package de.hmmh.wirecard.methods.impl;



import de.hybris.platform.payment.model.PaymentTransactionModel;

import java.util.Map;

import de.hmmh.wirecard.enums.WirecardPaymentMethodId;


/**
 * The payment method for Paysafecard / Chash-Ticket. Paysafecard is an electronic payment method for predominantly
 * online shopping and is based on a pre-pay system. Paysafecard is based in Vienna, Austria.
 * 
 * @author martin.strube
 * 
 */
public class WirecardPSCPaymentMethod extends AbstractWirecardPaymentMethod
{

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#getMethodId()
	 */
	@Override
	public WirecardPaymentMethodId getMethodId()
	{
		return WirecardPaymentMethodId.PSC;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.hmmh.wirecard.methods.WirecardPaymentMethod#appendMethodSpecificParameter(de.hybris.platform.payment.model.
	 * PaymentTransactionModel, java.lang.StringBuilder, java.util.Map, java.lang.StringBuilder, java.lang.StringBuilder)
	 */
	@Override
	public void appendMethodSpecificParameter(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		// Nothing to do so far

	}


}
