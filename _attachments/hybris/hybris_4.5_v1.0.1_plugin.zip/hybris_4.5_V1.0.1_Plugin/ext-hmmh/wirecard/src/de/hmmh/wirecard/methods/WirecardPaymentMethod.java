
package de.hmmh.wirecard.methods;

import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import de.hmmh.wirecard.enums.WirecardPaymentMethodId;
import de.hmmh.wirecard.model.FinancialInstitutionModel;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;


/**
 * The paymentMethod that should be executed is set up here. Each payment method knows how to handle it's execution. For
 * example creates a redirectURL, post request and so on...
 * 
 * @author Christoph.Meyer
 * 
 */
public interface WirecardPaymentMethod
{

	/**
	 * Returns the ENUM for this payment method defined in the wirecard-items.xml.
	 * 
	 * @return the {@link WirecardPaymentMethodId}
	 */
	public WirecardPaymentMethodId getMethodId();


	/**
	 * Method provided by Wirecard to generate the MD5 Hashsum. The MD5 Hash is used as the requestFingerprint in the
	 * QPay request and response.
	 * 
	 * @param input
	 *           The input String
	 * @return The input String as MD5 HashSum
	 */
	public String calculateMD5Hash(final String input);

	/**
	 * Authorization is done here. That means that the amount of money is only reserved for this customer. Later on it
	 * can be debited. Hence the money is transfered later.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that holds the actual payment transaction.
	 * @param incomingRequest
	 *           The incoming <code>HttpServletRequest</code> from placeOrder().
	 * @return
	 */
	public PaymentTransactionEntryModel authorizePayment(PaymentTransactionModel transaction, HttpServletRequest incomingRequest);

	/**
	 * This method handles the registration of new credit cards. The user registers once its card, gets a userId from the
	 * payment provider for its card and can then reuse it each time he does a payment process without entering the card
	 * information again and again.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that holds the actual payment transaction
	 * @return
	 */
	public PaymentTransactionEntryModel registerPayment(PaymentTransactionModel transaction);

	/**
	 * Fetches the payment configuration for this passed order. Hence the paymentMode that is used for this order.
	 * 
	 * @param order
	 *           The actual {@link AbstractOrderModel} that is used.
	 * @return The {@link WirecardPaymentModeModel} that is used in this transaction.
	 */
	public WirecardPaymentModeModel getConfig(final AbstractOrderModel order);

	/**
	 * When supporting payment methods that use registration the paymentProvider will at some time respond to a
	 * registration with a HTTP POST call.
	 * 
	 * Call this Method to process the response using the received POST parameters.
	 * 
	 * You must supply the current user's payment info to this method, it will be matched to the response.
	 * 
	 * @param postParameters
	 *           parameters sent by paymentProvider via HTTP POST
	 * @param paymentInfo
	 *           give the paymentInfo of current user
	 * @return RequestResult showing succcess oder failure.
	 */
	public PaymentTransactionEntryModel processRegisterResponse(PaymentTransactionModel transaction,
			Map<String, String> postParameters);

	/**
	 * The debit payment does authorization and debit in one step. Hence the money is transfered directly.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that holds the actual payment transaction
	 * @return
	 */
	public PaymentTransactionEntryModel debitPayment(PaymentTransactionModel transaction);

	public PaymentTransactionEntryModel processDebitResponse(PaymentTransactionModel transaction,
			Map<String, String> postParameters);

	public ConfigurationService getConfigurationService();

	/**
	 * Method to create a paymentInfo object filled with payment information gathered from the paymentMode in the order.
	 * 
	 * @param order
	 *           The {@link AbstractOrderModel} holding the necessary information
	 * @return
	 */
	public PaymentInfoModel createPaymentInfo(AbstractOrderModel order);

	/**
	 * Fetches the entry object.
	 * 
	 * @param transactionEntryId
	 *           the id to get the paymentTransactionEntry object
	 * @return The {@link PaymentTransactionEntryModel} object.
	 */
	public PaymentTransactionEntryModel getPaymentTransactionEntry(String transactionEntryId);


	/**
	 * Stores the response parameters in the specific (CreditCard-,.. ) PaymentInfo object.
	 * 
	 * @param parameters
	 *           The responseParameters passed by the payment provider.
	 * @param transactionEntry
	 *           The {@link PaymentTransactionEntryModel} object that holds the transaction information.
	 */
	public void storeResponseParameters(Map<String, String> parameters, PaymentTransactionEntryModel transactionEntry);


	/**
	 * Fetches the FinancialInstitution for its code.
	 * 
	 * @param code
	 *           The code of the FinancialInstitution defined in the impex script.
	 * @return The {@link FinancialInstitutionModel} if available or <code>null</code> if nothing was found.
	 */
	public FinancialInstitutionModel getFinancialInstitutionByCode(String code);


	/**
	 * Implemented by each PaymentMethod in case it needs to append more than the standard parameters to the post
	 * request.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request. This parameter must be set.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here, separated by a comma.
	 */
	public void appendMethodSpecificParameter(PaymentTransactionModel transaction, StringBuilder requestParamsStr,
			Map<String, String> requestParamsMap, StringBuilder requestFingerprintOrder, StringBuilder requestFingerprint);


	/**
	 * This method collects all necessary parameters to fire a qMore DataStorage init post request. After firering the
	 * request it collects its result, persists the dataStorageId into the cartModel and returns the javaScriptUrl.
	 * 
	 * @param cartModel
	 * @return The javascriptUrl.
	 */
	public String initQmoreDataStorage(CartModel cartModel);


	/**
	 * Calculates the SHA-512 digest and returns the value as a String.
	 * 
	 * @param data
	 * @return
	 */
	public String calculateSHA512Hash(String data);


	/**
	 * Checks if qMore is used.
	 * 
	 * @return <b>true</b> is so.
	 */
	public boolean isQmoreEnabled();


	/**
	 * Checks if qPay is used.
	 * 
	 * @return <b>true</b> is so.
	 */
	public boolean isQpayEnabled();

}
