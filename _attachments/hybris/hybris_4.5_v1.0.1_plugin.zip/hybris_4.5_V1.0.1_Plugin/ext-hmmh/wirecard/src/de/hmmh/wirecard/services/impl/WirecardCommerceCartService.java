
package de.hmmh.wirecard.services.impl;

import de.hybris.platform.commerceservices.order.CommerceCartModification;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.commerceservices.order.impl.DefaultCommerceCartService;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.core.model.product.UnitModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.order.exceptions.CalculationException;
import de.hybris.platform.ordersplitting.model.StockLevelModel;

import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.log4j.Logger;


/**
 * We need to lock the cart for the paymentProcess so it can not be manipulated during the process. Due to this new
 * feature we need an own ComerceCartService that checks the lock before CRUD operations on it.
 * 
 * @author Christoph.Meyer
 * 
 */
public class WirecardCommerceCartService extends DefaultCommerceCartService
{

	Logger LOG = Logger.getLogger(WirecardCommerceCartService.class);

	@Override
	public CommerceCartModification addToCart(final CartModel cartModel, final ProductModel productModel, final long quantity,
			final UnitModel unit, final boolean forceNewEntry) throws CommerceCartModificationException
	{
		try
		{
			checkCartLock(cartModel);
		}
		catch (final InvalidCartException e)
		{
			LOG.info("could not add entries, cart is locked for payment!", e);
		}
		return super.addToCart(cartModel, productModel, quantity, unit, forceNewEntry);
	}

	// @Override
	// public long addToCart(final ProductModel productModel, final long
	// quantity, final UnitModel unit, final boolean forceNewEntry) throws
	// InvalidCartException, InsufficientStockLevelException {
	// final CartModel cartModel = getCartService().getSessionCart();
	// checkCartLock(cartModel);
	// return super.addToCart(productModel, quantity, unit, forceNewEntry);
	// }

	@Override
	public boolean calculateCart(final CartModel cartModel)
	{
		return super.calculateCart(cartModel);
	}

	@Override
	public void recalculateCart(final CartModel cartModel) throws CalculationException
	{
		super.recalculateCart(cartModel);
	}

	@Override
	public void removeAllEntries(final CartModel cartModel)
	{
		try
		{
			checkCartLock(cartModel);
			super.removeAllEntries(cartModel);
		}
		catch (final InvalidCartException ex)
		{
			LOG.info("could not remove entries, cart is locked for payment!");
		}
	}

	@Override
	public CommerceCartModification updateQuantityForCartEntry(final CartModel cartModel, final long entryNumber,
			final long newQuantity) throws CommerceCartModificationException
	{
		try
		{
			checkCartLock(cartModel);
			return super.updateQuantityForCartEntry(cartModel, entryNumber, newQuantity);
		}
		catch (final InvalidCartException ex)
		{
			LOG.info("could not update quantities, cart is locked for payment!");
		}
		final AbstractOrderEntryModel entryToUpdate = getEntryForNumber(cartModel, (int) entryNumber);
		return checkStockLevel(entryToUpdate.getProduct(), newQuantity - entryToUpdate.getQuantity().longValue(), cartModel,
				entryToUpdate);
	}

	private void checkCartLock(final CartModel cartModel) throws InvalidCartException
	{
		if (BooleanUtils.isTrue(cartModel.getLocked()))
		{
			throw new InvalidCartException("error.cart.locked.");
		}
	}

	/**
	 * 
	 * @param productModel
	 * @param quantity
	 * @param cartModel
	 * @param orderEntryModel
	 * @return {@link CommerceCartModification}
	 */
	// TODO: check implementation
	private CommerceCartModification checkStockLevel(final ProductModel productModel, final long quantity,
			final CartModel cartModel, final AbstractOrderEntryModel orderEntryModel)
	{
		long stockLevel = 0;
		if (CollectionUtils.isEmpty(getWarehouseService().getDefWarehouse()))
		{
			stockLevel = DefaultCommerceCartService.DEFAULT_FORCE_IN_STOCK_MAX_QUANTITY;
		}
		else
		{
			final Collection<StockLevelModel> stockLevelModels = getStockService().getAllStockLevels(productModel);
			for (final StockLevelModel stockLevelModel : stockLevelModels)
			{
				stockLevel += stockLevelModel.getAvailable();
			}
		}

		final CommerceCartModification modification = new CommerceCartModification();
		modification.setQuantityAdded(0);
		modification.setEntry(orderEntryModel);
		modification.setQuantity(quantity);
		modification.setStatusCode("success");
		if (stockLevel == 0 && quantity > 0)
		{
			modification.setStatusCode("lowStock");
		}

		return modification;
	}

}
