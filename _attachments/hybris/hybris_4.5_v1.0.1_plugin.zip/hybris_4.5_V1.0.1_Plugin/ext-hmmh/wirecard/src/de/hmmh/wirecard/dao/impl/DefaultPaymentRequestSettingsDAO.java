/**
 * 
 */
package de.hmmh.wirecard.dao.impl;

import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

import de.hmmh.wirecard.model.PaymentRequestSettingsModel;


/**
 * The DataAccessObject for the {@link PaymentRequestSettingsModel}.
 * 
 * @author martin.strube
 * 
 */
public class DefaultPaymentRequestSettingsDAO extends DefaultGenericDao<PaymentRequestSettingsModel>
{

	public DefaultPaymentRequestSettingsDAO()
	{
		super(PaymentRequestSettingsModel._TYPECODE);
	}
}
