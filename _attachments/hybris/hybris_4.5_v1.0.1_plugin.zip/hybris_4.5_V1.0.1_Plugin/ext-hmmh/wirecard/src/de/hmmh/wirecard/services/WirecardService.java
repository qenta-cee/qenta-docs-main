
package de.hmmh.wirecard.services;

import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import de.hmmh.wirecard.model.FinancialInstitutionModel;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.strategies.PaymentModeApplicationStrategy;


/**
 * The wirecard service handles all wirecard specific implementation that are requested by the paymentFacade.
 * 
 * @author Christoph.Meyer
 * 
 */
public interface WirecardService
{

	/**
	 * Validates the signature of the passed parameter of the wirecard post response.
	 * 
	 * @param parameters
	 *           A {@link Map} holding all parameters
	 * @return <b>True</b> if ok. Otherwise <b>false</b> is returned.
	 */
	public boolean validateResponseParameters(Map<String, String> parameters);

	/**
	 * returns list of payment modes that are available and valid for current Customer.
	 * 
	 * @return List of Wirecard payment modes.
	 */
	public List<WirecardPaymentModeModel> getPaymentModes();

	/**
	 * returns payment mode by code, regardless of business rules for specific customer
	 * 
	 * @param code
	 * @return
	 */
	public WirecardPaymentModeModel getPaymentMode(String code);

	public PaymentInfoModel getPaymentInfo(String code);

	/**
	 * returns the payment transaction for current payment info. A transaction is specific to the payment info and can
	 * contain several transaction entries (eg. registration, authorize, capture).
	 * 
	 * If current order has no payment transaction for given payment method, or if the existing transaction is not valid
	 * anymore (eg. because of price change after authorize, oder currency change), it created and initializes a new one.
	 * 
	 * @param order
	 * @return
	 */
	// PaymentTransactionModel getCurrentPaymentTransaction(AbstractOrderModel
	// order);

	/**
	 * Business logic to check if given mode is applicable for current user.
	 * 
	 * @param user
	 * @return true if mode is applicable
	 */
	public boolean isPaymentModeApplicable(CartModel cart, WirecardPaymentModeModel paymentMode);

	/**
	 *
	 */
	public String performRegistration(AbstractOrderModel order);

	public PaymentTransactionEntryModel processRegisterResponse(final AbstractOrderModel order,
			final Map<String, String> postParameters);

	/**
	 *
	 */
	public PaymentTransactionEntryModel performAuthorization(AbstractOrderModel order, HttpServletRequest incomingRequest);

	/**
	 *
	 */
	public PaymentTransactionEntryModel performDebit(AbstractOrderModel order);

	/**
	 *
	 */
	public PaymentTransactionEntryModel processDebitAuthorizeResponse(AbstractOrderModel order, Map<String, String> postParameters);

	/**
	 *
	 */
	public PaymentInfoModel createPaymentInfo(AbstractOrderModel order);

	/**
	 * @param transactionEntryId
	 * @return
	 */
	public PaymentTransactionEntryModel getPaymentTransactionEntry(String transactionEntryId);

	/**
	 * Checks the transactionStatus hence the paymentState if it was successful.
	 * 
	 * @param transactionStatus
	 * @return <code>true</code> if so. Otherwise <code>false</code> is returned
	 */
	public boolean isSuccess(String transactionStatus);

	/**
	 * Checks the transactionStatus if the transaction was cancelled by the user.
	 * 
	 * @param transactionStatus
	 * @return <code>true</code> if so. Otherwise <code>false</code> is returned
	 */
	public boolean isCancelled(String transactionStatus);

	/**
	 * Checks the transactionStatus if the transaction has a failure.
	 * 
	 * @param transactionStatus
	 * @return
	 */
	public boolean isFailure(String transactionStatus);

	/**
	 * Checks if the transaction wasn't processed so far.
	 * 
	 * @param transactionStatus
	 * @return
	 */
	public boolean isPending(String transactionStatus);

	public void setPaymentModeApplicationStrategies(final List<PaymentModeApplicationStrategy> paymentModeApplicationStrategies);

	/**
	 * Stores all valid response parameters that are passed in case of paymentState success.
	 * 
	 * @param parameters
	 *           The response parameters as a key, value {@link Map}
	 * @param transactionEntry
	 *           The {@link PaymentTransactionEntryModel}
	 */
	public void storeResponseParametersSuccess(Map<String, String> parameters, PaymentTransactionEntryModel transactionEntry);

	/**
	 * Stores basic response parameters. Hence only the paymentState the response query and a failure message is stored.
	 * These parameters are always transmitted no matter if the response is SUCCESSFUL or not.
	 * 
	 * @param responseParamString
	 *           The response parameters as {@link String}
	 * @param parameters
	 *           The response parameters as a key, value {@link Map}
	 * @param transactionEntry
	 *           The {@link PaymentTransactionEntryModel}
	 */
	public void storeResponseParametersBasic(String responseParamString, Map<String, String> parameters,
			PaymentTransactionEntryModel transactionEntry);

	/**
	 * Fetches the FinancialInstitution for its code.
	 * 
	 * @param code
	 *           The code of the FinancialInstitution defined in the impex script.
	 * @return The {@link FinancialInstitutionModel} if available or <code>null</code> if nothing was found.
	 */
	public FinancialInstitutionModel getFinancialInstitutionByCode(String code);

	/**
	 * Find the {@link CurrencyModel} instance by given code.
	 * 
	 * @param isoCode
	 * @return <code>null</code> if an empty string was passed or nothing was found.
	 */
	public CurrencyModel getCurrency(String isoCode);

	/**
	 * Initializes a wirecard qMore DataStorage session. This session will be valid for 30 minutes. As a result a
	 * javascriptUrl is returned that can be used only for this session
	 * 
	 * @param cartModel
	 *           The users cart.
	 * @return
	 */
	public String initQmoreDataStorage(CartModel cartModel);


}
