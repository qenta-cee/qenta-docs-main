
package de.hmmh.wirecard.strategies;

import de.hybris.platform.core.enums.CreditCardType;


/**
 * @author Christoph.Meyer
 * 
 */
public interface CardBrandNameProviderStrategy
{

	/**
	 * Used to map financial institute parameter from wirecard response to hybris CreditCardType
	 * 
	 * @param wirecardCardBrandName
	 * @return
	 */
	CreditCardType getCreditCardType(String wirecardCardBrandName);

}
