/**
 * 
 */
package de.hmmh.wirecard.methods.impl;

import de.hybris.platform.payment.model.PaymentTransactionModel;

import java.util.Map;

import de.hmmh.wirecard.enums.WirecardPaymentMethodId;


/**
 * The payment method for Giropay. Giropay is an Internet payment System in Germany, based on online banking.
 * 
 * @author martin.strube
 * 
 */
public class WirecardGIROPAYPaymentMethod extends AbstractWirecardPaymentMethod
{

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#getMethodId()
	 */
	@Override
	public WirecardPaymentMethodId getMethodId()
	{
		return WirecardPaymentMethodId.GIROPAY;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.hmmh.wirecard.methods.WirecardPaymentMethod#appendMethodSpecificParameter(de.hybris.platform.payment.model.
	 * PaymentTransactionModel, java.lang.StringBuilder, java.util.Map, java.lang.StringBuilder, java.lang.StringBuilder)
	 */
	@Override
	public void appendMethodSpecificParameter(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		// Nothing to do so far

	}

}
