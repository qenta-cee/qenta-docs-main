
package de.hmmh.wirecard.dao.impl;

import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

/**
 * @author Christoph.Meyer
 *
 */
public class DefaultWirecardPaymentInfoDAO extends DefaultGenericDao<PaymentInfoModel> {

	public DefaultWirecardPaymentInfoDAO() {
		super(PaymentInfoModel._TYPECODE);
	}
}
