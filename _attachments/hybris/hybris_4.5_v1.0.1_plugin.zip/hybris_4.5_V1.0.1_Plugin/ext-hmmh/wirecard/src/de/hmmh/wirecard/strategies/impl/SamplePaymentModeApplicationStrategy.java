
package de.hmmh.wirecard.strategies.impl;

import de.hybris.platform.core.model.order.CartModel;

import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.strategies.PaymentModeApplicationStrategy;


/**
 * @author Christoph.Meyer
 * 
 *         Sample/Default implementation with minimal risk management: Invoice is only allowed when payment and delivery
 *         address are the same.
 * 
 */
public class SamplePaymentModeApplicationStrategy implements PaymentModeApplicationStrategy
{

	@Override
	public boolean isPaymentModeApplicable(final CartModel cart, final WirecardPaymentModeModel paymentMode)
	{

		/*
		 * if (WirecardPaymentMethodId.IV.equals(paymentMode.getWirecardPaymentMethodId())) { return
		 * cart.getDeliveryAddress().equals(cart.getPaymentAddress()); }
		 */

		return true;
	}
}
