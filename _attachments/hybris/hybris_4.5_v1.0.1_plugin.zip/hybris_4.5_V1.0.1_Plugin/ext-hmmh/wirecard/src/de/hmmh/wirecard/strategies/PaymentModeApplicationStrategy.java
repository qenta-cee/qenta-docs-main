
package de.hmmh.wirecard.strategies;

import de.hybris.platform.core.model.order.CartModel;

import de.hmmh.wirecard.model.WirecardPaymentModeModel;


/**
 * @author Christoph.Meyer
 * 
 */
public interface PaymentModeApplicationStrategy
{

	boolean isPaymentModeApplicable(CartModel cart, WirecardPaymentModeModel paymentMode);

}
