
package de.hmmh.wirecard.methods.impl;

import de.hybris.platform.core.enums.CreditCardType;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.payment.CreditCardPaymentInfoModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;

import java.util.Map;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang.StringUtils;

import de.hmmh.wirecard.constants.WirecardConstants.ResponseParams;
import de.hmmh.wirecard.exception.WirecardException;
import de.hmmh.wirecard.model.FinancialInstitutionModel;


/**
 * @author Christoph.Meyer
 * 
 */
public abstract class AbstractWirecardCardPaymentMethod extends AbstractWirecardPaymentMethod
{



	@Override
	public PaymentTransactionEntryModel debitPayment(final PaymentTransactionModel transaction)
	{
		throw new WirecardException("Debit payment is not implemented...");
	}

	@Override
	public PaymentTransactionEntryModel processRegisterResponse(final PaymentTransactionModel transaction,
			final Map<String, String> postParameters)
	{
		throw new NotImplementedException("Method processRegisterResponse is not implement in payment wirecard");
	}

	@Override
	public PaymentTransactionEntryModel processDebitResponse(final PaymentTransactionModel transaction,
			final Map<String, String> postParameters)
	{
		throw new NotImplementedException("Method processDebitResponse is not implement in payment wirecard");

		//		final PaymentTransactionEntryModel entry = findTransactionEntry(transaction, postParameters);
		//		processBasicResponse(entry, postParameters);
		//		processAccountResponse(entry, postParameters);
		//		processAddressResponse(entry, postParameters);
		//		return entry;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#storeResponseParameters(java.util.Map,
	 * de.hybris.platform.payment.model.PaymentTransactionEntryModel)
	 */
	@Override
	public void storeResponseParameters(final Map<String, String> parameters, final PaymentTransactionEntryModel transactionEntry)
	{
		final CreditCardPaymentInfoModel paymentInfo = (CreditCardPaymentInfoModel) this.getTransactionPaymentInfo(transactionEntry
				.getPaymentTransaction());

		// store basic attributes
		storeBasicResponseParameters(parameters, transactionEntry);

		// store CreditCardPaymenInfo specific attributes
		final String anonymusPan = parameters.get(ResponseParams.ANONYMOUS_PAN);
		if (!StringUtils.isEmpty(anonymusPan))
		{
			paymentInfo.setAnonymousPan(anonymusPan);
		}
		String maskedPan = parameters.get(ResponseParams.MASKED_PAN);
		// maskedPAN is mandatory in paymentInfo. So if its not provided we use the anonymousPAN
		maskedPan = StringUtils.defaultIfEmpty(maskedPan, "**********" + anonymusPan);
		if (!StringUtils.isEmpty(maskedPan))
		{
			paymentInfo.setNumber(maskedPan);
		}
		// set type of CreditCard
		final String financialInstitutionStr = parameters.get(ResponseParams.FINANCIAL_INSTITUTION);
		if (!StringUtils.isEmpty(financialInstitutionStr))
		{
			final FinancialInstitutionModel financialInstitution = getFinancialInstitutionByCode(financialInstitutionStr);
			paymentInfo.setFinancialInstitution(financialInstitution);
			final CreditCardType creditCardType = cardBrandNameProviderStrategy.getCreditCardType(financialInstitutionStr);
			paymentInfo.setType(creditCardType);
		}
		String owner = parameters.get(ResponseParams.CARDHOLDER);
		// ccOwner is mandatory in paymentInfo. If not set we provide a default customer name
		owner = StringUtils.defaultIfEmpty(owner, "unknown");
		paymentInfo.setCcOwner(owner);
		final String authenticated = parameters.get(ResponseParams.AUTHENTICATED);
		if (StringUtils.isNotEmpty(authenticated))
		{
			// only set if value was transmitted
			paymentInfo.setAuthenticated(BooleanUtils.toBoolean(authenticated));
		}

		final String expiry = parameters.get(ResponseParams.EXPIRY);
		if (StringUtils.isNotEmpty(expiry))
		{
			final String month = expiry.substring(0, 2);
			final String year = expiry.substring(3, 7);
			paymentInfo.setValidToMonth(month);
			paymentInfo.setValidToYear(year);
		}

		modelService.save(paymentInfo);
	}

	@Override
	public PaymentInfoModel createPaymentInfo(final AbstractOrderModel order)
	{
		final CreditCardPaymentInfoModel paymentInfo = createBasicPaymentInfo(order, CreditCardPaymentInfoModel.class);
		fillBlankData(paymentInfo);
		return paymentInfo;
	}

	/**
	 * Fills in blank data
	 * 
	 * @param paymentInfo
	 */
	protected void fillBlankData(final CreditCardPaymentInfoModel paymentInfo)
	{
		paymentInfo.setCcOwner("--");
		paymentInfo.setNumber("--");
		paymentInfo.setType(CreditCardType.UNKNOWN);
		paymentInfo.setValidToMonth("--");
		paymentInfo.setValidToYear("--");
		modelService.save(paymentInfo);
	}

	@Override
	public void appendMethodSpecificParameter(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		// nothing to do here here 
	}


}