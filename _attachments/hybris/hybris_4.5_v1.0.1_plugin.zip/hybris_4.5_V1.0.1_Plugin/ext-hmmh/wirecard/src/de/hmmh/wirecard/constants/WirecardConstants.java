/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hmmh.wirecard.constants;

import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.util.Locale;


/**
 * Global class for all Wirecard constants. You can add global constants for your extension into this class.
 */
public final class WirecardConstants extends GeneratedWirecardConstants
{
	public static final String EXTENSIONNAME = "wirecard";
	public static final Locale LOCAL_DEFAULT = Locale.ENGLISH;

	private static final int ONE_SECOND_IN_MILLISECONDS = 1000;
	/**
	 * Determines the timeout in milliseconds until a connection is established. A timeout value of zero is interpreted
	 * as an infinite timeout.
	 */
	public static final int HTTP_CLIENT_CONNECTION_TIMEOUT = 5 * ONE_SECOND_IN_MILLISECONDS;

	/**
	 * Defines the socket timeout in milliseconds, which is the timeout for waiting for data. A timeout value of zero is
	 * interpreted as an infinite timeout.
	 */
	public static final int HTTP_CLIENT_SOCKET_TIMEOUT = 10 * ONE_SECOND_IN_MILLISECONDS;


	@SuppressWarnings("deprecation")
	private WirecardConstants()
	{
		super();
		assert false;
	}

	public static class TransactionStatus
	{
		public static final String ACK = "ACK";
		public static final String NOK = "NOK";

		private TransactionStatus()
		{
			assert false;
		}
	}

	public static class HeaderParams
	{
		public static final String USER_AGENT = "User-Agent";

		private HeaderParams()
		{
			assert false;
		}
	}

	/**
	 * Parameter name constants that are used in the wirecard request.
	 * 
	 * @author martin.strube
	 * 
	 */
	public static class RequestParams
	{


		// qPay and qMore parameters
		public static final String SECRET = "secret";
		public static final String CUSTOMER_ID = "customerId";
		public static final String SHOP_ID = "shopId";
		public static final String AMOUNT = "amount";
		public static final String CURRENCY = "currency";
		public static final String PAYMENT_TYPE = "paymentType";
		public static final String FINANCIAL_INSTITUTION = "financialInstitution";
		public static final String LANGUAGE = "language";
		public static final String ORDER_DESCRIPTION = "orderDescription";
		public static final String DISPLAY_TEXT = "displayText";
		public static final String SUCCESS_URL = "successUrl";
		public static final String CANCEL_URL = "cancelUrl";
		public static final String FAILURE_URL = "failureUrl";
		public static final String CONFIRM_URL = "confirmUrl";
		public static final String IMAGE_URL = "imageUrl";
		public static final String SERVICE_URL = "serviceUrl";
		public static final String REQUEST_FINGERPRINT_ORDER = "requestFingerprintOrder";
		public static final String REQUEST_FINGERPRINT = "requestFingerprint";
		public static final String WINDOW_NAME = "windowName";
		public static final String DUPLICATE_REQUEST_CHECK = "duplicateRequestCheck";
		public static final String CUSTOMER_STATEMENT = "customerStatement";
		public static final String ORDER_REFERENCE = "orderReference";
		public static final String AUTO_DEPOSIT = "autoDeposit";
		public static final String MAX_RETRIES = "maxRetries";
		public static final String ORDER_NUMBER = "orderNumber";
		public static final String CONFIRM_MAIL = "confirmMail";
		public static final String PAYMENT_TRANSACTION_CODE = "paymentTransactionCode";

		// Parameters used only by QMORE
		/** unique identifier for the users order */
		public static final String ORDER_IDENT = "orderIdent";
		/** returnURL for legacy browser */
		public static final String CORS_RETURN_URL = "returnUrl";
		/** Identifier for wirecard which version of JavaScrip should be provided for the dataStroage system. */
		public static final String JAVA_SCRIPT_VERSION = "javascriptScriptVersion";
		public static final String NOSCRIPT_INFO_URL = "noscriptInfoUrl";
		public static final String DATA_STORAGE_ID = "storageId";
		public static final String CONSUMER_USER_AGENT = "consumerUserAgent";
		public static final String CONSUMER_IP_ADDRESS = "consumerIpAddress";


		private RequestParams()
		{
			assert false;
		}
	}

	/**
	 * Parameter name constants that are used in the wirecard response.
	 * 
	 * @author martin.strube
	 * 
	 */
	public static class ResponseParams
	{

		// QPay response parameter

		/**
		 * The paymentState defines the result of the payment process from wirecard. Its values are defined in the Class
		 * <code>PaymentState</code>.
		 */
		public static final String PAYMENT_STATE = "paymentState";
		// same parameters as in Request
		public static final String PAYMENT_TRANSACTION_CODE = RequestParams.PAYMENT_TRANSACTION_CODE;
		public static final String SECRET = RequestParams.SECRET;
		public static final String AMOUNT = RequestParams.AMOUNT;
		public static final String CURRENCY = RequestParams.CURRENCY;
		public static final String PAYMENT_TYPE = RequestParams.PAYMENT_TYPE;
		public static final String FINANCIAL_INSTITUTION = RequestParams.FINANCIAL_INSTITUTION;
		public static final String LANGUAGE = RequestParams.LANGUAGE;
		public static final String ORDER_NUMBER = RequestParams.ORDER_NUMBER;
		/** Fingerabdruck der Rueckgabe Parameter */
		public static final String RESPONSE_FINGERPRINT = "responseFingerprint";
		/** Aufzaehlung der f�r den Fingerprint verwendeten Parameter */
		public static final String RESPONSE_FINGERPRINT_ORDER = "responseFingerprintOrder";
		/** Die letzten vier Stellen der Kartennummer (nur bei Kreditkartentransaktionen) */
		public static final String ANONYMOUS_PAN = "anonymousPan";
		/** Hat sich der Karteninhaber erfolgreich authentifiziert? */
		public static final String AUTHENTICATED = "authenticated";
		/** Error text in case of PaymentState=Failure */
		public static final String MESSAGE = "message";
		/** Ablaufdatum der Kreditkarte im Format: mm/yyyy */
		public static final String EXPIRY = "expiry";
		/** Name des Karteninhabers Kann nur aktiviert werden, wenn Prozessor/Acquirer es fordern */
		public static final String CARDHOLDER = "cardholder";

		/**
		 * PCI-konforme maskierte Kartennummer Format: ersten 6 Stellen + letzen 4 Stellen der Kartennummer, dazwischen *
		 * (je nach tatsaechlicher Laenge der Kartennummer )
		 */
		public static final String MASKED_PAN = "maskedPan";
		public static final String GATEWAY_REFERENCE_NUMBER = "gatewayReferenceNumber";
		public static final String GATEWAY_CONTRACT_NUMBER = "gatewayContractNumber";
		public static final String IDEAL_CONSUMER_NAME = "idealConsumerName";
		public static final String IDEAL_CONSUMER_CITY = "idealConsumerCity";
		public static final String IDEAL_CONSUMER_ACCOUNT_NUMBER = "idealConsumerAccountNumber";
		public static final String PAYPAL_PAYER_ID = "paypalPayerID";
		public static final String PAYPAL_PAYER_EMAIL = "paypalPayerEmail";
		public static final String PAYPAL_PAYER_LAST_NAME = "paypalPayerLastName";
		public static final String PAYPAL_PAYER_FIRST_NAME = "paypalPayerFirstName";
		public static final String SENDER_ACCOUNT_OWNER = "senderAccountOwner";
		public static final String SENDER_ACCOUNT_NUMBER = "senderAccountNumber";
		public static final String SENDER_BANK_NUMBER = "senderBankNumber";
		public static final String SENDER_BANK_NAME = "senderBankName";
		public static final String SENDER_BIC = "senderBIC";
		public static final String SENDER_IBAN = "senderIBAN";
		public static final String SENDER_COUNTRY = "senderCountry";
		public static final String SECURITY_CRITERIA = "securityCriteria";

		// QMORE response parameter
		public static final String JAVASCRIPT_URL = "javascriptUrl";
		public static final String REDIRECT_URL = "redirectUrl";
		public static final String DATA_STORAGE_ID = RequestParams.DATA_STORAGE_ID;
		/** Number of errors returned from QMORE */
		public static final String ERRORS = "errors";
		public static final String ERROR_CODE_PLACEHOLDER = "error.<n>.errorCode";
		public static final String ERROR_MESSAGE_PLACEHOLDER = "error.<n>.message";
		public static final String PAYMENT_SYSTEM_MESSAGE_PLACEHOLDER = "error.<n>.paySysMessage";

		public static final String ERROR_PLACEHOLDER_KEY = "<n>";

		public static final String CARDHOLDERNAME = "cardholdername";
		public static final String EXPECTEDDATEFORMAT = "MM/YYYY";
		public static final String BRAND = "brand";
		public static final String BANKNAME = "bankName";
		public static final String BANKCOUNTRY = "bankCountry";
		public static final String ACCOUNTOWNER = "accountOwner";
		public static final String BANKACCOUNT = "bankAccount";
		public static final String BANKNUMBER = "bankNumber";
		public static final String BANKBIC = "bankBic";
		public static final String BANKACCOUNTIBAN = "bankAccountIban";
		public static final String PAYBOXNUMBER = "payerPayboxNumber";
		public static final String USERNAME = "username";
		public static final String PAN = "pan";



		private ResponseParams()
		{
			assert false;
		}
	}

	/**
	 * The paymentState defines the result of the payment process from wirecard. The paymentState is send as parameter in
	 * the confirmURL, successURL, failureURL and cancelURL.
	 * 
	 * @author martin.strube
	 * 
	 */
	public static class PaymentState
	{
		/** Status for failure during payment. */
		public static final String FAILURE = "FAILURE".intern();
		/** Status for successfully processed payment. */
		public static final String SUCCESS = "SUCCESS".intern();
		/** Status for user cancelled the payment. */
		public static final String CANCEL = "CANCEL".intern();
		/** Status for payments without a response from the paymentProvider. */
		public static final String PENDING = "PENDING".intern();
	}


	/**
	 * Class that holds keys for constants that can be accessed via the hybris {@link ConfigurationService}.
	 * 
	 * @author martin.strube
	 * 
	 */
	public static class ConfigParams
	{

		public static final String QMORE_ENABLED = "wirecard.qmore.enabled";
		public static final String SECRET = "wirecard.secret";
		public static final String CUSTOMER_ID = "wirecard.customer.id";
		public static final String SHOP_ID = "wirecard.shop.id";
		public static final String QPAY_INIT_URL = "wirecard.qpay.init.url";
		public static final String RESPONSE_URL_CONFIRM = "wirecard.response.url.confirm";
		public static final String RESPONSE_URL_CANCEL = "wirecard.response.url.cancel";
		public static final String RESPONSE_URL_FAILURE = "wirecard.response.url.failure";
		public static final String BASE_URL_SERVICE = "wirecard.response.url.service";
		public static final String RESPONSE_URL_SUCCESS = "wirecard.response.url.success";
		public static final String FRONTEND_CSS_PATH = "wirecard.frontend.css.path";
		public static final String CORS_RETURN_URL = "wirecard.qmore.cors.return.url";
		public static final String QMORE_DATASTORAGE_INIT_URL = "wirecard.qmore.datastorage.init.url";
		public static final String QMORE_FRONTEND_INIT_URL = "wirecard.qmore.frontend.inti.url";

		private ConfigParams()
		{
			assert false;
		}
	}

}
