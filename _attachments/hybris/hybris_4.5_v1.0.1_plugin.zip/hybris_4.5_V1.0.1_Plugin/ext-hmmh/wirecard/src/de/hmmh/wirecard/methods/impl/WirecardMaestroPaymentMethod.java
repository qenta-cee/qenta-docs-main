/**
 * 
 */
package de.hmmh.wirecard.methods.impl;

import de.hybris.platform.payment.model.PaymentTransactionModel;

import java.util.Map;

import de.hmmh.wirecard.enums.WirecardPaymentMethodId;


/**
 * The payment method for Maestro SecureCode. Maestro is a multi-national debit card service owned by MasterCard.
 * Maestro cards are obtained from associate banks and can be linked to the card holder's current account, or they can
 * be prepaid cards.
 * 
 * @author martin.strube
 * 
 */
public class WirecardMaestroPaymentMethod extends AbstractWirecardCardPaymentMethod
{

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#getMethodId()
	 */
	@Override
	public WirecardPaymentMethodId getMethodId()
	{
		return WirecardPaymentMethodId.MAESTRO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.hmmh.wirecard.methods.WirecardPaymentMethod#appendMethodSpecificParameter(de.hybris.platform.payment.model.
	 * PaymentTransactionModel, java.lang.StringBuilder, java.util.Map, java.lang.StringBuilder, java.lang.StringBuilder)
	 */
	@Override
	public void appendMethodSpecificParameter(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		// Nothing to do so far
	}

}
