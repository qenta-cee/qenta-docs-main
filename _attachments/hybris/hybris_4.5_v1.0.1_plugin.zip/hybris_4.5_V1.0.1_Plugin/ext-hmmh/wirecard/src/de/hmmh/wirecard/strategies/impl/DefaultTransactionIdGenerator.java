
package de.hmmh.wirecard.strategies.impl;

import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;

import de.hmmh.wirecard.strategies.TransactionIdGenerator;

/**
 * @author Christoph.Meyer
 * 
 */
public class DefaultTransactionIdGenerator implements TransactionIdGenerator {

	@Override
	public String getTransactionEntryId(final PaymentTransactionModel transaction) {
		final String size = transaction.getEntries() == null ? "1" : String.valueOf(transaction.getEntries().size() + 1);
		return new StringBuilder(transaction.getOrder().getCode()).append('-').append(size).append('-').append(System.currentTimeMillis()).toString();
	}

	@Override
	public String getTransactionId(final AbstractOrderModel order) {
		return "transaction-" + order.getCode() + "-" + System.currentTimeMillis();
	}
}
