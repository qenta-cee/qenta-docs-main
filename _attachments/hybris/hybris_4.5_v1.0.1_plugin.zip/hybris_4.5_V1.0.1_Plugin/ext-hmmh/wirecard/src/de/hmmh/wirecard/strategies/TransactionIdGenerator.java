
package de.hmmh.wirecard.strategies;

import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;

/**
 * @author Christoph.Meyer
 * 
 */
public interface TransactionIdGenerator {

	String getTransactionEntryId(PaymentTransactionModel transaction);

	String getTransactionId(AbstractOrderModel order);

}
