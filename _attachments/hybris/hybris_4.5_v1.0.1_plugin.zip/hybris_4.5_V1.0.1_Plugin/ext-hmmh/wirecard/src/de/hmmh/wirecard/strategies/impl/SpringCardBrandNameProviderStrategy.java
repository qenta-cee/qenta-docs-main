
package de.hmmh.wirecard.strategies.impl;

import de.hybris.platform.core.enums.CreditCardType;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import de.hmmh.wirecard.strategies.CardBrandNameProviderStrategy;

/**
 * @author Christoph.Meyer
 * 
 */
public class SpringCardBrandNameProviderStrategy implements CardBrandNameProviderStrategy {

	private static final Logger LOG = Logger.getLogger(SpringCardBrandNameProviderStrategy.class);

	private Map<String, String> wirecard2HybrisCodes;

	public Map<String, String> getWirecard2HybrisCodes() {
		return wirecard2HybrisCodes;
	}

	public void setWirecard2HybrisCodes(final Map<String, String> wirecard2HybrisCodes) {
		this.wirecard2HybrisCodes = wirecard2HybrisCodes;
	}

	@Override
	public CreditCardType getCreditCardType(final String wirecardCardBrandName) {

		CreditCardType result = CreditCardType.UNKNOWN;

		result = getCardBrandByName(wirecardCardBrandName);

		if (result == CreditCardType.UNKNOWN && wirecard2HybrisCodes != null) {
			final String name = wirecard2HybrisCodes.get(wirecardCardBrandName);
			if (name != null) {
				result = getCardBrandByName(name);
			}
		}

		if (result == CreditCardType.UNKNOWN) {
			for (final Map.Entry<String, String> entry : wirecard2HybrisCodes.entrySet()) {
				if (StringUtils.equalsIgnoreCase(wirecardCardBrandName, entry.getKey())) {
					try {
						result = CreditCardType.valueOf(entry.getValue());
						break;
					} catch (final IllegalArgumentException ex) {
						result = CreditCardType.UNKNOWN;
						LOG.debug("Unknown card type! ", ex);
					}
				}
			}
		}
		return result;
	}

	/**
	 * @param wirecardCardBrandName
	 * @return
	 */
	protected CreditCardType getCardBrandByName(final String wirecardCardBrandName) {
		CreditCardType result;
		try {
			result = CreditCardType.valueOf(wirecardCardBrandName);
		} catch (final IllegalArgumentException ex) {
			result = CreditCardType.UNKNOWN;
			LOG.debug("Unknown card type! ", ex);
		}
		return result;
	}
}
