/**
 * 
 */
package de.hmmh.wirecard.methods.impl;



import de.hmmh.wirecard.enums.WirecardPaymentMethodId;


/**
 * Credit card payment (inclusive "Verified by Visa" and "MasterCard SecureCode")
 * 
 * @author martin.strube
 * 
 */
public class WirecardCCardPaymentMethod extends AbstractWirecardCardPaymentMethod
{

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#getMethodId()
	 */
	@Override
	public WirecardPaymentMethodId getMethodId()
	{
		return WirecardPaymentMethodId.CCARD;
	}

}
