/**
 * 
 */
package de.hmmh.wirecard.dao.impl;

import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

import de.hmmh.wirecard.model.FinancialInstitutionModel;


/**
 * The DataAccessObject for the {@link FinancialInstitutionModel}.
 * 
 * @author martin.strube
 * 
 */
public class DefaultFinancialInstitutionDao extends DefaultGenericDao<FinancialInstitutionModel>
{

	public DefaultFinancialInstitutionDao()
	{
		super(FinancialInstitutionModel._TYPECODE);
	}
}
