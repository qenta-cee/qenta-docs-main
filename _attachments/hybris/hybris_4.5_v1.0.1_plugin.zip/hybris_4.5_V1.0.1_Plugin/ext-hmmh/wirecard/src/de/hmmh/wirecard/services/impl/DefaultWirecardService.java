
package de.hmmh.wirecard.services.impl;

import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.payment.enums.PaymentTransactionType;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.i18n.daos.impl.DefaultCurrencyDao;
import de.hybris.platform.servicelayer.internal.service.AbstractBusinessService;
import de.hybris.platform.servicelayer.model.ModelService;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import de.hmmh.wirecard.constants.WirecardConstants;
import de.hmmh.wirecard.constants.WirecardConstants.ConfigParams;
import de.hmmh.wirecard.constants.WirecardConstants.PaymentState;
import de.hmmh.wirecard.constants.WirecardConstants.ResponseParams;
import de.hmmh.wirecard.constants.WirecardConstants.TransactionStatus;
import de.hmmh.wirecard.dao.impl.DefaultFinancialInstitutionDao;
import de.hmmh.wirecard.dao.impl.DefaultPaymentRequestSettingsDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentInfoDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentModeDAO;
import de.hmmh.wirecard.enums.WirecardPaymentMethodId;
import de.hmmh.wirecard.exception.WirecardException;
import de.hmmh.wirecard.methods.WirecardPaymentMethod;
import de.hmmh.wirecard.model.FinancialInstitutionModel;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.services.WirecardService;
import de.hmmh.wirecard.strategies.PaymentModeApplicationStrategy;
import de.hmmh.wirecard.strategies.TransactionIdGenerator;


/**
 * The default implementation of the WirecardService.
 * 
 * @author Christoph.Meyer
 * 
 */
public class DefaultWirecardService extends AbstractBusinessService implements WirecardService
{

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = Logger.getLogger(DefaultWirecardService.class);

	private transient DefaultWirecardPaymentInfoDAO wirecardPaymentInfoDao;
	protected transient DefaultWirecardPaymentModeDAO paymentModeDao;
	private transient DefaultFinancialInstitutionDao financialInstitutionDao;
	private transient DefaultPaymentRequestSettingsDAO paymentRequestSettingsDAO;

	private Map<String, WirecardPaymentMethod> methods;
	private transient List<PaymentModeApplicationStrategy> paymentModeApplicationStrategies;
	protected transient TransactionIdGenerator transactionIdGenerator;
	protected ConfigurationService configurationService;
	private transient DefaultCurrencyDao currencyDao;

	/**
	 * @return the configurationService
	 */
	public ConfigurationService getConfigurationService()
	{
		return configurationService;
	}

	/**
	 * @param configurationService
	 *           the configurationService to set
	 */
	public void setConfigurationService(final ConfigurationService configurationService)
	{
		this.configurationService = configurationService;
	}

	/**
	 * Fetches the paymentMethod by its PaymentMethodId
	 * 
	 * @param id
	 * @return
	 */
	private WirecardPaymentMethod getMethod(final WirecardPaymentMethodId id)
	{
		return getPaymentMethodByCode(id.getCode());
	}

	/**
	 * Fetches the right paymentMethod by its code.
	 * 
	 * @param code
	 * @return
	 */
	private WirecardPaymentMethod getPaymentMethodByCode(final String code)
	{
		final WirecardPaymentMethod method = methods.get(code);
		if (method == null)
		{
			throw new WirecardException("No Method defined for id " + code);
		}
		return method;
	}

	@Override
	public String performRegistration(final AbstractOrderModel order)
	{
		throw new NotImplementedException("Method performRegistration is not implemented for wirecard");
	}

	@Override
	public PaymentTransactionEntryModel processRegisterResponse(final AbstractOrderModel order,
			final Map<String, String> postParameters)
	{
		throw new NotImplementedException("Method processRegisterResponse is not implemented for wirecard");
	}

	@Override
	public PaymentTransactionEntryModel performAuthorization(final AbstractOrderModel order,
			final HttpServletRequest incomingRequest)
	{
		final WirecardPaymentModeModel paymentMode = (WirecardPaymentModeModel) order.getPaymentMode();
		final WirecardPaymentMethod method = getMethod(paymentMode.getWirecardPaymentMethodId());
		final PaymentTransactionModel transaction = createPaymentTransaction(order);
		return method.authorizePayment(transaction, incomingRequest);
	}

	@Override
	public PaymentTransactionEntryModel performDebit(final AbstractOrderModel order)
	{
		throw new NotImplementedException("Method performDebit is not implemented for wirecard");
	}

	@Override
	public PaymentTransactionEntryModel processDebitAuthorizeResponse(final AbstractOrderModel order,
			final Map<String, String> postParameters)
	{

		throw new NotImplementedException("Method processDebitAuthorizeResponse is not implemented for wirecard");

		//		final PaymentTransactionModel transaction = getPaymentTransactionForOrder(order, postParameters);
		//		if (transaction == null)
		//		{
		//			throw new WirecardException("Cannot find transaction for order");
		//		}
		//		final WirecardPaymentMethod method = getMethod(transaction.getInfo().getPaymentType());
		//		return method.processDebitResponse(transaction, postParameters);
	}

	/**
	 * use this to retrieve a payment info model for given cart and payment mode from an existing transaction.
	 * 
	 * @param order
	 * @param newPaymentMode
	 * @return
	 */
	@Deprecated
	public PaymentInfoModel getTransactionPaymentInfo(final AbstractOrderModel order, final WirecardPaymentModeModel newPaymentMode)
	{

		PaymentInfoModel paymentInfo = null;

		// check for every transaction if it is still valid for this cart, and
		// if its payment mode is the one we need:
		if (order.getPaymentTransactions() != null)
		{
			for (final PaymentTransactionModel transaction : order.getPaymentTransactions())
			{
				if (isTransactionValidForOrder(transaction, order))
				{
					if (transaction.getInfo().getPaymentType().equals(newPaymentMode.getWirecardPaymentMethodId()))
					{
						paymentInfo = transaction.getInfo();
					}
				}
			}
		}
		return paymentInfo;
	}

	public String getTypeCodeForPaymentInfo(final WirecardPaymentModeModel paymentMode)
	{
		return paymentMode.getPaymentInfoType().getCode();
	}

	/**
	 * checks if the transaction is still valid.
	 * 
	 * It is still valid, if user, currency, and amount are the same as in the order.
	 * 
	 * it is still valid, if the amount in the order has changed, but no authorization has been done yet in the order.
	 * 
	 * it is not valid anymore, if user or currency changed, or if the amount changed after an authorization.
	 * 
	 * 
	 * @param transaction
	 * @param order
	 * @return
	 */
	@Deprecated
	private boolean isTransactionValidForOrder(final PaymentTransactionModel transaction, final AbstractOrderModel order)
	{
		final BigDecimal orderamount = new BigDecimal(order.getTotalPrice().doubleValue());
		if (transaction.getPlannedAmount() == null)
		{
			LOG.info("transaction " + transaction.getCode() + " amount is " + transaction.getPlannedAmount() + ", order amount is "
					+ order.getTotalPrice());
			return false;
		}
		if (transaction.getPlannedAmount().compareTo(orderamount) != 0)
		{
			// need to check if there was a successful debit/authorize already:
			if (transaction.getEntries() != null)
			{
				for (final PaymentTransactionEntryModel entry : transaction.getEntries())
				{
					if (PaymentTransactionType.AUTHORIZATION.equals(entry.getType())
							|| PaymentTransactionType.DEBIT.equals(entry.getType()))
					{
						if (TransactionStatus.ACK.equals(entry.getTransactionStatus()))
						{
							LOG.info("transaction " + transaction.getCode() + " already has Debit/Auth with result ACK!");
							return false;
						}
					}
				}
			}
		}
		return checkCurrency(transaction, order);
	}

	/**
	 * @param transaction
	 * @param order
	 * @return
	 */
	protected boolean checkCurrency(final PaymentTransactionModel transaction, final AbstractOrderModel order)
	{
		if (transaction.getCurrency() == null || !transaction.getCurrency().equals(order.getCurrency()))
		{
			LOG.info("transaction " + transaction.getCode() + " does not match cart currency");
			return false;
		}
		return true;
	}

	/**
	 * creates new payment transaction for given order.
	 */
	private PaymentTransactionModel createPaymentTransaction(final AbstractOrderModel order)
	{

		if (order.getPaymentInfo() == null)
		{
			throw new WirecardException("paymentinfo in cart must not be null");
		}

		final PaymentTransactionModel currentTransaction = getModelService().create(PaymentTransactionModel.class);

		currentTransaction.setCode(transactionIdGenerator.getTransactionId(order));
		currentTransaction.setInfo(order.getPaymentInfo());
		currentTransaction.setOrder(order);
		currentTransaction.setCurrency(order.getCurrency());
		currentTransaction.setPlannedAmount(new BigDecimal(order.getTotalPrice().doubleValue()));
		getModelService().save(currentTransaction);
		return currentTransaction;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.services.WirecardService#initQmoreDataStorage(de.hybris.platform.core.model.order.CartModel,
	 * java.lang.String)
	 */
	@Override
	public String initQmoreDataStorage(final CartModel cartModel)
	{
		final String javaScriptUrl = getMiscPaymentMethod().initQmoreDataStorage(cartModel);
		return javaScriptUrl;
	}

	@Override
	public boolean isPaymentModeApplicable(final CartModel cart, final WirecardPaymentModeModel paymentMode)
	{
		if (paymentModeApplicationStrategies != null)
		{
			for (final PaymentModeApplicationStrategy strategy : paymentModeApplicationStrategies)
			{
				if (!strategy.isPaymentModeApplicable(cart, paymentMode))
				{
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public List<WirecardPaymentModeModel> getPaymentModes()
	{
		final List<WirecardPaymentModeModel> modes = paymentModeDao.find(Collections.singletonMap("active", Boolean.TRUE));
		return modes == null ? Collections.EMPTY_LIST : modes;
	}



	@Override
	public WirecardPaymentModeModel getPaymentMode(final String code)
	{
		if (code == null)
		{
			return null;
		}
		final List<WirecardPaymentModeModel> modes = paymentModeDao.find(Collections.singletonMap("code", code));
		return modes.iterator().hasNext() ? modes.iterator().next() : null;
	}

	@Override
	public PaymentInfoModel getPaymentInfo(final String code)
	{
		if (code == null)
		{
			return null;
		}
		final List<PaymentInfoModel> modes = wirecardPaymentInfoDao.find(Collections.singletonMap("code", code));
		return modes.iterator().hasNext() ? modes.iterator().next() : null;
	}

	@Override
	public FinancialInstitutionModel getFinancialInstitutionByCode(final String code)
	{
		if (code == null)
		{
			return null;
		}
		final List<FinancialInstitutionModel> modes = financialInstitutionDao
				.find(Collections.singletonMap("identifierCode", code));
		return modes.isEmpty() ? null : modes.iterator().next();
	}



	@Override
	public PaymentInfoModel createPaymentInfo(final AbstractOrderModel order)
	{
		final WirecardPaymentMethod method = methods.get(((WirecardPaymentModeModel) order.getPaymentMode())
				.getWirecardPaymentMethodId().getCode());
		final PaymentInfoModel info = method.createPaymentInfo(order);
		info.setBillingAddress(order.getPaymentAddress());
		getModelService().save(info);
		return info;
	}

	@Override
	public PaymentTransactionEntryModel getPaymentTransactionEntry(final String transactionEntryCode)
	{
		return getMiscPaymentMethod().getPaymentTransactionEntry(transactionEntryCode);
	}

	/**
	 * 
	 * @return
	 */
	public DefaultWirecardPaymentInfoDAO getWirecardPaymentInfoDao()
	{
		return wirecardPaymentInfoDao;
	}

	/**
	 * 
	 * @param paymentInfoDao
	 */
	public void setWirecardPaymentInfoDao(final DefaultWirecardPaymentInfoDAO paymentInfoDao)
	{
		this.wirecardPaymentInfoDao = paymentInfoDao;
	}

	@Override
	public CurrencyModel getCurrency(final String isoCode)
	{
		if (StringUtils.isEmpty(isoCode))
		{
			return null;
		}

		final List<CurrencyModel> currencys = currencyDao.findCurrenciesByCode(isoCode);
		return currencys.isEmpty() ? null : currencys.iterator().next();
	}

	@Override
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	public void setMethods(final Map<String, WirecardPaymentMethod> methods)
	{
		this.methods = methods;
	}

	public void setWirecardPaymentModeDao(final DefaultWirecardPaymentModeDAO paymentModeDao)
	{
		this.paymentModeDao = paymentModeDao;
	}

	/**
	 * @param currencyDao
	 *           the currencyDao to set
	 */
	public void setCurrencyDao(final DefaultCurrencyDao currencyDao)
	{
		this.currencyDao = currencyDao;
	}

	/**
	 * @param financialInstitutionDao
	 *           the financialInstitutionDao to set
	 */
	public void setFinancialInstitutionDao(final DefaultFinancialInstitutionDao financialInstitutionDao)
	{
		this.financialInstitutionDao = financialInstitutionDao;
	}



	/**
	 * @return the paymentRequestSettingsDAO
	 */
	public DefaultPaymentRequestSettingsDAO getPaymentRequestSettingsDAO()
	{
		return paymentRequestSettingsDAO;
	}

	/**
	 * @param paymentRequestSettingsDAO
	 *           the paymentRequestSettingsDAO to set
	 */
	public void setPaymentRequestSettingsDAO(final DefaultPaymentRequestSettingsDAO paymentRequestSettingsDAO)
	{
		this.paymentRequestSettingsDAO = paymentRequestSettingsDAO;
	}

	@Override
	public boolean isSuccess(final String transactionStatus)
	{
		return PaymentState.SUCCESS.equals(transactionStatus);
	}

	@Override
	public boolean isCancelled(final String transactionStatus)
	{
		return PaymentState.CANCEL.equals(transactionStatus);
	}

	@Override
	public boolean isFailure(final String transactionStatus)
	{
		return PaymentState.FAILURE.equals(transactionStatus);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.services.WirecardService#isPending(java.lang.String)
	 */
	@Override
	public boolean isPending(final String transactionStatus)
	{
		return PaymentState.PENDING.equals(transactionStatus);
	}

	@Override
	public void setPaymentModeApplicationStrategies(final List<PaymentModeApplicationStrategy> paymentModeApplicationStrategies)
	{
		this.paymentModeApplicationStrategies = paymentModeApplicationStrategies;
	}

	public void setTransactionIdGenerator(final TransactionIdGenerator transactionIdGenerator)
	{
		this.transactionIdGenerator = transactionIdGenerator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.services.WirecardService#validateResponseParameters(java.util.Map)
	 */
	@Override
	public boolean validateResponseParameters(final Map<String, String> parameters)
	{
		final String secret = configurationService.getConfiguration().getString(ConfigParams.SECRET, null);
		final String fingerprintOrder = parameters.get(WirecardConstants.ResponseParams.RESPONSE_FINGERPRINT_ORDER);
		final String[] fingerprintOrders = fingerprintOrder.split(",");
		String fingerprintSeed = "";
		boolean secredUsed = false;
		for (final String parameterKey : fingerprintOrders)
		{
			if (WirecardConstants.RequestParams.SECRET.equals(parameterKey))
			{
				if (parameters.get(WirecardConstants.RequestParams.SECRET) != null)
				{
					throw new WirecardException("Secret transmitted, transmission is no more save");
				}
				fingerprintSeed += secret;
				secredUsed = true;
				LOG.info("Secret used!");
			}
			else
			{
				fingerprintSeed += parameters.get(parameterKey);
			}
		}

		final WirecardPaymentMethod paymentMethod = getMiscPaymentMethod();
		String responseFingerPrintCalc = null;
		if (paymentMethod.isQpayEnabled())
		{
			// qPay needs the MD5 Hash algorithm 
			responseFingerPrintCalc = paymentMethod.calculateMD5Hash(fingerprintSeed);
		}
		else
		{
			// qMore needs the sha512 Hash algorithm 
			responseFingerPrintCalc = paymentMethod.calculateSHA512Hash(fingerprintSeed);
		}
		final String responseFingerPrint = parameters.get(WirecardConstants.ResponseParams.RESPONSE_FINGERPRINT);
		if (StringUtils.isNotEmpty(responseFingerPrint) && secredUsed && responseFingerPrint.equals(responseFingerPrintCalc))
		{
			LOG.info("Response fingerprint was ok.");
			// everything is ok with the response parameters
			return true;
		}
		else
		{
			LOG.error("Response fingerprint not ok.");
			LOG.error("Response fingerprintOrder: " + fingerprintOrder);
			LOG.error("Response fingerprintSeeds: " + fingerprintSeed);
			return false;
		}
	}

	/**
	 * Returns the first paymentMethod form the payment methods Map to access the paymentMethods standard methods.
	 * 
	 * @return any {@link WirecardPaymentMethod}
	 */
	private WirecardPaymentMethod getMiscPaymentMethod()
	{
		return methods.values().iterator().next();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.services.WirecardService#storeResponseParametersSuccess(java.lang.String, java.util.Map)
	 */
	@Override
	public void storeResponseParametersSuccess(final Map<String, String> parameters,
			final PaymentTransactionEntryModel transactionEntry)
	{

		if (transactionEntry == null)
		{
			throw new WirecardException("PaymentTransactionEntryModel can not be null when storing parameters");
		}
		else
		{
			// FIRST fill the PaymentTransactionEntry object
			final String amountStr = parameters.get(ResponseParams.AMOUNT);
			if (StringUtils.isNotEmpty(amountStr))
			{
				final double amountDbl = Double.parseDouble(amountStr);
				transactionEntry.setAmount(BigDecimal.valueOf(amountDbl));
			}
			final String currencyStr = parameters.get(ResponseParams.CURRENCY);
			final CurrencyModel currency = getCurrency(currencyStr);
			transactionEntry.setCurrency(currency);

			getModelService().save(transactionEntry);

			// SECOND fill the specific paymentInfo object in the specific paymentMethod
			final String paymentType = parameters.get(ResponseParams.PAYMENT_TYPE);
			final WirecardPaymentMethod paymentMethod = getPaymentMethodByCode(paymentType);
			paymentMethod.storeResponseParameters(parameters, transactionEntry);

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.services.WirecardService#storeResponseParametersBasic(java.lang.String, java.util.Map)
	 */
	@Override
	public void storeResponseParametersBasic(final String responseParamString, final Map<String, String> parameters,
			final PaymentTransactionEntryModel transactionEntry)
	{
		if (transactionEntry == null)
		{
			throw new WirecardException("PaymentTransactionEntryModel can not be null when storing parameters");
		}
		else
		{
			transactionEntry.setResponseParams(responseParamString);
			transactionEntry.setTransactionStatusDetails("Response received from payment provider");
			transactionEntry.setTransactionStatus(parameters.get(ResponseParams.PAYMENT_STATE));

			// The error message is only passed in case of paymentState=FAILURE
			// dependent on qMore, qPay different message keys are used
			if (getMiscPaymentMethod().isQmoreEnabled())
			{
				String errorMessage = null;
				// there is only one error Message returned from qMore
				// First: try to get the error message from real payment provider 
				final String paymentSystemErrorMessageKey = ResponseParams.PAYMENT_SYSTEM_MESSAGE_PLACEHOLDER.replaceFirst(
						ResponseParams.ERROR_PLACEHOLDER_KEY, String.valueOf(1));
				errorMessage = parameters.get(paymentSystemErrorMessageKey);
				// Second: get wirecard error message
				if (StringUtils.isEmpty(errorMessage))
				{
					final String errorMessageKey = ResponseParams.ERROR_MESSAGE_PLACEHOLDER.replaceFirst(
							ResponseParams.ERROR_PLACEHOLDER_KEY, String.valueOf(1));
					errorMessage = parameters.get(errorMessageKey);
				}

				transactionEntry.setMessage(errorMessage);
			}
			else
			{
				// get error message for qPay
				transactionEntry.setMessage(parameters.get(ResponseParams.MESSAGE));
			}
			getModelService().save(transactionEntry);
		}
	}



}
