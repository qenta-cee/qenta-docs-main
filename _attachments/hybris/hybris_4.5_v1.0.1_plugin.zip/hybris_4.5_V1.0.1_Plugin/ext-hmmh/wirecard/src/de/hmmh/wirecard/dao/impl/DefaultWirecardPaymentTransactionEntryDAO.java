
package de.hmmh.wirecard.dao.impl;

import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

/**
 * @author Christoph.Meyer
 *
 */
public class DefaultWirecardPaymentTransactionEntryDAO extends DefaultGenericDao<PaymentTransactionEntryModel> {

	public DefaultWirecardPaymentTransactionEntryDAO() {
		super(PaymentTransactionEntryModel._TYPECODE);
	}
}
