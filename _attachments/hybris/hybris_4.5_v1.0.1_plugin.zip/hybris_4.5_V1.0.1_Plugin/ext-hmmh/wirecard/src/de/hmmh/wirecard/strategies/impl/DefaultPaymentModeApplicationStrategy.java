
package de.hmmh.wirecard.strategies.impl;

import de.hybris.platform.core.model.order.CartModel;

import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.strategies.PaymentModeApplicationStrategy;


/**
 * @author Christoph.Meyer
 * 
 */
public class DefaultPaymentModeApplicationStrategy implements PaymentModeApplicationStrategy
{

	@Override
	public boolean isPaymentModeApplicable(final CartModel cart, final WirecardPaymentModeModel paymentMode)
	{
		if (paymentMode.isUseCountryRestrictions() && !paymentMode.getAllowedCountries().isEmpty())
		{
			return paymentMode.getAllowedCountries().contains(cart.getPaymentAddress().getCountry());
		}
		return true;
	}
}
