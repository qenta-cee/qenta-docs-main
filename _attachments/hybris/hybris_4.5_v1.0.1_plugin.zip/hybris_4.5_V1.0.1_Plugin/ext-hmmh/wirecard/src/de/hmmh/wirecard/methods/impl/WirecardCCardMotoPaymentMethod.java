/**
 * 
 */
package de.hmmh.wirecard.methods.impl;



import de.hmmh.wirecard.enums.WirecardPaymentMethodId;



/**
 * Credit Card payment (exclusive "Verified by Visa" and "MasterCardSecureCode")
 * 
 * @author martin.strube
 * 
 */
public class WirecardCCardMotoPaymentMethod extends AbstractWirecardCardPaymentMethod
{

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#getMethodId()
	 */
	@Override
	public WirecardPaymentMethodId getMethodId()
	{
		return WirecardPaymentMethodId.CCARDMOTO;
	}

}
