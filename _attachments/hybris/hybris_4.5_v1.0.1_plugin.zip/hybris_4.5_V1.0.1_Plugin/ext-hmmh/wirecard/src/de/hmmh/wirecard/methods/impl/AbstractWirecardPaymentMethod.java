/**
 *
 * Diesen Quelltext stellt die hmmh AG dem Auftraggeber zur Einsichtnahme zwecks
 * Qualit�tssicherung zur Verf�gung. Die �nderung, Vervielf�ltigung oder die Weitergabe
 * an Dritte ist zustimmungspflichtig. S�mtliche r�umlichen, zeitlichen und �rtlichen
 * Nutzungsrechte liegen ausschlie�lich beim Urheber hmmh AG, es sei denn, es ist
 * ausdr�cklich eine abweichende Nutzungsrechtsvereinbarung vertraglich getroffen worden.
 */
package de.hmmh.wirecard.methods.impl;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;

import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.impl.DefaultCMSSiteService;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.AdvancePaymentInfoModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.payment.enums.PaymentTransactionType;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.i18n.impl.DefaultI18NService;
import de.hybris.platform.servicelayer.internal.converter.impl.DefaultLocaleProvider;
import de.hybris.platform.servicelayer.internal.model.impl.LocaleProvider;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.session.SessionService;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.zkoss.util.Maps;

import de.hmmh.wirecard.constants.WirecardConstants;
import de.hmmh.wirecard.constants.WirecardConstants.ConfigParams;
import de.hmmh.wirecard.constants.WirecardConstants.PaymentState;
import de.hmmh.wirecard.constants.WirecardConstants.RequestParams;
import de.hmmh.wirecard.constants.WirecardConstants.ResponseParams;
import de.hmmh.wirecard.dao.impl.DefaultFinancialInstitutionDao;
import de.hmmh.wirecard.dao.impl.DefaultPaymentRequestSettingsDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentModeDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentTransactionEntryDAO;
import de.hmmh.wirecard.enums.WirecardPaymentMethodId;
import de.hmmh.wirecard.exception.WirecardException;
import de.hmmh.wirecard.methods.WirecardPaymentMethod;
import de.hmmh.wirecard.model.FinancialInstitutionModel;
import de.hmmh.wirecard.model.PaymentRequestSettingsModel;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.strategies.CardBrandNameProviderStrategy;
import de.hmmh.wirecard.strategies.TransactionIdGenerator;


/**
 * @author Christoph.Meyer
 * 
 */
public abstract class AbstractWirecardPaymentMethod implements WirecardPaymentMethod
{

	/**
	 * 
	 */
	private static final String ENCODING_UTF_8 = "UTF-8";
	protected static final Logger LOG = Logger.getLogger(AbstractWirecardPaymentMethod.class);
	protected DefaultWirecardPaymentModeDAO paymentModeDao;
	protected DefaultWirecardPaymentTransactionEntryDAO transactionEntryDao;
	protected transient DefaultFinancialInstitutionDao financialInstitutionDao;
	protected DefaultPaymentRequestSettingsDAO paymentRequestSettingsDAO;
	protected ConfigurationService configurationService;
	protected ModelService modelService;
	protected CommonI18NService commoni18NService;
	protected SessionService sessionService;
	protected CardBrandNameProviderStrategy cardBrandNameProviderStrategy;
	protected TransactionIdGenerator transactionIdGenerator;
	protected LocaleProvider localeProvider;
	protected DefaultI18NService i18NService;
	protected DefaultCMSSiteService cmsSiteService;


	@Override
	public PaymentTransactionEntryModel authorizePayment(final PaymentTransactionModel transaction,
			final HttpServletRequest incomingRequest)
	{
		final PaymentTransactionEntryModel entry = modelService.create(PaymentTransactionEntryModel.class);
		entry.setType(PaymentTransactionType.AUTHORIZATION);
		entry.setPaymentTransaction(transaction);
		entry.setCode(transaction.getCode());
		entry.setTransactionStatus(PaymentState.PENDING);
		entry.setTransactionStatusDetails("No Response has yet been processed");
		entry.setAmount(transaction.getPlannedAmount());
		entry.setCurrency(transaction.getCurrency());
		// save an update
		modelService.save(entry);
		modelService.refresh(entry);

		// the parameter string to be store in the db via paymentEntry object 
		final StringBuilder requestParamsStr = new StringBuilder();
		// A map of parameters used for the http PostMethod
		final Map<String, String> requestParamsMap = new HashMap<String, String>();
		// the parameter order of the requestFingerprint
		final StringBuilder requestFingerprintOrder = new StringBuilder();
		// the fingerprint string itself. This string later is encrypted into an MD5 Hash
		final StringBuilder requestFingerprint = new StringBuilder();

		// append all parameters to the http post request.  
		appendParamAmount(transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamCurrency(transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamPaymentType(requestParamsStr, requestParamsMap);
		appendParamOrderDescription(transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamPaymentTransactionCode(transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder,
				requestFingerprint);
		appendParamOrderIdent(transaction.getOrder(), requestParamsStr, requestParamsMap, requestFingerprint,
				requestFingerprintOrder);
		appendParamSecret(requestFingerprintOrder, requestFingerprint);
		appendParamCustomerId(requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamShopId(requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendMethodSpecificParameter(transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);

		appendUrlParameter(incomingRequest, transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder,
				requestFingerprint);
		appendHmcConfigurationParameter(requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamLanguage(requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamStorageId(transaction, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		appendParamWindowName(requestParamsStr, requestParamsMap);
		if (isQmoreEnabled())
		{
			appendParamUserAgent(incomingRequest, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
			appendParamIpAddress(incomingRequest, requestParamsStr, requestParamsMap, requestFingerprintOrder, requestFingerprint);
		}

		// append the very last parameter of the fingerprintOrder: The fingerprintOrder itself
		requestFingerprintOrder.append(RequestParams.REQUEST_FINGERPRINT_ORDER);
		requestParamsStr.append(RequestParams.REQUEST_FINGERPRINT_ORDER).append('=').append(requestFingerprintOrder.toString())
				.append('&');
		requestParamsMap.put(RequestParams.REQUEST_FINGERPRINT_ORDER, requestFingerprintOrder.toString());
		requestFingerprint.append(requestFingerprintOrder.toString());

		// decide between the two Hash generations
		if (isQpayEnabled())
		{
			final String requestFingerprintMD5 = calculateMD5Hash(requestFingerprint.toString());
			requestParamsStr.append(RequestParams.REQUEST_FINGERPRINT).append('=').append(requestFingerprintMD5);
		}
		else
		{
			final String requestFingerprintSHA512 = calculateSHA512Hash(requestFingerprint.toString());
			requestParamsStr.append(RequestParams.REQUEST_FINGERPRINT).append('=').append(requestFingerprintSHA512);
			requestParamsMap.put(RequestParams.REQUEST_FINGERPRINT, requestFingerprintSHA512);
		}

		LOG.info("Authorize params: " + Maps.toString(requestParamsMap, ' ', '\n'));
		// in case of qPay open iFrame to qPay
		if (isQpayEnabled())
		{
			// store iFrame post request parameters in entry
			entry.setRedirectParams(requestParamsStr.toString());
			entry.setRedirectUrl("about:blank");
			modelService.save(entry);
		}

		// in case of Qmore fire post for authorization
		if (isQmoreEnabled())
		{
			final String frontendInitUrl = configurationService.getConfiguration().getString(ConfigParams.QMORE_FRONTEND_INIT_URL,
					null);
			final PostMethod method = new PostMethod(frontendInitUrl);
			appendParamsToMethod(method, requestParamsMap);
			appendHeaderToMethod(method);

			// store qMore post request parameters in entry
			entry.setRedirectParams(requestParamsStr.toString());
			modelService.save(entry);

			// fire post
			final String response = executeMethod(method, entry);
			// handle response parameters
			final Map<String, String> paramMap = getResponseParams(response);
			checkResponseParametersForErrors(paramMap);
			final String redirectUrlQMore = paramMap.get(ResponseParams.REDIRECT_URL);
			// set redirect to open qMore iFrame
			entry.setRedirectUrl(redirectUrlQMore);
			modelService.save(entry);
		}

		return entry;
	}

	/**
	 * Appends the consumers IP-Address that was used during browsing this website.
	 * 
	 * @param incomingRequest
	 *           The incoming request.
	 * @param requestParamsStr
	 *           The parameter for the http Post request as <code>String</code>.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a <code>Map</code>.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	private void appendParamIpAddress(final HttpServletRequest incomingRequest, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final String ipAddress = incomingRequest.getRemoteAddr();
		requestParamsStr.append(RequestParams.CONSUMER_IP_ADDRESS).append("=").append(ipAddress).append("&");
		requestParamsMap.put(RequestParams.CONSUMER_IP_ADDRESS, ipAddress);
		requestFingerprintOrder.append(RequestParams.CONSUMER_IP_ADDRESS + ",");
		requestFingerprint.append(ipAddress);
	}

	/**
	 * Appends the consumers User-Agent that was used during browsing this website.
	 * 
	 * @param incomingRequest
	 *           The incoming request.
	 * @param requestParamsStr
	 *           The parameter for the http Post request as <code>String</code>.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a <code>Map</code>.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	private void appendParamUserAgent(final HttpServletRequest incomingRequest, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final String userAgent = incomingRequest.getHeader(WirecardConstants.HeaderParams.USER_AGENT);
		requestParamsStr.append(RequestParams.CONSUMER_USER_AGENT).append("=").append(userAgent).append("&");
		requestParamsMap.put(RequestParams.CONSUMER_USER_AGENT, userAgent);
		requestFingerprintOrder.append(RequestParams.CONSUMER_USER_AGENT + ",");
		requestFingerprint.append(userAgent);
	}

	/**
	 * Add the windowname to get the wirecard payment iFrame closed after success.
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request as String
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map.
	 */
	private void appendParamWindowName(final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap)
	{
		requestParamsStr.append(RequestParams.WINDOW_NAME).append('=').append("wire_frame").append('&');
		requestParamsMap.put(RequestParams.WINDOW_NAME, "wire_frame");
	}

	/**
	 * Appends the dataStorageId to the parameter map, string fingerprint order and so on.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request as String
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	private void appendParamStorageId(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final String storageId = transaction.getOrder().getDataStorageId();
		if (StringUtils.isNotEmpty(storageId))
		{
			requestFingerprintOrder.append(RequestParams.DATA_STORAGE_ID + ",");
			requestParamsMap.put(RequestParams.DATA_STORAGE_ID, storageId);
			requestParamsStr.append(RequestParams.DATA_STORAGE_ID).append('=').append(storageId).append('&');
			requestFingerprint.append(storageId);
		}
	}


	/**
	 * Appends the amount to the reqeustParameters, requestFingerprint and fingerprintOrder if committed.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request as String
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamAmount(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final BigDecimal amountBig = transaction.getPlannedAmount();
		if (amountBig == null)
		{
			throw new WirecardException("Transaction must be configured with amount.", "amountMissing", "", "", "");
		}

		// set max digits to 2 for amount
		final String amount = amountBig.setScale(2).toString();
		requestFingerprintOrder.append(RequestParams.AMOUNT + ",");
		requestParamsStr.append(RequestParams.AMOUNT).append('=').append(amount).append('&');
		requestParamsMap.put(RequestParams.AMOUNT, amount);
		requestFingerprint.append(amount);
	}

	/**
	 * Appends the amount to the requestParameters, requestFingerprint and fingerprintOrder if committed.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request as String
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamCurrency(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final CurrencyModel currency = transaction.getCurrency();
		if (currency == null)
		{
			throw new WirecardException("Transaction must be configured with currency.", "currencyMissing", "", "", "");
		}

		requestFingerprintOrder.append(RequestParams.CURRENCY + ",");
		requestParamsMap.put(RequestParams.CURRENCY, currency.getIsocode());
		requestParamsStr.append(RequestParams.CURRENCY).append('=').append(currency.getIsocode()).append('&');
		requestFingerprint.append(currency.getIsocode());
	}

	/**
	 * Appends the paymentType to the requestParameters, requestFingerprint and fingerprintOrder if committed.
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request. This parameter must be set.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 */
	protected void appendParamPaymentType(final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap)
	{
		final String paymentType = getPaymentType();
		requestParamsStr.append(RequestParams.PAYMENT_TYPE).append('=').append(paymentType).append('&');
		requestParamsMap.put(RequestParams.PAYMENT_TYPE, paymentType);
	}


	/**
	 * Appends the OrderDesctiption to the requestParameters, requestFingerprint and fingerprintOrder if committed.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request. This parameter must be set.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here..
	 */
	protected void appendParamOrderDescription(final PaymentTransactionModel transaction, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final AbstractOrderModel order = transaction.getOrder();
		if (order == null)
		{
			throw new WirecardException("Transaction must be configured with amount, currency and an abstractorder.",
					"orderMissing", "", "", "");
		}

		requestFingerprintOrder.append(RequestParams.ORDER_DESCRIPTION + ",");
		requestParamsStr.append(RequestParams.ORDER_DESCRIPTION).append('=').append(order.getDesignatedOrderCode()).append('&');
		requestParamsMap.put(RequestParams.ORDER_DESCRIPTION, order.getDesignatedOrderCode());
		requestFingerprint.append(order.getDesignatedOrderCode());
	}

	/**
	 * Appends the PaymentTransactionCode to the requestParamStr or Map, requestFingerprint and fingerprintOrder if
	 * committed. The transactionCode is the same in the TransactionEntry as in the PaymentTransaction. The code is
	 * mandatory to find the right transaction when we get the response from wirecard.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request. This parameter must be set.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamPaymentTransactionCode(final PaymentTransactionModel transaction,
			final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap,
			final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		final String paymentTransactionCode = transaction.getCode();
		requestFingerprintOrder.append(RequestParams.PAYMENT_TRANSACTION_CODE + ",");
		requestParamsStr.append(RequestParams.PAYMENT_TRANSACTION_CODE).append('=').append(paymentTransactionCode).append('&');
		requestParamsMap.put(RequestParams.PAYMENT_TRANSACTION_CODE, paymentTransactionCode);
		requestFingerprint.append(paymentTransactionCode);
	}


	/**
	 * Appends the secret to the requestParamStr or Map, requestFingerprint and fingerprintOrder if committed.
	 * 
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamSecret(final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		final String secret = configurationService.getConfiguration().getString(ConfigParams.SECRET, null);
		if (requestFingerprintOrder != null)
		{
			requestFingerprintOrder.append(RequestParams.SECRET + ",");
		}
		requestFingerprint.append(secret);
	}


	/**
	 * Appends the PaymentTransactionCode to the requestParamStr or Map, requestFingerprint and fingerprintOrder if
	 * committed. The transactionCode is the same in the TransactionEntry as in the PaymentTransaction. The code is
	 * mandatory to find the right transaction when we get the response from wirecard.
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request. This parameter must be set.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamCustomerId(final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap,
			final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		final String customerId = configurationService.getConfiguration().getString(ConfigParams.CUSTOMER_ID, null);
		if (requestFingerprintOrder != null)
		{
			requestFingerprintOrder.append(RequestParams.CUSTOMER_ID + ",");
		}
		if (requestParamsStr != null)
		{
			requestParamsStr.append(RequestParams.CUSTOMER_ID).append('=').append(customerId).append('&');
		}

		requestParamsMap.put(RequestParams.CUSTOMER_ID, customerId);
		requestFingerprint.append(customerId);
	}

	/**
	 * Appends the ShopId to the requestParamStr or Map, requestFingerprint and fingerprintOrder if committed. The shopId
	 * is an optional parameter so if not set in the HMC it's not set into the passed parameters.
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request. This parameter must be set.
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamShopId(final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap,
			final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		final PaymentRequestSettingsModel paymentRequestSettingsModel = getPaymentRequestSettingForCurrentSite();
		final String shopID = paymentRequestSettingsModel.getShopID();
		if (StringUtils.isNotEmpty(shopID))
		{
			if (requestFingerprintOrder != null)
			{
				requestFingerprintOrder.append(RequestParams.SHOP_ID + ",");
			}

			if (requestParamsMap != null)
			{
				requestParamsMap.put(RequestParams.SHOP_ID, shopID);
			}

			if (requestParamsStr != null)
			{
				requestParamsStr.append(RequestParams.SHOP_ID).append('=').append(shopID).append('&');
			}
			requestFingerprint.append(shopID);
		}
	}

	/**
	 * Appends the all necessary URLs to the QPAY post request parameter. That are
	 * <code>successUrl, failureUrl, cancelUrl, confirmUrl, serviceUrl</code>.
	 * 
	 * @param incomingRequest
	 * @param transaction
	 *           The {@link PaymentTransactionModel} that hold this transaction
	 * @param requestParamsStr
	 *           The parameter for the http Post request
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here, separated by a comma.
	 */
	protected void appendUrlParameter(final HttpServletRequest incomingRequest, final PaymentTransactionModel transaction,
			final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap,
			final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		if (isQpayEnabled())
		{
			final String redirectUrl = configurationService.getConfiguration().getString(ConfigParams.QPAY_INIT_URL, null);
			requestParamsStr.append("httpPostActionUrl").append('=').append(redirectUrl).append('&');
		}

		final String failureUrl = configurationService.getConfiguration().getString(ConfigParams.RESPONSE_URL_FAILURE, null);
		requestParamsStr.append(RequestParams.FAILURE_URL).append('=').append(failureUrl).append('&');
		requestParamsMap.put(RequestParams.FAILURE_URL, failureUrl);

		final String cancelUrl = configurationService.getConfiguration().getString(ConfigParams.RESPONSE_URL_CANCEL, null);
		requestParamsStr.append(RequestParams.CANCEL_URL).append('=').append(cancelUrl).append('&');
		requestParamsMap.put(RequestParams.CANCEL_URL, cancelUrl);

		String confirmUrl = configurationService.getConfiguration().getString(ConfigParams.RESPONSE_URL_CONFIRM, null);
		// append SessionId to store errorCodes in Session for later use 
		final String sessionId = incomingRequest.getSession().getId();
		final String sessionParam = ";jsessionid=" + sessionId;
		confirmUrl = confirmUrl + sessionParam;
		requestFingerprintOrder.append(RequestParams.CONFIRM_URL + ",");
		requestParamsStr.append(RequestParams.CONFIRM_URL).append('=').append(confirmUrl).append('&');
		requestParamsMap.put(RequestParams.CONFIRM_URL, confirmUrl);
		requestFingerprint.append(confirmUrl);

		String successUrl = configurationService.getConfiguration().getString(ConfigParams.RESPONSE_URL_SUCCESS, null);
		final AbstractOrderModel order = transaction.getOrder();
		if (order == null)
		{
			throw new WirecardException("Transaction must be configured with an abstractOrder.", "orderMissing", "", "", "");
		}

		successUrl += ((CartModel) order).getDesignatedOrderCode();
		requestFingerprintOrder.append(RequestParams.SUCCESS_URL + ",");
		requestParamsStr.append(RequestParams.SUCCESS_URL).append('=').append(successUrl).append('&');
		requestParamsMap.put(RequestParams.SUCCESS_URL, successUrl);
		requestFingerprint.append(successUrl);
	}

	/**
	 * Appends all configuration parameter that can be configured over the HMC. That are
	 * <code>duplicateRequestCheck, autoDeposit, maxRetries, confirmMail, ...</code>
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here, separated by a comma.
	 */
	protected void appendHmcConfigurationParameter(final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprintOrder,
			final StringBuilder requestFingerprint)
	{
		final PaymentRequestSettingsModel paymentRequestSettings = getPaymentRequestSettingForCurrentSite();

		final String customerStatement = paymentRequestSettings.getCustomerStatement();
		if (!StringUtils.isEmpty(customerStatement))
		{
			requestFingerprintOrder.append(RequestParams.CUSTOMER_STATEMENT + ",");
			requestParamsStr.append(RequestParams.CUSTOMER_STATEMENT).append('=').append(customerStatement).append('&');
			requestParamsMap.put(RequestParams.CUSTOMER_STATEMENT, customerStatement);
			requestFingerprint.append(customerStatement);
		}

		if (isQpayEnabled())
		{
			final Integer maxRetries = paymentRequestSettings.getMaxRetries();
			if (maxRetries != null)
			{
				requestFingerprintOrder.append(RequestParams.MAX_RETRIES + ",");
				requestParamsStr.append(RequestParams.MAX_RETRIES).append('=').append(maxRetries).append('&');
				requestFingerprint.append(maxRetries);
			}
		}

		final boolean duplicateRequestCheck = paymentRequestSettings.isDuplicateRequestCheck();
		requestFingerprintOrder.append(RequestParams.DUPLICATE_REQUEST_CHECK + ",");
		requestParamsStr.append(RequestParams.DUPLICATE_REQUEST_CHECK).append('=').append(duplicateRequestCheck).append('&');
		requestParamsMap.put(RequestParams.DUPLICATE_REQUEST_CHECK, Boolean.toString(duplicateRequestCheck));
		requestFingerprint.append(duplicateRequestCheck);

		final boolean autoDeposit = paymentRequestSettings.isAutoDeposit();
		requestFingerprintOrder.append(RequestParams.AUTO_DEPOSIT + ",");
		requestParamsStr.append(RequestParams.AUTO_DEPOSIT).append('=').append(autoDeposit).append('&');
		requestParamsMap.put(RequestParams.AUTO_DEPOSIT, Boolean.toString(autoDeposit));
		requestFingerprint.append(autoDeposit);

		if (isQpayEnabled())
		{
			final String imageUrl = paymentRequestSettings.getImageURL();
			if (!StringUtils.isEmpty(imageUrl))
			{
				requestFingerprintOrder.append(RequestParams.IMAGE_URL + ",");
				requestParamsStr.append(RequestParams.IMAGE_URL).append('=').append(imageUrl).append('&');
				requestParamsMap.put(RequestParams.IMAGE_URL, imageUrl);
				requestFingerprint.append(imageUrl);
			}
		}

		final String serviceUrl = paymentRequestSettings.getServiceURL();
		if (StringUtils.isNotEmpty(serviceUrl))
		{
			requestFingerprintOrder.append(RequestParams.SERVICE_URL + ",");
			requestParamsStr.append(RequestParams.SERVICE_URL).append('=').append(serviceUrl).append('&');
			requestParamsMap.put(RequestParams.SERVICE_URL, serviceUrl);
			requestFingerprint.append(serviceUrl);
		}
	}

	/**
	 * Appends all other parameters to the request. That are <code>language, windowName</code>.
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprintOrder
	 *           The order of the requestFingerprint is stored here, separated by a comma.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamLanguage(final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap,
			final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		String language = WirecardConstants.LOCAL_DEFAULT.getLanguage();

		if (getLocaleProvider().getCurrentDataLocale() != null)
		{
			language = getLocaleProvider().getCurrentDataLocale().getLanguage();
		}
		LOG.info("Choosen local: " + language);

		if (requestFingerprintOrder != null)
		{
			requestFingerprintOrder.append(RequestParams.LANGUAGE + ",");
		}

		if (requestParamsMap != null)
		{
			requestParamsMap.put(RequestParams.LANGUAGE, language);
		}
		if (requestParamsStr != null)
		{
			requestParamsStr.append(RequestParams.LANGUAGE).append('=').append(language).append('&');
		}
		requestFingerprint.append(language);
	}

	protected LocaleProvider getLocaleProvider()
	{
		if (this.localeProvider == null)
		{
			this.localeProvider = new DefaultLocaleProvider(i18NService);
		}
		return this.localeProvider;
	}


	/**
	 * Gets the paymentType for QPAY. Since Java doesn't provide variable names with a '-' in it we need to do this hack.
	 * 
	 * @return The paymentMethodId as {@link String}
	 */
	private String getPaymentType()
	{
		final WirecardPaymentMethodId method = getMethodId();
		if (WirecardPaymentMethodId.CCARDMOTO.equals(method))
		{
			return "CCARD-MOTO";
		}

		return method.toString();

	}

	@Override
	public PaymentInfoModel createPaymentInfo(final AbstractOrderModel order)
	{
		final AdvancePaymentInfoModel paymentInfo = createBasicPaymentInfo(order, AdvancePaymentInfoModel.class);

		return paymentInfo;
	}

	public WirecardPaymentModeModel getConfig(final AbstractOrderModel order)
	{
		return (WirecardPaymentModeModel) order.getPaymentMode();
	}



	/**
	 * A passed URL parameter string containing <code>key1=Value2&key2=value2&...</code> pairs will be extracted and put
	 * into a HashMap.
	 * 
	 * @param response
	 * @return
	 */
	public Map<String, String> getResponseParams(final String response)
	{
		String responseCopy = response;
		final Map<String, String> result = new HashMap<String, String>();
		responseCopy = StringUtils.replace(responseCopy, "\r", "");
		responseCopy = StringUtils.replace(responseCopy, "\n", "");
		if (responseCopy != null)
		{
			final StringTokenizer tokenizer = new StringTokenizer(responseCopy, "&");
			String value;
			String key;
			while (tokenizer.hasMoreTokens())
			{
				final String token = tokenizer.nextToken();
				key = decodeUrl(StringUtils.substringBefore(token, "="));
				value = decodeUrl(StringUtils.substringAfter(token, "="));
				result.put(key, value);
			}
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hmmh.wirecard.methods.WirecardPaymentMethod#storeResponseParameters(java.util.Map,
	 * de.hybris.platform.payment.model.PaymentTransactionEntryModel)
	 */
	@Override
	public void storeResponseParameters(final Map<String, String> parameters, final PaymentTransactionEntryModel transactionEntry)
	{
		// store basic attributes
		storeBasicResponseParameters(parameters, transactionEntry);

		final PaymentInfoModel paymentInfo = getTransactionPaymentInfo(transactionEntry.getPaymentTransaction());
		// store non credit card specific attributes
		paymentInfo.setGatewayReferenceNumber(parameters.get(ResponseParams.GATEWAY_REFERENCE_NUMBER));
		paymentInfo.setGatewayContractNumber(parameters.get(ResponseParams.GATEWAY_CONTRACT_NUMBER));

		// check against NULL values and empty strings as paymentInfo will be 
		// stored on an earlier step and at this point it is not guaranteed 
		// that all parameters will be transfered via confirmUrl

		// iDeal 
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.IDEAL_CONSUMER_NAME)))
		{
			paymentInfo.setIdealConsumerName(parameters.get(ResponseParams.IDEAL_CONSUMER_NAME));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.IDEAL_CONSUMER_CITY)))
		{
			paymentInfo.setIdealConsumerCity(parameters.get(ResponseParams.IDEAL_CONSUMER_CITY));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.IDEAL_CONSUMER_ACCOUNT_NUMBER)))
		{
			paymentInfo.setIdealConsumerAccountNumber(parameters.get(ResponseParams.IDEAL_CONSUMER_ACCOUNT_NUMBER));
		}

		// PayPal 
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.PAYPAL_PAYER_ID)))
		{
			paymentInfo.setPaypalPayerID(parameters.get(ResponseParams.PAYPAL_PAYER_ID));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.PAYPAL_PAYER_EMAIL)))
		{
			paymentInfo.setPaypalPayerEmail(parameters.get(ResponseParams.PAYPAL_PAYER_EMAIL));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.PAYPAL_PAYER_LAST_NAME)))
		{
			paymentInfo.setPaypalPayerLastName(parameters.get(ResponseParams.PAYPAL_PAYER_LAST_NAME));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.PAYPAL_PAYER_FIRST_NAME)))
		{
			paymentInfo.setPaypalPayerFirstName(parameters.get(ResponseParams.PAYPAL_PAYER_FIRST_NAME));
		}

		// Sofortueberweisung, ELV, etc.
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_ACCOUNT_OWNER)))
		{
			paymentInfo.setSenderAccountOwner(parameters.get(ResponseParams.SENDER_ACCOUNT_OWNER));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_ACCOUNT_NUMBER)))
		{
			paymentInfo.setSenderAccountNumber(parameters.get(ResponseParams.SENDER_ACCOUNT_NUMBER));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_BANK_NUMBER)))
		{
			paymentInfo.setSenderBankNumber(parameters.get(ResponseParams.SENDER_BANK_NUMBER));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_BANK_NAME)))
		{
			paymentInfo.setSenderBankName(parameters.get(ResponseParams.SENDER_BANK_NAME));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_BIC)))
		{
			paymentInfo.setSenderBIC(parameters.get(ResponseParams.SENDER_BIC));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_IBAN)))
		{
			paymentInfo.setSenderIBAN(parameters.get(ResponseParams.SENDER_IBAN));
		}
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.SENDER_COUNTRY)))
		{
			paymentInfo.setSenderCountry(parameters.get(ResponseParams.SENDER_COUNTRY));
		}


		final String serucrityCriteria = parameters.get(ResponseParams.SECURITY_CRITERIA);
		if (StringUtils.isNotEmpty(serucrityCriteria))
		{
			paymentInfo.setSecurityCriteria(Byte.valueOf(serucrityCriteria));
		}

		modelService.save(paymentInfo);
	}

	/**
	 * Stores Basic attributes that are used by both CreditCard payment and normal payment.
	 * 
	 * @param parameters
	 *           The Map holding the parameters
	 * @param transactionEntry
	 *           The
	 */
	protected void storeBasicResponseParameters(final Map<String, String> parameters,
			final PaymentTransactionEntryModel transactionEntry)
	{

		// Fetch paymentInfo object
		final PaymentInfoModel paymentInfo = this.getTransactionPaymentInfo(transactionEntry.getPaymentTransaction());
		// store basic attributes
		paymentInfo.setPaymentType(this.getMethodId());
		if (StringUtils.isNotEmpty(parameters.get(ResponseParams.LANGUAGE)))
		{
			paymentInfo.setLanguage(parameters.get(ResponseParams.LANGUAGE));
		}

		final String financialInstitutionStr = parameters.get(ResponseParams.FINANCIAL_INSTITUTION);
		if (StringUtils.isNotEmpty(financialInstitutionStr))
		{
			final FinancialInstitutionModel financialInstitution = getFinancialInstitutionByCode(financialInstitutionStr);
			paymentInfo.setFinancialInstitution(financialInstitution);
		}
		modelService.save(paymentInfo);
	}

	/**
	 * Checks if qMore or qPay is used.
	 * 
	 * @return true if qMore is enabled
	 */
	@Override
	public boolean isQmoreEnabled()
	{
		return configurationService.getConfiguration().getBoolean(ConfigParams.QMORE_ENABLED, false);
	}

	/**
	 * Checks if qPay is used.
	 * 
	 * @return true if qPay is enabled
	 */
	@Override
	public boolean isQpayEnabled()
	{
		return !this.isQmoreEnabled();
	}

	@Override
	public String initQmoreDataStorage(final CartModel cartModel)
	{
		// collect request parameters

		// A map of parameters used for the http PostMethod
		final Map<String, String> requestParamsMap = new HashMap<String, String>();
		// the fingerprint string itself. This string later is encrypted into an SHA512 Hash
		final StringBuilder requestFingerprint = new StringBuilder();

		// Don't mix up the order, otherwise the fingerPrint is not valid anymore! 
		appendParamCustomerId(null, requestParamsMap, null, requestFingerprint);
		appendParamShopId(null, requestParamsMap, null, requestFingerprint);
		appendParamOrderIdent(cartModel, null, requestParamsMap, requestFingerprint, null);
		appendParamReturnUrlCors(null, requestFingerprint, requestParamsMap);
		appendParamLanguage(null, requestParamsMap, null, requestFingerprint);
		// appendParamJavaScriptVersion(javaScriptVersion, requestParamsStr, requestFingerprint, requestParamsMap);
		appendParamSecret(null, requestFingerprint);

		final String requestFingerprintCalc = calculateSHA512Hash(requestFingerprint.toString());
		requestParamsMap.put(RequestParams.REQUEST_FINGERPRINT, requestFingerprintCalc);

		LOG.info("DataStore init params: " + Maps.toString(requestParamsMap, ' ', '\n'));

		// Create and fire PostMethod
		final String dsInitUrl = configurationService.getConfiguration().getString(ConfigParams.QMORE_DATASTORAGE_INIT_URL, null);
		final PostMethod method = new PostMethod(dsInitUrl);
		appendParamsToMethod(method, requestParamsMap);
		appendHeaderToMethod(method);

		final String response = executeMethod(method, null);

		// handle response parameters
		final Map<String, String> paramMap = getResponseParams(response);
		checkResponseParametersForErrors(paramMap);

		final String javaScriptUrlEncoded = paramMap.get(WirecardConstants.ResponseParams.JAVASCRIPT_URL);
		final String dataStorageId = paramMap.get(WirecardConstants.ResponseParams.DATA_STORAGE_ID);
		cartModel.setDataStorageId(dataStorageId);
		modelService.save(cartModel);

		return decodeUrl(javaScriptUrlEncoded);
	}

	/**
	 * Decodes the passed URL assuming the passed string is UTF-8 encoded.
	 * 
	 * @param encodedUrl
	 *           The urlEncoded String to decode.
	 * @return <code>null</code> if an empty string was passed. Otherwise the decoded url is returned.
	 */
	private String decodeUrl(final String encodedUrl)
	{
		String decodedUrl = null;
		if (StringUtils.isNotEmpty(encodedUrl))
		{
			try
			{
				decodedUrl = URLDecoder.decode(encodedUrl, ENCODING_UTF_8);
			}
			catch (final UnsupportedEncodingException e)
			{
				LOG.error(e, e);
			}
		}
		return decodedUrl;
	}

	/**
	 * Checks the result of the qMore communication. In case of errors they will be printed out and a WirecardException
	 * is thrown.
	 * 
	 * @param paramMap
	 *           The response parameter map that holds all error messages, keys and so on.
	 */
	protected void checkResponseParametersForErrors(final Map<String, String> paramMap)
	{
		final String errors = paramMap.get(ResponseParams.ERRORS);
		if (StringUtils.isNotEmpty(errors))
		{
			final int errorNumber = Integer.parseInt(errors);
			LOG.error("Got " + errors + " errors in response: ");
			for (int i = 1; i <= errorNumber; i++)
			{
				// print out all errors 
				final String errorMessageKey = ResponseParams.ERROR_MESSAGE_PLACEHOLDER.replaceFirst(
						ResponseParams.ERROR_PLACEHOLDER_KEY, String.valueOf(i));
				final String errorMessage = paramMap.get(errorMessageKey);
				LOG.error(errorMessage);
			}
			throw new WirecardException("Error during wirecard handshake.", "errorDuringWirecardHandshake", "error", "empty", "");
		}

	}

	/**
	 * Fires the PostMethod, logs errors and returns its response.
	 * 
	 * @param method
	 * @param entry
	 * @return The unhandled DataStorage init response from wirecard
	 */
	private String executeMethod(final PostMethod method, final PaymentTransactionEntryModel entry)
	{
		String response = null;
		try
		{
			int statusCode = 0;
			final HttpClient client = getHttpClient();
			statusCode = client.executeMethod(method);
			LOG.info("Status: " + statusCode);

			if (statusCode != HttpStatus.SC_OK)
			{
				LOG.error("Http error, status: " + statusCode);
				// read response anyway
				response = method.getResponseBodyAsString(100000);
			}
			else
			{
				response = method.getResponseBodyAsString(100000);
			}
			LOG.info("DS-Init response: " + response);
		}
		catch (final HttpException e)
		{
			if (entry != null)
			{
				entry.setTransactionStatus("HTTP error " + e.getMessage());
			}
			LOG.error("Error while sending request to wirecard", e);
		}
		catch (final IOException e)
		{
			if (entry != null)
			{
				entry.setTransactionStatus("IO error " + e.getMessage());
			}
			LOG.error("Error while sending request to wirecard", e);
		}
		finally
		{
			method.releaseConnection();
		}

		return response;
	}

	/**
	 * Creates a new <code>HttpClient</code> and sets it standard timeout values defined in {@link WirecardConstants}.
	 * 
	 * @return The {@link HttpClient}
	 */
	public HttpClient getHttpClient()
	{
		// create connection defaults
		final HttpConnectionManagerParams hmcp = new HttpConnectionManagerParams();
		hmcp.setSoTimeout(WirecardConstants.HTTP_CLIENT_SOCKET_TIMEOUT);
		hmcp.setConnectionTimeout(WirecardConstants.HTTP_CLIENT_CONNECTION_TIMEOUT);

		final SimpleHttpConnectionManager scm = new SimpleHttpConnectionManager();
		scm.setParams(hmcp);

		// create http client
		return new HttpClient(scm);
	}

	/**
	 * Sets some request headers like user-agent, contentType and charset.
	 * 
	 * @param method
	 */
	private void appendHeaderToMethod(final PostMethod method)
	{
		method.setRequestHeader(WirecardConstants.HeaderParams.USER_AGENT,
				"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0");
	}

	/**
	 * Iterates over the map and adds all key value pairs to the passed postMethod.
	 * 
	 * @param method
	 *           The {@link PostMethod}
	 * @param requestParamsMap
	 *           The Map holding all the parameters to be added into the PostMethod.
	 */
	private void appendParamsToMethod(final PostMethod method, final Map<String, String> requestParamsMap)
	{
		validateParameterNotNull(method, "PostMethod can not be null");
		validateParameterNotNull(requestParamsMap, "Map can not be null");

		for (final Map.Entry<String, String> entry : requestParamsMap.entrySet())
		{
			method.addParameter(entry.getKey(), entry.getValue());
		}
	}

	/**
	 * Appends the passed JavaScriptVersion to the requestParams
	 * 
	 * @param javaScriptVersion
	 * @param requestParamsStr
	 * @param requestFingerprint
	 * @param requestParamsMap
	 */
	private void appendParamJavaScriptVersion(final String javaScriptVersion, final StringBuilder requestParamsStr,
			final StringBuilder requestFingerprint, final Map<String, String> requestParamsMap)
	{
		requestParamsStr.append(RequestParams.JAVA_SCRIPT_VERSION).append('=').append(javaScriptVersion).append('&');
		requestParamsMap.put(RequestParams.JAVA_SCRIPT_VERSION, javaScriptVersion);
		requestFingerprint.append(javaScriptVersion);
	}

	/**
	 * Appends the parameter returnUrl that handles legacy browsers that can't handle CORS. <br/>
	 * See: <i>http://en.wikipedia.org/wiki/Cross-origin_resource_sharing</i>
	 * 
	 * @param requestParamsStr
	 *           The parameter for the http Post request
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	private void appendParamReturnUrlCors(final StringBuilder requestParamsStr, final StringBuilder requestFingerprint,
			final Map<String, String> requestParamsMap)
	{
		final String corsReturnUrl = configurationService.getConfiguration().getString(ConfigParams.CORS_RETURN_URL, null);
		if (requestParamsStr != null)
		{
			requestParamsStr.append(RequestParams.CORS_RETURN_URL).append('=').append(corsReturnUrl).append('&');
		}

		if (requestParamsMap != null)
		{
			requestParamsMap.put(RequestParams.CORS_RETURN_URL, corsReturnUrl);
		}
		requestFingerprint.append(corsReturnUrl);
	}

	/**
	 * Appends the parameter OrderItend. The orderIdent is a unique identifier of the order in the shop. Hence its the
	 * orderCode.
	 * 
	 * @param orderModel
	 *           The {@link AbstractOrderModel} that hold this users orderList
	 * @param requestParamsStr
	 *           The parameter for the http Post request
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map if committed.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 */
	protected void appendParamOrderIdent(final AbstractOrderModel orderModel, final StringBuilder requestParamsStr,
			final Map<String, String> requestParamsMap, final StringBuilder requestFingerprint,
			final StringBuilder requestFingerprintOrder)
	{
		final String orderIdent = orderModel.getDesignatedOrderCode();

		if (requestParamsStr != null)
		{
			requestParamsStr.append(RequestParams.ORDER_IDENT).append('=').append(orderIdent).append('&');
		}

		if (requestFingerprintOrder != null)
		{
			requestFingerprintOrder.append(RequestParams.ORDER_IDENT + ",");
		}

		requestParamsMap.put(RequestParams.ORDER_IDENT, orderIdent);
		requestFingerprint.append(orderIdent);
	}


	/**
	 * Appends the parameter identifierCode of the {@link FinancialInstitutionModel} to the parameter Map / String and
	 * fingerprint.
	 * 
	 * @param transaction
	 *           The {@link PaymentTransactionModel}
	 * @param requestParamsStr
	 *           The parameter for the http Post request
	 * @param requestParamsMap
	 *           The parameter for the http Post request stored in a Map.
	 * @param requestFingerprint
	 *           The attributes for the requestFingerprint are stored here.
	 * @param requestFingerprintOrder
	 *           the order of the fingerprint
	 */
	protected void appendParamFinancialInstitution(final PaymentTransactionModel transaction,
			final StringBuilder requestParamsStr, final Map<String, String> requestParamsMap,
			final StringBuilder requestFingerprintOrder, final StringBuilder requestFingerprint)
	{
		// 	set Financialinstitute
		final FinancialInstitutionModel financialInstitution = transaction.getInfo().getFinancialInstitution();
		if (financialInstitution == null)
		{
			throw new WirecardException("FinancialInstitution is mandatory for EPS, iDeal", "financialInstitutionMissing", "", "",
					"");
		}

		if (requestFingerprintOrder != null)
		{
			requestFingerprintOrder.append(RequestParams.FINANCIAL_INSTITUTION + ",");
		}
		requestParamsMap.put(RequestParams.FINANCIAL_INSTITUTION, financialInstitution.getIdentifierCode());
		requestParamsStr.append(RequestParams.FINANCIAL_INSTITUTION).append('=').append(financialInstitution.getIdentifierCode())
				.append('&');
		requestFingerprint.append(financialInstitution.getIdentifierCode());
	}


	/**
	 * Looks up the DB for the {@link PaymentTransactionEntryModel} that can be identified by the paymentTransactionCode
	 * set in the postParametersMap.
	 * 
	 * @param transaction
	 * @param postParameters
	 * @return the entry or null if nothing was found.
	 */
	public PaymentTransactionEntryModel findTransactionEntry(final PaymentTransactionModel transaction,
			final Map<String, String> postParameters)
	{
		final String transactionId = postParameters.get(ResponseParams.PAYMENT_TRANSACTION_CODE);
		if (transactionId != null)
		{
			for (final PaymentTransactionEntryModel entry : transaction.getEntries())
			{
				if (transactionId.equals(entry.getCode()))
				{
					return entry;
				}
			}
		}
		return null;
	}

	protected WirecardPaymentModeModel getPaymentMode(final AbstractOrderModel order)
	{
		final WirecardPaymentModeModel paymentMode = (WirecardPaymentModeModel) order.getPaymentMode();
		if (paymentMode == null)
		{
			throw new WirecardException("cannot create payment info for order without paymentmode!");
		}
		return paymentMode;
	}

	protected <T> T createPaymentInfoModel(final Class<T> paymentInfoModelClass)
	{

		if (paymentInfoModelClass.getGenericSuperclass().equals(PaymentInfoModel.class))
		{
			return modelService.create(paymentInfoModelClass);
		}
		else
		{
			throw new WirecardException(new StringBuilder("cannot create payment info model of class ").append(
					paymentInfoModelClass.getSimpleName()).toString());
		}
	}

	protected <T> T createBasicPaymentInfo(final AbstractOrderModel order, final Class<T> paymentInfoModelClass)
	{

		final T paymentInfo = createPaymentInfoModel(paymentInfoModelClass);
		setPaymentInfoPaymentAddress(order, (PaymentInfoModel) paymentInfo);

		((PaymentInfoModel) paymentInfo).setUser(order.getUser());
		((PaymentInfoModel) paymentInfo).setPaymentType(getMethodId());
		final WirecardPaymentModeModel paymentMode = getPaymentMode(order);
		((PaymentInfoModel) paymentInfo).setUseAuthorization(paymentMode.isUseAuthorization());
		((PaymentInfoModel) paymentInfo).setUseSubscription(paymentMode.isUseSubscription());


		// 	NOT needed in Wirecard payment yet
		//		((PaymentInfoModel) paymentInfo).setConfigured(false);		
		//		((PaymentInfoModel) paymentInfo).setChannelId(((WirecardPaymentModeModel) order.getPaymentMode()).getChannelId());

		// generate a paymentInfoCode
		final String code = new StringBuilder("paymentinfo-").append(getMethodId()).append('-').append(order.getCode()).append('-')
				.append(System.currentTimeMillis()).toString();
		((PaymentInfoModel) paymentInfo).setCode(code);

		return paymentInfo;
	}

	protected void setPaymentInfoPaymentAddress(final AbstractOrderModel order, final PaymentInfoModel paymentInfo)
	{
		AddressModel billingAddress = order.getPaymentAddress();
		if (billingAddress == null)
		{
			billingAddress = modelService.create(AddressModel.class);
			billingAddress.setOwner(order);
			order.setPaymentAddress(billingAddress);
			modelService.saveAll(billingAddress, order);
		}

		paymentInfo.setBillingAddress(billingAddress);
	}

	/**
	 * Gets the PaymentRequetSettings defined in the HMC. If its not set a WirecardException is thrown
	 * 
	 * @return
	 */
	protected PaymentRequestSettingsModel getPaymentRequestSetting(final String cmsSitePk)
	{
		final List<PaymentRequestSettingsModel> result = paymentRequestSettingsDAO
				.find(Collections.singletonMap("site", cmsSitePk));
		if (result == null || result.isEmpty())
		{
			throw new WirecardException("PaymentRequestSetting is empty", "paymentRequestSettingsEmptyInHMC", "error", "empty",
					"PaymentRequestSetting is empty");
		}

		return result.iterator().next();
	}

	/**
	 * Gets {@link PaymentRequestSettingsModel} for the currently used CMS Site the uses is browsing right now.
	 * 
	 * @return
	 */
	protected PaymentRequestSettingsModel getPaymentRequestSettingForCurrentSite()
	{
		final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();
		LOG.info("site: " + currentSite.getUid());
		return getPaymentRequestSetting(currentSite.getPk().getLongValueAsString());
	}

	@Override
	public PaymentTransactionEntryModel getPaymentTransactionEntry(final String transactionEntryCode)
	{
		final List<PaymentTransactionEntryModel> result = transactionEntryDao.find(Collections.singletonMap("code",
				transactionEntryCode));
		return result.isEmpty() ? null : result.iterator().next();
	}

	@Override
	public FinancialInstitutionModel getFinancialInstitutionByCode(final String code)
	{
		if (StringUtils.isEmpty(code))
		{
			return null;
		}
		final List<FinancialInstitutionModel> modes = financialInstitutionDao
				.find(Collections.singletonMap("identifierCode", code));
		return modes.isEmpty() ? null : modes.iterator().next();
	}


	/**
	 * @param transaction
	 * @return
	 */
	protected PaymentInfoModel getTransactionPaymentInfo(final PaymentTransactionModel transaction)
	{
		final PaymentInfoModel paymentInfo = transaction.getInfo();

		if (paymentInfo == null)
		{
			throw new WirecardException("PaymentInfo missing");
		}
		return paymentInfo;
	}

	public void setConfigurationService(final ConfigurationService configurationService)
	{
		this.configurationService = configurationService;
	}

	@Override
	public ConfigurationService getConfigurationService()
	{
		return this.configurationService;
	}

	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	public void setWirecardPaymentModeDao(final DefaultWirecardPaymentModeDAO paymentModeDao)
	{
		this.paymentModeDao = paymentModeDao;
	}

	/**
	 * @param financialInstitutionDao
	 *           the financialInstitutionDao to set
	 */
	public void setFinancialInstitutionDao(final DefaultFinancialInstitutionDao financialInstitutionDao)
	{
		this.financialInstitutionDao = financialInstitutionDao;
	}

	public void setCommoni18NService(final CommonI18NService commonI18NService)
	{
		commoni18NService = commonI18NService;
	}

	public void setSessionService(final SessionService sessionService)
	{
		this.sessionService = sessionService;
	}

	public void setCardBrandNameProviderStrategy(final CardBrandNameProviderStrategy cardBrandNameProvider)
	{
		this.cardBrandNameProviderStrategy = cardBrandNameProvider;
	}

	public void setTransactionIdGenerator(final TransactionIdGenerator transactionIdGenerator)
	{
		this.transactionIdGenerator = transactionIdGenerator;
	}

	public void setTransactionEntryDao(final DefaultWirecardPaymentTransactionEntryDAO transactionEntryDao)
	{
		this.transactionEntryDao = transactionEntryDao;
	}



	/**
	 * @return the paymentRequestSettingsDAO
	 */
	public DefaultPaymentRequestSettingsDAO getPaymentRequestSettingsDAO()
	{
		return paymentRequestSettingsDAO;
	}


	/**
	 * @param paymentRequestSettingsDAO
	 *           the paymentRequestSettingsDAO to set
	 */
	public void setPaymentRequestSettingsDAO(final DefaultPaymentRequestSettingsDAO paymentRequestSettingsDAO)
	{
		this.paymentRequestSettingsDAO = paymentRequestSettingsDAO;
	}

	/**
	 * Calculates the SHA-512 digest and returns the value as a String.
	 * 
	 * @param data
	 * @return
	 */
	@Override
	public String calculateSHA512Hash(final String data)
	{
		validateParameterNotNull(data, "The string must not be null to be hashed.");
		return DigestUtils.sha512Hex(data);
	}

	/**
	 * Method provided by Wirecard to generate the MD5 Hashsum. The MD5 Hash is used as the requestFingerprint in the
	 * QPay request and response.
	 * 
	 * @param input
	 * @return the input String as MD5 HashSum
	 */
	@Override
	public String calculateMD5Hash(final String input)
	{
		validateParameterNotNull(input, "The string must not be null to be hashed.");
		try
		{
			// step 1, calculate MD5 hash from input
			final java.security.MessageDigest md5 = MessageDigest.getInstance("MD5");

			final byte[] inputBytes = input.getBytes(ENCODING_UTF_8); // instead of system-depended encoding we need UTF-8 encoding
			final byte[] hash = md5.digest(inputBytes);

			// step 2, convert byte array to hex string
			final StringBuffer sb = new StringBuffer();
			String hex;
			for (int i = 0; i < hash.length; i++)
			{
				hex = Integer.toHexString(0xFF & hash[i]);
				switch (hex.length())
				{
					case 0:
						sb.append("00");
						break;
					case 1:
						sb.append("0");
						sb.append(hex);
						break;
					case 2:
						sb.append(hex);
						break;
					default:
						throw new RuntimeException("illegal hash");
				}
			}

			return sb.toString();
		}
		catch (final NoSuchAlgorithmException e)
		{
			throw new WirecardException(e.getMessage());
		}
		catch (final UnsupportedEncodingException e)
		{
			throw new WirecardException(e.getMessage());
		}
	}

	@Override
	public PaymentTransactionEntryModel registerPayment(final PaymentTransactionModel transaction)
	{
		// YTODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentTransactionEntryModel processRegisterResponse(final PaymentTransactionModel transaction,
			final Map<String, String> postParameters)
	{
		// YTODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentTransactionEntryModel debitPayment(final PaymentTransactionModel transaction)
	{
		// YTODO Auto-generated method stub
		return null;
	}

	@Override
	public PaymentTransactionEntryModel processDebitResponse(final PaymentTransactionModel transaction,
			final Map<String, String> postParameters)
	{
		// YTODO Auto-generated method stub
		return null;
	}

	/**
	 * @param i18nService
	 *           the i18NService to set
	 */
	public void setI18NService(final DefaultI18NService i18nService)
	{
		i18NService = i18nService;
	}

	/**
	 * @param cmsSiteService
	 *           the cmsSiteService to set
	 */
	public void setCmsSiteService(final DefaultCMSSiteService cmsSiteService)
	{
		this.cmsSiteService = cmsSiteService;
	}


}
