
package de.hmmh.wirecard.exception;

import org.apache.commons.lang.StringUtils;


/**
 * Standard RuntimeException for Wirecard.
 * 
 * @author Christoph.Meyer
 * 
 */
public class WirecardException extends RuntimeException
{

	private String result;
	private String reason;
	private String statusCode;
	private String returnCode;

	public WirecardException(final String message)
	{
		super(message);
	}

	public WirecardException(final String message, final String statusCode, final String returnCode, final String result,
			final String reason)
	{
		super(message);
		this.statusCode = statusCode;
		this.returnCode = returnCode;
		this.reason = reason;
		this.result = result;
	}

	public String getResult()
	{
		return result;
	}

	public String getReason()
	{
		return reason;
	}

	public String getStatusCode()
	{
		return statusCode;
	}

	public String getReturnCode()
	{
		return returnCode;
	}

	public String getStatusString()
	{
		return getMessage() + " - wirecard status: " + result + " " + returnCode + " " + reason + " " + statusCode;
	}

	/**
	 * @return
	 */
	public String getMessageKey()
	{
		return "checkout.placeOrder.failed.wirecard." + StringUtils.defaultString(getStatusCode(), "unknown");
	}
}
