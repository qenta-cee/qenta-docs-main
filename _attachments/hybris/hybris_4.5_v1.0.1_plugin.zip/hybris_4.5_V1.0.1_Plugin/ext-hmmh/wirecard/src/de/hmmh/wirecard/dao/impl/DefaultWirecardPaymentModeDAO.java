
package de.hmmh.wirecard.dao.impl;

import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

import de.hmmh.wirecard.model.WirecardPaymentModeModel;




/**
 * @author Christoph.Meyer
 * 
 */
public class DefaultWirecardPaymentModeDAO extends DefaultGenericDao<WirecardPaymentModeModel>
{

	public DefaultWirecardPaymentModeDAO()
	{
		super(WirecardPaymentModeModel._TYPECODE);
	}

}