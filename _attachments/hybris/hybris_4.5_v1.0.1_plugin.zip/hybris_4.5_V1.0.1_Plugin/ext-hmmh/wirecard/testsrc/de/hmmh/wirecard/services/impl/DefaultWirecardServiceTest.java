/**
 * 
 */
package de.hmmh.wirecard.services.impl;

import static org.mockito.BDDMockito.given;

import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.configuration.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import de.hmmh.wirecard.constants.WirecardConstants;
import de.hmmh.wirecard.constants.WirecardConstants.RequestParams;
import de.hmmh.wirecard.constants.WirecardConstants.ResponseParams;
import de.hmmh.wirecard.exception.WirecardException;
import de.hmmh.wirecard.methods.WirecardPaymentMethod;
import de.hmmh.wirecard.methods.impl.AbstractWirecardCardPaymentMethod;
import de.hmmh.wirecard.methods.impl.WirecardCCardMotoPaymentMethod;
import de.hmmh.wirecard.methods.impl.WirecardCCardPaymentMethod;


/**
 * Functional test of the {@link DefaultWirecardService} class.
 * 
 * @author martin.strube
 * 
 */
public class DefaultWirecardServiceTest
{
	private DefaultWirecardService classUnderTest;

	private Map<String, String> parameters;

	@Mock
	private ConfigurationService configurationService;
	@Mock
	private Configuration configuration;


	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUpClass() throws Exception
	{
		classUnderTest = new DefaultWirecardService();

		// set up mokito 
		MockitoAnnotations.initMocks(this);
		// set up config service to get the test secret
		given(configurationService.getConfiguration()).willReturn(configuration);
		given(configuration.getString(WirecardConstants.ConfigParams.SECRET, null)).willReturn("B8AKTPWBRMNBV455FG6M2DANE99WU2");
		// add configService Mock to testClass
		classUnderTest.setConfigurationService(configurationService);

		final Map<String, WirecardPaymentMethod> methods = new HashMap<String, WirecardPaymentMethod>();
		// set up some payment methods to access the MD5hash functionality
		final WirecardCCardPaymentMethod ccardPaymentMethod = new WirecardCCardPaymentMethod();
		final AbstractWirecardCardPaymentMethod ccardMotoPaymentMethod = new WirecardCCardMotoPaymentMethod();
		methods.put(ccardMotoPaymentMethod.getMethodId().toString(), ccardPaymentMethod);
		methods.put(ccardMotoPaymentMethod.getMethodId().toString(), ccardMotoPaymentMethod);

		classUnderTest.setMethods(methods);
	}

	@Before
	public void setUpParameters() throws Exception
	{
		// create MAP with valid parameters
		parameters = new HashMap<String, String>();
		parameters.put(RequestParams.SERVICE_URL, "http://www.hybris.com/contact");
		parameters.put(RequestParams.ORDER_DESCRIPTION, "00009004");
		parameters.put(RequestParams.CONFIRM_URL, "https://wirehybris.hmmh.de/yacceleratorstorefront/wirecard/response");
		parameters.put(RequestParams.FAILURE_URL, "https://wirehybris.hmmh.de/yacceleratorstorefront/checkout/cancel");
		parameters.put(ResponseParams.RESPONSE_FINGERPRINT, "77fd5af0b55cdf6a6cda33127659e03c");
		parameters.put(RequestParams.CURRENCY, "USD");
		parameters.put(RequestParams.AMOUNT, "108.84");
		parameters.put(RequestParams.WINDOW_NAME, "wire_frame");
		parameters.put(RequestParams.CANCEL_URL, "https://wirehybris.hmmh.de/yacceleratorstorefront/checkout/cancel");
		parameters.put(RequestParams.SUCCESS_URL,
				"https://wirehybris.hmmh.de/yacceleratorstorefront/checkout/orderConfirmation/00009004");
		parameters.put(RequestParams.LANGUAGE, "en");
		parameters.put(RequestParams.CUSTOMER_ID, "D200001");
		parameters.put(ResponseParams.RESPONSE_FINGERPRINT_ORDER,
				"amount,currency,orderDescription,secret,customerID,successURL,confirmURL,language,responseFingerprintOrder");
		parameters.put("fooo", "bar");
	}

	/**
	 * Test method for positive test result
	 * {@link de.hmmh.wirecard.services.impl.DefaultWirecardService#validateResponseParameters(java.util.Map)}.
	 */
	@Test
	public void testValidateResponseParametersOk()
	{
		final boolean result = classUnderTest.validateResponseParameters(parameters);
		Assert.assertTrue("result must be ok!", result);
	}

	/**
	 * Test method for negative test result
	 * {@link de.hmmh.wirecard.services.impl.DefaultWirecardService#validateResponseParameters(java.util.Map)}.
	 */
	@Test
	public void testValidateResponseParametersFail()
	{
		// fake parameter manipulation
		parameters.put(RequestParams.AMOUNT, "6.66");
		final boolean result = classUnderTest.validateResponseParameters(parameters);
		Assert.assertFalse("Result MUST not be ok since parameter manipulation.", result);
	}

	/**
	 * Test method for
	 * {@link de.hmmh.wirecard.services.impl.DefaultWirecardService#validateResponseParameters(java.util.Map)}.
	 */
	@Test
	public void testValidateResponseParametersException()
	{
		// cause exception since secret was passed
		parameters.put(ResponseParams.SECRET, "someSecret");
		try
		{
			classUnderTest.validateResponseParameters(parameters);
			Assert.fail("code must not end up here");
		}
		catch (final WirecardException e)
		{
			// everything went fine!			
		}
	}

}
