
package de.hmmh.wirecard.strategies;

import static junit.framework.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import de.hmmh.wirecard.strategies.WirecardCreateOrderFromCartStrategy;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.order.strategies.CartValidator;
import de.hybris.platform.order.strategies.ordercloning.CloneAbstractOrderStrategy;
import de.hybris.platform.servicelayer.keygenerator.KeyGenerator;

import org.junit.Before;
import org.junit.Test;

/**
 * @author joern.ketelsen
 * 
 */
public class WirecardCreateOrderFromCartStrategyTest {

	private WirecardCreateOrderFromCartStrategy strategy;
	private CloneAbstractOrderStrategy cloneAbstractOrderStrategy;
	private CartValidator cartValidator;
	private KeyGenerator keyGenerator;

	@Before
	public void setUp() throws Exception {
		strategy = new WirecardCreateOrderFromCartStrategy();
		cloneAbstractOrderStrategy = mock(CloneAbstractOrderStrategy.class);
		cartValidator = mock(CartValidator.class);
		keyGenerator = mock(KeyGenerator.class);

		strategy.setCloneAbstractOrderStrategy(cloneAbstractOrderStrategy);
		strategy.setKeyGenerator(keyGenerator);
		strategy.setCartValidator(cartValidator);
	}

	/**
	 * This tests effectively nothing but forced the implementation of the
	 * called methods, c. integration test
	 * 
	 * @throws Exception
	 */
	@Test
	public void testOrderGeneration() throws Exception {

		final CartModel cart = new CartModel();

		final String orderCode = strategy.generateOrderCode();
		final OrderModel order = mock(OrderModel.class);
		given(cloneAbstractOrderStrategy.clone(null, null, cart, orderCode, OrderModel.class, OrderEntryModel.class)).willReturn(order);
		cart.setDesignatedOrderCode(orderCode);

		final OrderModel resOrder = strategy.createOrderFromCart(cart, orderCode);
		verify(cartValidator).validateCart(cart);
		assertNotNull(resOrder);
	}
}
