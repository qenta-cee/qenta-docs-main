
package de.hmmh.wirecard.methods.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import de.hybris.platform.core.PK;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.CreditCardPaymentInfoModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.i18n.impl.DefaultI18NService;
import de.hybris.platform.servicelayer.internal.model.impl.LocaleProvider;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.session.Session;
import de.hybris.platform.servicelayer.session.SessionService;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import junit.framework.Assert;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import de.hmmh.wirecard.constants.WirecardConstants;
import de.hmmh.wirecard.constants.WirecardConstants.ResponseParams;
import de.hmmh.wirecard.dao.impl.DefaultPaymentRequestSettingsDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentModeDAO;
import de.hmmh.wirecard.enums.WirecardPaymentMethodId;
import de.hmmh.wirecard.exception.WirecardException;
import de.hmmh.wirecard.model.PaymentRequestSettingsModel;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.strategies.CardBrandNameProviderStrategy;
import de.hmmh.wirecard.strategies.TransactionIdGenerator;
import de.hmmh.wirecard.strategies.WirecardCreateOrderFromCartStrategy;
import de.hmmh.wirecard.strategies.impl.DefaultTransactionIdGenerator;


/**
 * @author Christoph.Meyer
 * 
 */
public class AbstractWirecardPaymentMethodTest
{

	private WirecardCCardPaymentMethod paymentMethod;

	@Mock
	private DefaultWirecardPaymentModeDAO paymentModeDAO;

	@Mock
	private WirecardPaymentModeModel paymentMode;

	@Mock
	private ModelService modelService;

	@Mock
	private DefaultPaymentRequestSettingsDAO paymentRequestSettingsDAO;

	@Mock
	private Configuration configuration;

	@Mock
	private PaymentTransactionModel transaction;

	@Mock
	private PaymentTransactionEntryModel transactionEntry;

	@Mock
	private ConfigurationService configService;

	@Mock
	private CreditCardPaymentInfoModel paymentInfo;

	private HttpClient httpClient;

	@Mock
	private DefaultI18NService i18nService;

	@Mock
	private LocaleProvider localProvider;

	@Mock
	private CartModel cart;

	@Mock
	private UserModel customer;

	@Mock
	private SessionService sessionService;

	@Mock
	private Session currentSession;

	@Mock
	private CardBrandNameProviderStrategy cardBrandNameProvider;

	@Mock
	private WirecardCreateOrderFromCartStrategy createOrderFromCartStrategy;

	TransactionIdGenerator transactionIdGenerator;

	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);

		given(configService.getConfiguration()).willReturn(configuration);
		given(configuration.getString(WirecardConstants.ConfigParams.QPAY_INIT_URL, null)).willReturn(
				"https://secure.wirecard-cee.com/qpay/init.ph");
		given(configuration.getString(WirecardConstants.ConfigParams.CUSTOMER_ID, null)).willReturn("D200001");
		given(configuration.getString(WirecardConstants.ConfigParams.SECRET, null)).willReturn("B8AKTPWBRMNBV455FG6M2DANE99WU2");
		given(configuration.getString(WirecardConstants.ConfigParams.CORS_RETURN_URL, null)).willReturn(
				"https://wirehybris.hmmh.de/yacceleratorstorefront/checkout/corsReturnUrl");
		given(configuration.getString(WirecardConstants.ConfigParams.QMORE_DATASTORAGE_INIT_URL, null)).willReturn(
				"https://secure.wirecard-cee.com/qmore/dataStorage/init");

		given(currentSession.getAttribute("jsessionid")).willReturn("sessionId");
		given(sessionService.getCurrentSession()).willReturn(currentSession);

		paymentMethod = mock(WirecardCCardPaymentMethod.class, Mockito.CALLS_REAL_METHODS);
		paymentMethod.setWirecardPaymentModeDao(paymentModeDAO);
		paymentMethod.setCardBrandNameProviderStrategy(cardBrandNameProvider);
		paymentMethod.setPaymentRequestSettingsDAO(paymentRequestSettingsDAO);
		paymentMethod.setI18NService(i18nService);
		given(paymentMethod.getLocaleProvider()).willReturn(localProvider);
		given(localProvider.getCurrentDataLocale()).willReturn(Locale.ENGLISH);

		transactionIdGenerator = new DefaultTransactionIdGenerator();
		paymentMethod.setTransactionIdGenerator(transactionIdGenerator);

		httpClient = new HttpClient();
		given(paymentMethod.getHttpClient()).willReturn(httpClient);

		paymentMethod.setSessionService(sessionService);
		given(configuration.getString(WirecardConstants.ConfigParams.RESPONSE_URL_CONFIRM, null))
				.willReturn("https://response.uri");
		given(cart.getPaymentMode()).willReturn(paymentMode);
		given(cart.getUser()).willReturn(customer);
		given(cart.getCode()).willReturn("245454545");
		given(cart.getDesignatedOrderCode()).willReturn("00005002");


		given(paymentMode.getChannelId()).willReturn("12345");
		given(paymentModeDAO.find(Collections.singletonMap("WirecardPaymentMethodId", WirecardPaymentMethodId.CCARD))).willReturn(
				Collections.singletonList(paymentMode));

		given(transaction.getOrder()).willReturn(cart);
		given(transaction.getInfo()).willReturn(paymentInfo);
		given(customer.getPk()).willReturn(PK.createPK(1));

		//		given(transactionEntry.getCode()).willReturn("transaction-00000001-1338388419776");
		given(transactionEntry.getCode()).willReturn("00000001x1338388419776");
		given(transactionEntry.getPaymentTransaction()).willReturn(transaction);

		final List<PaymentRequestSettingsModel> prSettings = new LinkedList<PaymentRequestSettingsModel>();
		final PaymentRequestSettingsModel paymentRequestSettingsModel = new PaymentRequestSettingsModel();
		paymentRequestSettingsModel.setShopID("qmore");
		prSettings.add(paymentRequestSettingsModel);
		given(paymentRequestSettingsDAO.find()).willReturn(prSettings);

		paymentMethod.setConfigurationService(configService);
		paymentMethod.setModelService(modelService);

		given(modelService.create(PaymentTransactionEntryModel.class)).willReturn(new PaymentTransactionEntryModel());

	}

	@Test
	public void testGetResponseParams()
	{

		final String simple = "BLA=bla&FASEL=fasel&";
		Map<String, String> map = paymentMethod.getResponseParams(simple);
		assertEquals("bla", map.get("BLA"));
		assertEquals("fasel", map.get("FASEL"));

		final String tricky = "BLA=bla&FASEL=f�sel%26test";
		map = paymentMethod.getResponseParams(tricky);
		assertEquals("bla", map.get("BLA"));
		assertEquals("f�sel&test", map.get("FASEL"));
	}

	@Test
	public void testCalculateSHA512Hash()
	{
		final String data = "D200001B8AKTPWBRMNBV455FG6M2DANE99WU2CID44http://www.example.com/returnen";
		final String expectedResult = "def22b00800290bd21c33d5c16817b50058c493bd60aafc9dd8281caee9b2ee5988b219d17f11c3d3dfd83bb909e3ffe65f6de0801aff540cf0db8e3272951f7";
		final String calculatedData = paymentMethod.calculateSHA512Hash(data);

		assertEquals("MUST be the same!", expectedResult, calculatedData);
	}

	@Test
	public void testQMoreJavaScripURL()
	{
		final String qMoreJavaScripURL = paymentMethod.initQmoreDataStorage(cart);
		System.out.println("got javaScript: " + qMoreJavaScripURL);

		Assert.assertNotNull(qMoreJavaScripURL);
		Assert.assertTrue("A Javascript should end with .js", qMoreJavaScripURL.endsWith(".js"));
	}

	@Test
	public void testQMoreJavaScripURLFail()
	{
		try
		{
			// set bad qMore secret
			given(configuration.getString(WirecardConstants.ConfigParams.SECRET, null)).willReturn("badSecret");
			paymentMethod.initQmoreDataStorage(cart);
			Assert.fail("WirecardException expected due to wrong secret used.");
		}
		catch (final WirecardException e)
		{
			// everything fine
			System.out.println("TestQMoreJavaScripURLFail: passed!");
		}
	}


	/**
	 * Basic response funktion test of the wirecard API.
	 */
	@Test
	public void testQmoreInterface()
	{
		final HttpClient client = new HttpClient();

		final PostMethod post = new PostMethod("https://secure.wirecard-cee.com/qmore/dataStorage/init");
		post.addRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0");
		post.addParameter("customerId", "D200001");
		post.addParameter("orderIdent", "123546879");
		post.addParameter("javascriptScriptVersion", "1.8.0");
		post.addParameter("language", "en");
		post.addParameter("shopId", "qmore");
		post.addParameter("returnUrl", "https://wirehybris.hmmh.de/yacceleratorstorefront/checkout/corsReturnUrl");
		post.addParameter(
				"requestFingerprint",
				"dd7d687009d786b1685b3c9946c90aa1bca112acf9b1bc9403acb532bdbe3b34307bf44aeb41a21ae990154d5451af33cd092802b9b5616d765f0f2838d7c940");

		try
		{
			final int returnCode = client.executeMethod(post);

			if (returnCode == HttpStatus.SC_NOT_IMPLEMENTED)
			{
				System.err.println("The Post method is not implemented by this URI");
				// still consume the response body
				post.getResponseBodyAsString();
			}
			else
			{
				final String response = post.getResponseBodyAsString(10000);
				System.err.println(response);
				final Map<String, String> responseMap = paymentMethod.getResponseParams(response);
				for (final Map.Entry<String, String> entrySet : responseMap.entrySet())
				{
					System.out.println(entrySet.getKey() + " " + entrySet.getValue());
				}
			}
		}
		catch (final Exception e)
		{
			System.err.println(e);
		}
		finally
		{
			post.releaseConnection();
		}
	}


	@Test
	public void checkResponseParametersForErrorsTest()
	{
		final Map<String, String> paramMap = new HashMap<String, String>();
		// check with empty Map => no errors no problems
		paymentMethod.checkResponseParametersForErrors(paramMap);

		// add some errors
		paramMap.put(ResponseParams.ERRORS, "2");
		// check without error messages
		try
		{
			paymentMethod.checkResponseParametersForErrors(paramMap);
			Assert.fail("Expected a WirecardException du to errors in Map.");
		}
		catch (final WirecardException e1)
		{
			// everything fine here
		}

		// add some error messages
		paramMap.put("error.1.message", "Fingerprint was invalid");
		paramMap.put("error.2.message", "Parameter XY was missing");

		try
		{
			paymentMethod.checkResponseParametersForErrors(paramMap);
			Assert.fail("Expected a WirecardException du to errors in Map.");
		}
		catch (final WirecardException e)
		{
			// everything fine here
		}
	}


}
