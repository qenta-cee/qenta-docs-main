
package de.hmmh.wirecard.methods.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import de.hybris.platform.core.PK;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.CreditCardPaymentInfoModel;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.payment.model.PaymentTransactionEntryModel;
import de.hybris.platform.payment.model.PaymentTransactionModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.i18n.impl.DefaultI18NService;
import de.hybris.platform.servicelayer.internal.model.impl.LocaleProvider;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.session.Session;
import de.hybris.platform.servicelayer.session.SessionService;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import de.hmmh.wirecard.constants.WirecardConstants;
import de.hmmh.wirecard.dao.impl.DefaultPaymentRequestSettingsDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentModeDAO;
import de.hmmh.wirecard.exception.WirecardException;
import de.hmmh.wirecard.model.PaymentRequestSettingsModel;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.strategies.TransactionIdGenerator;
import de.hmmh.wirecard.strategies.WirecardCreateOrderFromCartStrategy;
import de.hmmh.wirecard.strategies.impl.DefaultTransactionIdGenerator;


/**
 * @author Christoph.Meyer
 * 
 */
public class WirecardCCPaymentMethodTest
{

	private WirecardCCardPaymentMethod paymentMethod;

	@Mock
	private DefaultWirecardPaymentModeDAO paymentModeDAO;

	@Mock
	private DefaultI18NService i18NService;

	@Mock
	private LocaleProvider localeProvider;

	@Mock
	private DefaultPaymentRequestSettingsDAO paymentRequestSettingsDAO;

	@Mock
	private WirecardPaymentModeModel paymentMode;

	@Mock
	private ModelService modelService;

	@Mock
	private Configuration configuration;

	@Mock
	private PaymentTransactionModel transaction;

	@Mock
	private ConfigurationService configService;

	@Mock
	private CreditCardPaymentInfoModel paymentInfo;

	@Mock
	private CurrencyModel euro;

	@Mock
	private HttpClient httpClient;

	@Mock
	private HttpServletRequest request;

	@Mock
	private CartModel cart;

	@Mock
	private UserModel customer;

	@Mock
	private SessionService sessionService;

	@Mock
	private Session currentSession;

	@Mock
	private AddressModel billingAddress;

	@Mock
	private LanguageModel sessionLanguage;
	@Mock
	private WirecardCreateOrderFromCartStrategy createOrderFromCartStrategy;

	TransactionIdGenerator transactionIdGenerator;

	@Before
	public void setUp() throws HttpException, IOException
	{
		MockitoAnnotations.initMocks(this);

		given(configService.getConfiguration()).willReturn(configuration);
		given(configuration.getString(WirecardConstants.ConfigParams.QPAY_INIT_URL, null)).willReturn("https://test.uri");
		given(configuration.getString(WirecardConstants.ConfigParams.FRONTEND_CSS_PATH, null)).willReturn("any.css");

		given(configuration.getString(WirecardConstants.ConfigParams.RESPONSE_URL_CONFIRM, null))
				.willReturn("https://response.uri");

		paymentMethod = mock(WirecardCCardPaymentMethod.class, Mockito.CALLS_REAL_METHODS);
		paymentMethod.setWirecardPaymentModeDao(paymentModeDAO);

		transactionIdGenerator = new DefaultTransactionIdGenerator();
		paymentMethod.setTransactionIdGenerator(transactionIdGenerator);

		paymentMethod.setSessionService(sessionService);
		given(currentSession.getAttribute("jsessionid")).willReturn("sessionId");
		given(sessionService.getCurrentSession()).willReturn(currentSession);

		given(paymentMethod.getHttpClient()).willReturn(httpClient);

		final List<PaymentRequestSettingsModel> prSettings = new LinkedList<PaymentRequestSettingsModel>();
		final PaymentRequestSettingsModel paymentRequestSettingsModel = new PaymentRequestSettingsModel();
		paymentRequestSettingsModel.setShopID("qmore");
		prSettings.add(paymentRequestSettingsModel);
		given(paymentRequestSettingsDAO.find()).willReturn(prSettings);
		paymentMethod.setPaymentRequestSettingsDAO(paymentRequestSettingsDAO);

		paymentMethod.setI18NService(i18NService);
		given(localeProvider.getCurrentDataLocale()).willReturn(Locale.ENGLISH);
		given(paymentMethod.getLocaleProvider()).willReturn(localeProvider);

		// use this to modify the postmethod within the call of the
		// executeMethod on mocked httpClient
		doAnswer(new Answer<Integer>()
		{
			@Override
			public Integer answer(final InvocationOnMock invocation) throws Throwable
			{
				final Object[] args = invocation.getArguments();
				final PostMethod postMethod = (PostMethod) args[0];
				// take parameter and reflect to response body
				final byte[] responseBody = fakeResponseBody(postMethod);
				ReflectionTestUtils.setField(postMethod, "responseBody", responseBody);
				return Integer.valueOf(1);
			}
		}).when(httpClient).executeMethod((PostMethod) anyObject());

		given(paymentMode.getChannelId()).willReturn("12345");
		given(cart.getPaymentMode()).willReturn(paymentMode);

		given(paymentModeDAO.find(Collections.singletonMap("code", "CC"))).willReturn(Collections.singletonList(paymentMode));

		given(euro.getIsocode()).willReturn("EUR");

		given(transaction.getOrder()).willReturn(cart);
		given(transaction.getInfo()).willReturn(paymentInfo);

		given(paymentInfo.getBillingAddress()).willReturn(billingAddress);
		given(customer.getUid()).willReturn("info@bla.de");
		given(paymentInfo.getUser()).willReturn(customer);
		given(sessionLanguage.getIsocode()).willReturn("de");
		given(customer.getSessionLanguage()).willReturn(sessionLanguage);
		given(cart.getUser()).willReturn(customer);
		given(cart.getCode()).willReturn("245454545");

		given(customer.getPk()).willReturn(PK.createPK(1));

		paymentMethod.setConfigurationService(configService);
		paymentMethod.setModelService(modelService);

		given(transaction.getPlannedAmount()).willReturn(new BigDecimal("10.00"));
		given(transaction.getCurrency()).willReturn(euro);

		given(modelService.create(PaymentTransactionEntryModel.class)).willReturn(new PaymentTransactionEntryModel());

	}

	@Test
	public void testAuthorizePaymentFail()
	{

		given(transaction.getPlannedAmount()).willReturn(null);
		given(transaction.getCurrency()).willReturn(null);

		try
		{
			paymentMethod.authorizePayment(transaction, request);
			fail("no amount defined, exception expected!");
		}
		catch (final WirecardException ex)
		{
			// expected, with missing amount, currency.
		}
	}

	@Test
	public void testAuthorizePayment()
	{

		final PaymentTransactionEntryModel entry = paymentMethod.authorizePayment(transaction, request);
		assertNotNull(entry);
	}

	/**
	 * @param postMethod
	 * @return
	 */
	protected byte[] fakeResponseBody(final PostMethod postMethod)
	{
		final String reflectParams[] =
		{ "IDENTIFICATION.TRANSACTIONID" };
		final String responseParams[] =
		{ "PROCESSING.RESULT=ACK" };
		final ArrayList<String> bodyElements = new ArrayList<String>();
		for (final String param : reflectParams)
		{
			bodyElements.add(new StringBuilder(param).append('=')
					.append(postMethod.getParameter("IDENTIFICATION.TRANSACTIONID").getValue()).toString());
		}
		bodyElements.addAll(Arrays.asList(responseParams));
		return StringUtils.join(bodyElements, '&').getBytes();
	}
}
