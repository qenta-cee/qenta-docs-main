
package de.hmmh.wirecard.services.impl;

import static org.junit.Assert.assertNotNull;

import de.hybris.platform.servicelayer.ServicelayerTest;

import javax.annotation.Resource;

import org.junit.Test;

import de.hmmh.wirecard.services.WirecardService;

/**
 * @author Christoph.Meyer
 *
 */
public class WirecardServiceIntegrationTest extends ServicelayerTest {

	@Resource
	private WirecardService wirecardService;

	@Test
	public void testBasic() {
		assertNotNull(wirecardService);
	}

}
