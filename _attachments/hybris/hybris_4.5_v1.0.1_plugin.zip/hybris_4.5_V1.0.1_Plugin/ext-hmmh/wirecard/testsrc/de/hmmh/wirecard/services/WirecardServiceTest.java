
package de.hmmh.wirecard.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

import de.hybris.platform.commerceservices.order.CommerceCartService;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.core.model.type.ComposedTypeModel;
import de.hybris.platform.servicelayer.model.ModelService;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentInfoDAO;
import de.hmmh.wirecard.dao.impl.DefaultWirecardPaymentModeDAO;
import de.hmmh.wirecard.enums.WirecardPaymentMethodId;
import de.hmmh.wirecard.methods.WirecardPaymentMethod;
import de.hmmh.wirecard.methods.impl.WirecardCCardPaymentMethod;
import de.hmmh.wirecard.model.WirecardPaymentModeModel;
import de.hmmh.wirecard.services.impl.DefaultWirecardService;


/**
 * @author Christoph.Meyer
 * 
 */
public class WirecardServiceTest
{

	private DefaultWirecardService wirecardService;

	@Mock
	private ModelService modelService;

	@Mock
	private WirecardPaymentModeModel paymentModeCCard;

	@Mock
	private PaymentInfoModel paymentInfoCC;

	@Mock
	private CurrencyModel euro;

	@Mock
	private DefaultWirecardPaymentInfoDAO paymentInfoDAO;

	@Mock
	private WirecardCCardPaymentMethod ccMethod;

	@Mock
	private ComposedTypeModel composedTypeModelCC;

	@Mock
	private DefaultWirecardPaymentModeDAO paymentModeDao;

	@Mock
	private CommerceCartService commerceCartService;

	private Map<String, WirecardPaymentMethod> methods;

	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
		final CartModel cart = new CartModel();
		methods = new HashMap<String, WirecardPaymentMethod>();
		methods.put("CCARD", ccMethod);

		given(paymentInfoCC.getPaymentType()).willReturn(WirecardPaymentMethodId.CCARD);

		given(paymentModeCCard.getWirecardPaymentMethodId()).willReturn(WirecardPaymentMethodId.CCARD);
		given(paymentModeCCard.getActive()).willReturn(Boolean.TRUE);
		given(paymentModeCCard.getCode()).willReturn("ccard");

		given(ccMethod.getConfig(cart)).willReturn(paymentModeCCard);

		given(paymentModeCCard.getPaymentInfoType()).willReturn(composedTypeModelCC);
		given(composedTypeModelCC.getCode()).willReturn("CreditCardPaymentInfo");

		given(euro.getIsocode()).willReturn("EUR");

		wirecardService = mock(DefaultWirecardService.class, Mockito.CALLS_REAL_METHODS);
		wirecardService.setWirecardPaymentInfoDao(paymentInfoDAO);
		wirecardService.setWirecardPaymentModeDao(paymentModeDao);
		wirecardService.setMethods(methods);
		wirecardService.setModelService(modelService);
	}

	@Test
	public void testGetPaymentModes()
	{
		final List<WirecardPaymentModeModel> list = Collections.singletonList(new WirecardPaymentModeModel());
		given(paymentModeDao.find(Collections.singletonMap("active", Boolean.TRUE))).willReturn(list);
		final List<WirecardPaymentModeModel> modes = wirecardService.getPaymentModes();
		assertEquals(1, modes.size());
	}

	@Test
	public void testIsModeApplicable()
	{
		assertTrue(wirecardService.isPaymentModeApplicable(null, null));
	}

}
