/**
 * 
 */
package de.hmmh.paymentfacades.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Christoph.Meyer
 * 
 */
@Controller
public class WirecardTestController {
	private static final Logger LOG = Logger.getLogger(WirecardTestController.class);

	@RequestMapping("/test")
	public String fakeWirecard(final Model model, final HttpServletRequest request) {

		final String paymentCode = request.getParameter("PAYMENT.CODE");
		final String subscriptionId = request.getParameter("ACCOUNT.REGISTRATION");
		final String transactionId = request.getParameter("IDENTIFICATION.TRANSACTIONID");
		LOG.debug(new StringBuilder("fakeWirecard was called for type: ").append(paymentCode).toString());
		if ("CC.RG".equals(paymentCode) && subscriptionId == null) {
			LOG.debug("sending redirectURL for CC.RG without subscriptionId");
			model.addAttribute("uniqueId", String.valueOf(System.currentTimeMillis()));
			model.addAttribute("transactionId", transactionId);
			return "redirectCCPA";
		} else if ("CC.DB".equals(paymentCode) && subscriptionId == null) {
			LOG.debug("sending response for CC.DB");
			model.addAttribute("uniqueId", String.valueOf(System.currentTimeMillis()));
			model.addAttribute("transactionId", transactionId);
			return "redirectCCDB_no3d";
		}
		return "index";
	}

	@RequestMapping("/frontend/{method}")
	public String fakeWirecard(final Model model, final HttpServletRequest request, @PathVariable("method") final String paymentCode) {
		LOG.debug(new StringBuilder("fakeWirecard frontend was called for type: ").append(paymentCode));

		final String transactionId = request.getParameter("IDENTIFICATION.TRANSACTIONID");

		model.addAttribute("uniqueId", String.valueOf(System.currentTimeMillis()));
		model.addAttribute("transactionId", transactionId);
		model.addAttribute("params", request.getParameterMap());

		return "iframeCCPA";
	}

}
