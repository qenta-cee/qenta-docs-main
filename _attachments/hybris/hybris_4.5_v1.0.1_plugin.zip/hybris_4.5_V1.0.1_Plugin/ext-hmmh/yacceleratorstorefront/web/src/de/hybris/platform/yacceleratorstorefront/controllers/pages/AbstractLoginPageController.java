/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.controllers.pages;

import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.commercefacades.user.data.TitleData;
import de.hybris.platform.servicelayer.i18n.I18NService;
import de.hybris.platform.yacceleratorstorefront.breadcrumb.Breadcrumb;
import de.hybris.platform.yacceleratorstorefront.controllers.util.RequestProcessHelper;
import de.hybris.platform.yacceleratorstorefront.forms.LoginForm;
import de.hybris.platform.yacceleratorstorefront.forms.RegisterForm;
import de.hybris.platform.yacceleratorstorefront.security.AutoLoginStrategy;

import java.util.Collection;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * Abstract base class for login page controllers
 */
public abstract class AbstractLoginPageController extends AbstractPageController
{
	@Autowired
	private CustomerFacade customerFacade;

	@Autowired
	private UserFacade userFacade;

	@Autowired
	private AutoLoginStrategy autoLoginStrategy;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private I18NService i18nService;


	@RequestMapping(method = RequestMethod.GET)
	public String getLogin(final Model model, final HttpServletRequest request) throws CMSItemNotFoundException
	{
		model.addAttribute(new RegisterForm());
		final LoginForm loginForm = new LoginForm();
		final String username = (String) request.getAttribute("j_username");
		loginForm.setJ_username(username);
		model.addAttribute(loginForm);
		storeCmsPageInModel(model, getLoginCmsPage());

		final Breadcrumb loginBreadcrumbEntry = new Breadcrumb("#", messageSource.getMessage("header.link.login", null,
				i18nService.getCurrentLocale()), null);
		model.addAttribute("breadcrumbs", Collections.singletonList(loginBreadcrumbEntry));
		return getLoginView();
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String register(@Valid final RegisterForm form, final BindingResult bindingResult, final Model model,
			final HttpServletRequest request, final HttpServletResponse response) throws CMSItemNotFoundException
	{
		if (!RequestProcessHelper.processRegisterUserRequest(form, bindingResult, model, request, response, customerFacade,
				autoLoginStrategy))
		{
			storeCmsPageInModel(model, getLoginCmsPage());
			return getLoginView();
		}

		return REDIRECT_PREFIX + getSuccessRedirect();
	}

	@ModelAttribute("titles")
	public Collection<TitleData> getTitles()
	{
		return userFacade.getTitles();
	}

	protected abstract String getLoginView();

	protected abstract String getSuccessRedirect();

	protected abstract AbstractPageModel getLoginCmsPage() throws CMSItemNotFoundException;
}
