/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.servlets.btg;

import de.hybris.platform.btg.enums.BTGConditionEvaluationScope;
import de.hybris.platform.btg.enums.BTGEvaluationMethod;
import de.hybris.platform.btg.enums.BTGResultScope;
import de.hybris.platform.btg.segment.SegmentEvaluationException;
import de.hybris.platform.btg.servicelayer.services.evaluator.impl.SessionBTGEvaluationContextProvider;
import de.hybris.platform.btg.services.BTGEvaluationService;
import de.hybris.platform.btg.services.BTGResultService;
import de.hybris.platform.btg.services.impl.BTGEvaluationContext;
import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.cms2.model.preview.CMSPreviewTicketModel;
import de.hybris.platform.cms2.model.preview.PreviewDataModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSPreviewService;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FilterSpringUtil;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.filter.OncePerRequestFilter;


/**
 * Filter that evaluates the BTG context for the current request
 */
public class BTGSegmentFilter extends OncePerRequestFilter implements CMSFilter
{
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(BTGSegmentFilter.class);

	@Override
	protected void doFilterInternal(final HttpServletRequest httpRequest, final HttpServletResponse httpResponse,
			final FilterChain filterChain) throws ServletException, IOException
	{
		if (!Boolean.parseBoolean(httpRequest.getParameter("proceedLogout")))
		{
			final BTGEvaluationService btgEvaluationService = getBTGEvaluationService(httpRequest);
			final BTGResultService btgResultService = getBTGResultService(httpRequest);
			final UserService userService = getUserService(httpRequest);
			final UserModel currentUser = userService.getCurrentUser();
			final CMSSiteService cmsSiteService = getCMSSiteService(httpRequest);
			final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();
			try
			{
				BTGEvaluationContext context = null;
				if (isPreviewDataModelValid(httpRequest))
				{
					//preview for BTGCockpit
					//always invoke FULL evaluation method and store results per session   
					context = new BTGEvaluationContext(BTGConditionEvaluationScope.ONLINE, BTGEvaluationMethod.FULL,
							BTGResultScope.SESSION);
				}
				else
				{
					//process normal request (i.e. normal browser non-btgcockpit request)
					//the evaluation method will be taken from segment!
					context = new BTGEvaluationContext(BTGConditionEvaluationScope.ONLINE, null);
				}
				//right now we basically invalidate all results, because we don't specify  BTGRuleType 
				//i.e. when user would like to invalidate only some type of rules he should specify this parameter
				btgResultService.invalidateEvaluationResults(currentSite, currentUser, context, null);
				btgEvaluationService.evaluateAllSegments(currentUser, currentSite, context);

				getSessionService(httpRequest).setAttribute(SessionBTGEvaluationContextProvider.BTG_CURRENT_EVALUATION_CONTEXT,
						context);
			}
			catch (final SegmentEvaluationException e)
			{
				throw new ServletException(e.getMessage(), e);
			}
		}
		filterChain.doFilter(httpRequest, httpResponse);
	}

	/**
	 * Retrieves {@link CMSFilter#PREVIEW_TICKET_ID_PARAM} from current request
	 * 
	 * @param httpRequest
	 *           current request
	 * @return current ticket id
	 */
	protected String getPreviewTicketId(final HttpServletRequest httpRequest)
	{
		String id = httpRequest.getParameter(PREVIEW_TICKET_ID_PARAM);
		if (StringUtils.isBlank(id))
		{
			id = getSessionService(httpRequest).getAttribute(PREVIEW_TICKET_ID_PARAM);
		}
		return id;
	}

	/**
	 * Checks whether current Preview Data is valid (not removed)
	 * 
	 * @param httpRequest
	 *           current request
	 * @return true whether is valid otherwise false
	 */
	protected boolean isPreviewDataModelValid(final HttpServletRequest httpRequest)
	{
		return getPreviewData(getPreviewTicketId(httpRequest), httpRequest) != null;
	}

	/**
	 * Retrieves current Preview Data according to given ticked id
	 * 
	 * @param ticketId
	 *           current ticket id
	 * @param httpRequest
	 *           current request
	 * @return current Preview Data attached to given ticket if any otherwise null
	 */
	protected PreviewDataModel getPreviewData(final String ticketId, final HttpServletRequest httpRequest)
	{
		PreviewDataModel ret = null;
		final CMSPreviewTicketModel previewTicket = getCmsPreviewService(httpRequest).getPreviewTicket(ticketId);
		if (previewTicket != null)
		{
			ret = previewTicket.getPreviewData();
		}
		return ret;
	}

	protected CMSSiteService getCMSSiteService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "cmsSiteService", CMSSiteService.class);
	}

	protected SessionService getSessionService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "sessionService", SessionService.class);
	}

	protected UserService getUserService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "userService", UserService.class);
	}

	protected CMSPreviewService getCmsPreviewService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "cmsPreviewService", CMSPreviewService.class);
	}

	protected BTGEvaluationService getBTGEvaluationService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "btgEvaluationService", BTGEvaluationService.class);
	}

	protected BTGResultService getBTGResultService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "btgResultService", BTGResultService.class);
	}
}
