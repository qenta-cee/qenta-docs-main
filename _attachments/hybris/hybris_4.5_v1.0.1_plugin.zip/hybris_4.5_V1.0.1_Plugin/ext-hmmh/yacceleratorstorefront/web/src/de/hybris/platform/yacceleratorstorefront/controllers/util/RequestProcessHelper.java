/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */

package de.hybris.platform.yacceleratorstorefront.controllers.util;

import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.yacceleratorstorefront.forms.LoginForm;
import de.hybris.platform.yacceleratorstorefront.forms.RegisterForm;
import de.hybris.platform.yacceleratorstorefront.security.AutoLoginStrategy;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FlashScope;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;


/**
 */
public class RequestProcessHelper
{
	protected static final Logger LOG = Logger.getLogger(RequestProcessHelper.class);

	public static boolean processRegisterUserRequest(final RegisterForm form, final BindingResult bindingResult,
			final Model model, final HttpServletRequest request, final HttpServletResponse response,
			final CustomerFacade customerFacade, final AutoLoginStrategy autoLoginStrategy) throws CMSItemNotFoundException
	{
		if (bindingResult.hasErrors())
		{
			model.addAttribute(new LoginForm());
			GlobalMessages.addErrorMessage(model, "form.global.error");
			return false;
		}
		final RegisterData data = new RegisterData();
		data.setFirstName(form.getFirstName());
		data.setLastName(form.getLastName());
		data.setLogin(form.getEmail());
		data.setPassword(form.getPwd());
		data.setTitleCode(form.getTitleCode());
		try
		{
			customerFacade.register(data);
			autoLoginStrategy.login(form.getEmail(), form.getPwd(), request, response);
			FlashScope.getCurrent(request).put(GlobalMessages.CONF_MESSAGES_HOLDER,
					Collections.singletonList("registration.confirmation.message.title"));
		}
		catch (final DuplicateUidException e)
		{
			LOG.warn("registration failed: " + e);
			model.addAttribute(new LoginForm());
			bindingResult.rejectValue("email", "registration.error.account.exists.title");
			GlobalMessages.addErrorMessage(model, "form.global.error");
			return false;
		}
		return true;
	}

}
