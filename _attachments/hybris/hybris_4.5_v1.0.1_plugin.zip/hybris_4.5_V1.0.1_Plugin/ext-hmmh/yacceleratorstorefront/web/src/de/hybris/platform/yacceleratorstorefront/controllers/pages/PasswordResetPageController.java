/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.controllers.pages;

import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commerceservices.customer.TokenInvalidatedException;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.yacceleratorstorefront.breadcrumb.impl.SimpleBreadcrumbBuilder;
import de.hybris.platform.yacceleratorstorefront.constants.WebConstants;
import de.hybris.platform.yacceleratorstorefront.controllers.ControllerConstants;
import de.hybris.platform.yacceleratorstorefront.controllers.util.GlobalMessages;
import de.hybris.platform.yacceleratorstorefront.forms.ForgottenPwdForm;
import de.hybris.platform.yacceleratorstorefront.forms.UpdatePwdForm;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FlashScope;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * Controller for the forgotten password pages. Supports requesting a password reset email as well as changing the
 * password once you have got the token that was sent via email.
 */
@Controller
@Scope("tenant")
@RequestMapping(value = "/login/pw")
public class PasswordResetPageController extends AbstractPageController
{
	private static final Logger LOG = Logger.getLogger(PasswordResetPageController.class);

	private static final String REDIRECT_LOGIN = "redirect:/login";
	private static final String REDIRECT_HOME = "redirect:/";

	private static final String UPDATE_PWD_CMS_PAGE = "updatePassword";
	private static final String FORGOT_PASSWORD_CMS_PAGE = "forgottenPassword";

	@Autowired
	private CustomerFacade customerFacade;

	@Autowired
	SimpleBreadcrumbBuilder simpleBreadcrumbBuilder;

	@RequestMapping(value = "/request", method = RequestMethod.GET)
	public String getPasswordRequest(final Model model) throws CMSItemNotFoundException
	{
		model.addAttribute(new ForgottenPwdForm());
		storeCmsPageInModel(model, getContentPageForLabelOrId(FORGOT_PASSWORD_CMS_PAGE));
		model.addAttribute(WebConstants.BREADCRUMBS_KEY, simpleBreadcrumbBuilder.getBreadcrumbs("forgottenPwd.title"));
		return ControllerConstants.Views.Pages.Password.PasswordResetRequestPage;
	}

	@RequestMapping(value = "/request", method = RequestMethod.POST)
	public String passwordRequest(@Valid final ForgottenPwdForm form, final BindingResult bindingResult, final Model model,
			final HttpServletRequest request) throws CMSItemNotFoundException
	{
		if (bindingResult.hasErrors())
		{
			prepareErrorMessage(model, FORGOT_PASSWORD_CMS_PAGE);
		}
		else
		{
			try
			{
				customerFacade.forgottenPassword(form.getEmail());
				FlashScope.getCurrent(request).put(GlobalMessages.CONF_MESSAGES_HOLDER,
						Collections.singletonList("account.confirmation.forgotten.password.link.sent"));
				return REDIRECT_LOGIN;
			}
			catch (final UnknownIdentifierException e)
			{
				prepareErrorMessage(model, FORGOT_PASSWORD_CMS_PAGE);
				bindingResult.rejectValue("email", "account.error.account.not.found");
			}
		}
		model.addAttribute(WebConstants.BREADCRUMBS_KEY, simpleBreadcrumbBuilder.getBreadcrumbs("forgottenPwd.title"));
		return ControllerConstants.Views.Pages.Password.PasswordResetRequestPage;
	}

	@RequestMapping(value = "/change", method = RequestMethod.GET)
	public String getChangePassword(@RequestParam(required = false) final String token, final Model model)
			throws CMSItemNotFoundException
	{
		if (StringUtils.isBlank(token))
		{
			return REDIRECT_HOME;
		}
		final UpdatePwdForm form = new UpdatePwdForm();
		form.setToken(token);
		model.addAttribute(form);
		storeCmsPageInModel(model, getContentPageForLabelOrId(UPDATE_PWD_CMS_PAGE));
		model.addAttribute(WebConstants.BREADCRUMBS_KEY, simpleBreadcrumbBuilder.getBreadcrumbs("updatePwd.title"));
		return ControllerConstants.Views.Pages.Password.PasswordResetChangePage;
	}

	@RequestMapping(value = "/change", method = RequestMethod.POST)
	public String changePassword(@Valid final UpdatePwdForm form, final BindingResult bindingResult, final Model model,
			final HttpServletRequest request) throws CMSItemNotFoundException
	{
		if (bindingResult.hasErrors())
		{
			prepareErrorMessage(model, UPDATE_PWD_CMS_PAGE);
			return ControllerConstants.Views.Pages.Password.PasswordResetChangePage;
		}
		if (!StringUtils.isBlank(form.getToken()))
		{
			try
			{
				customerFacade.updatePassword(form.getToken(), form.getPwd());
				FlashScope.getCurrent(request).put(GlobalMessages.CONF_MESSAGES_HOLDER,
						Collections.singletonList("account.confirmation.password.updated"));
			}
			catch (final TokenInvalidatedException e)
			{
				FlashScope.getCurrent(request).put(GlobalMessages.ERROR_MESSAGES_HOLDER,
						Collections.singletonList("updatePwd.token.invalidated"));
			}
			catch (final RuntimeException e)
			{
				FlashScope.getCurrent(request).put(GlobalMessages.ERROR_MESSAGES_HOLDER,
						Collections.singletonList("updatePwd.token.invalid"));
			}
		}
		return REDIRECT_LOGIN;
	}

	/**
	 * Prepares the view to display an error message
	 * 
	 * @param model
	 * @param page
	 * @throws CMSItemNotFoundException
	 */
	protected void prepareErrorMessage(final Model model, final String page) throws CMSItemNotFoundException
	{
		GlobalMessages.addErrorMessage(model, "form.global.error");
		storeCmsPageInModel(model, getContentPageForLabelOrId(page));
	}
}
