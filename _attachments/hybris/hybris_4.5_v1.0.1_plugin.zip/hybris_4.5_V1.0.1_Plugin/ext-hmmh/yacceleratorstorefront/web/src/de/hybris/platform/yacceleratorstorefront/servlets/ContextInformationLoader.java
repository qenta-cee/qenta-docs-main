/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.servlets;

import de.hybris.platform.catalog.CatalogService;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.cms2.constants.Cms2Constants;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.cms2.model.preview.PreviewDataModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.security.PrincipalModel;
import de.hybris.platform.core.model.user.UserGroupModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.servicelayer.i18n.I18NService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.time.TimeService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.site.BaseSiteService;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FilterSpringUtil;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;


/**
 * Default context information loader
 */
public class ContextInformationLoader
{
	private static final Logger LOG = Logger.getLogger(ContextInformationLoader.class);

	// Private lock used to control instance creation
	private static final Object LOCK = new Object();

	private static ContextInformationLoader instance = null;

	public static ContextInformationLoader getInstance()
	{
		synchronized (LOCK)
		{
			if (instance == null)
			{
				instance = new ContextInformationLoader();
			}
		}
		return instance;
	}

	public CMSSiteModel getCurrentSite(final HttpServletRequest httpRequest)
	{
		return getCMSSiteService(httpRequest).getCurrentSite();
	}

	public void setCatalogVersions(final HttpServletRequest httpRequest)
	{
		try
		{
			final CMSSiteModel currentSiteModel = getCurrentSite(httpRequest);
			if (currentSiteModel != null)
			{
				getCMSSiteService(httpRequest).setCurrentSiteAndCatalogVersions(currentSiteModel, true);
			}
		}
		catch (final CMSItemNotFoundException e)
		{
			if (LOG.isDebugEnabled())
			{
				LOG.debug("Catalog has no active catalog version!", e);
			}
		}
	}

	public CMSSiteModel initializeSiteFromRequest(final HttpServletRequest httpRequest, final String absoluteURL)
	{
		try
		{
			final URL currentURL = new URL(absoluteURL);
			final CMSSiteService cmsSiteService = getCMSSiteService(httpRequest);
			final CMSSiteModel cmsSiteModel = cmsSiteService.getSiteForURL(currentURL);
			if (cmsSiteModel != null)
			{
				getBaseSiteService(httpRequest).setCurrentBaseSite(cmsSiteModel, true);
				return cmsSiteModel;
			}
		}
		catch (final MalformedURLException e)
		{
			if (LOG.isDebugEnabled())
			{
				LOG.debug("Cannot find CMSSite associated with current URL ( " + absoluteURL
						+ " - check whether this is correct URL) !");
			}
		}
		catch (final CMSItemNotFoundException e)
		{
			LOG.warn("Cannot find CMSSite associated with current URL (" + absoluteURL + ")!");
		}
		return null;
	}


	public void initializePreviewRequest(final HttpServletRequest httpRequest, final PreviewDataModel previewDataModel)
	{
		loadActiveBaseSite(httpRequest, previewDataModel);
		loadCatalogVersions(httpRequest, previewDataModel.getCatalogVersions());
	}

	public void loadActiveBaseSite(final HttpServletRequest httpRequest, final PreviewDataModel previewDataModel)
	{
		final BaseSiteService baseSiteService = getBaseSiteService(httpRequest);
		if (previewDataModel.getActiveSite() == null)
		{
			LOG.warn("Could not set active site. Reason: No active site was selected!");
		}
		else
		{
			baseSiteService.setCurrentBaseSite(previewDataModel.getActiveSite(), true);
		}
	}

	public void loadCatalogVersions(final HttpServletRequest httpRequest, final Collection<CatalogVersionModel> catalogVersions)
	{
		getCatalogVersionService(httpRequest).setSessionCatalogVersions(catalogVersions);
	}

	protected void loadFakeUser(final HttpServletRequest httpRequest, final UserModel fakeUser)
	{
		final UserService userService = getUserService(httpRequest);
		final UserModel currentUser = userService.getCurrentUser();
		if (fakeUser != null && !fakeUser.equals(currentUser))
		{
			userService.setCurrentUser(fakeUser);
		}
	}

	protected void loadFakeUserGroup(final HttpServletRequest httpRequest, final PreviewDataModel previewDataModel)
	{
		if (previewDataModel.getUser() == null && previewDataModel.getUserGroup() != null)
		{
			UserModel userWithinDesiredGroup = null;
			final UserGroupModel fakeUserGroup = previewDataModel.getUserGroup();
			for (final PrincipalModel principalModel : fakeUserGroup.getMembers())
			{
				if (principalModel instanceof UserModel)
				{
					userWithinDesiredGroup = (UserModel) principalModel;
					break;
				}
			}
			if (userWithinDesiredGroup != null)
			{
				loadFakeUser(httpRequest, userWithinDesiredGroup);
			}
		}
	}

	protected void loadFakeLanguage(final HttpServletRequest httpRequest, final LanguageModel languageModel)
	{
		if (languageModel != null)
		{
			getI18NService(httpRequest).setCurrentLocale(new Locale(languageModel.getIsocode()));
		}
	}

	protected void storePreviewTicketIDWithinSession(final HttpServletRequest httpRequest)
	{
		final String ticketId = httpRequest.getParameter(CMSFilter.PREVIEW_TICKET_ID_PARAM);
		if (StringUtils.isNotBlank(ticketId))
		{
			JaloSession.getCurrentSession().setAttribute(CMSFilter.PREVIEW_TICKET_ID_PARAM, ticketId);
		}
	}

	protected void loadFakeDate(final HttpServletRequest httpRequest, final Date fakeDate)
	{
		if (fakeDate != null)
		{
			getTimeService(httpRequest).setCurrentTime(fakeDate);
			JaloSession.getCurrentSession().setAttribute(Cms2Constants.PREVIEW_TIME, fakeDate);
		}
	}

	public void loadFakeContextInformation(final HttpServletRequest httpRequest, final PreviewDataModel previewData)
	{
		//set fake user
		loadFakeUser(httpRequest, previewData.getUser());
		//set fake user group
		loadFakeUserGroup(httpRequest, previewData);
		//set fake language
		loadFakeLanguage(httpRequest, previewData.getLanguage());
		//set fake date
		loadFakeDate(httpRequest, previewData.getTime());

		storePreviewTicketIDWithinSession(httpRequest);
	}

	public void storePreviewData(final HttpServletRequest httpRequest, final PreviewDataModel previewData)
	{
		final ModelService modelService = getModelService(httpRequest);
		if (previewData == null)
		{
			LOG.warn("Could not store preview data. Reason: Preview data was null.");
		}
		else
		{
			if (modelService == null)
			{
				LOG.warn("Could not store preview data. Reason: Model service was null.");
			}
			else
			{
				modelService.save(previewData);
			}
		}
	}

	protected CMSSiteService getCMSSiteService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "cmsSiteService", CMSSiteService.class);
	}

	protected BaseSiteService getBaseSiteService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "baseSiteService", BaseSiteService.class);
	}

	protected CatalogService getCatalogService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "catalogService", CatalogService.class);
	}

	protected CatalogVersionService getCatalogVersionService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "catalogVersionService", CatalogVersionService.class);
	}

	protected UserService getUserService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "userService", UserService.class);
	}

	protected I18NService getI18NService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "i18nService", I18NService.class);
	}

	protected ModelService getModelService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "modelService", ModelService.class);
	}

	protected TimeService getTimeService(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "timeService", TimeService.class);
	}
}
