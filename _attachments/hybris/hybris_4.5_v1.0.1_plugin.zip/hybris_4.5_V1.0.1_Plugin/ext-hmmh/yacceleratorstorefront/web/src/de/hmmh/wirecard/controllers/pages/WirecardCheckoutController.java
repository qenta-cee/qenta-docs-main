/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hmmh.wirecard.controllers.pages;

import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.yacceleratorstorefront.breadcrumb.impl.SimpleBreadcrumbBuilder;
import de.hybris.platform.yacceleratorstorefront.constants.WebConstants;
import de.hybris.platform.yacceleratorstorefront.controllers.ControllerConstants;
import de.hybris.platform.yacceleratorstorefront.controllers.pages.CheckoutController;
import de.hybris.platform.yacceleratorstorefront.controllers.util.GlobalMessages;
import de.hybris.platform.yacceleratorstorefront.forms.AddressForm;
import de.hybris.platform.yacceleratorstorefront.forms.PaymentDetailsForm;
import de.hybris.platform.yacceleratorstorefront.forms.PlaceOrderForm;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FlashScope;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import de.hmmh.paymentfacades.data.FinancialInstitutionData;
import de.hmmh.paymentfacades.data.PaymentModesData;
import de.hmmh.paymentfacades.data.WirecardCartData;
import de.hmmh.paymentfacades.data.WirecardPaymentModeData;
import de.hmmh.paymentfacades.facades.WirecardCheckoutFacade;
import de.hmmh.wirecard.controllers.WirecardResponseController;
import de.hmmh.wirecard.exception.WirecardException;


/**
 * CheckoutController
 */
@Controller
@Scope("tenant")
@RequestMapping(value = "/checkout")
public class WirecardCheckoutController extends CheckoutController
{
	/**
	 * 
	 */
	private static final String REDIRECT_URL = "redirectUrl";
	private static final String REQUEST = "request";
	private static final String POST_ACTION_URL = "httpPostActionUrl";

	protected static final Logger LOG = Logger.getLogger(WirecardCheckoutController.class);

	private static final String CHECKOUT_SUMMARY_CMS_PAGE = "checkoutSummaryPage";

	@Autowired
	private transient UserFacade userFacade;

	@Autowired
	private transient WirecardCheckoutFacade checkoutFacade;

	@Autowired
	private transient ProductFacade productFacade;

	@Autowired
	private transient SimpleBreadcrumbBuilder simpleBreadcrumbBuilder;

	@Autowired
	private transient SessionService sessionService;

	@Override
	@RequestMapping(value = "/summary", method = RequestMethod.GET)
	public String checkoutSummary(final Model model) throws CMSItemNotFoundException
	{

		// Try to set default delivery address and delivery mode
		checkoutFacade.setDeliveryAddressIfAvailable();
		checkoutFacade.setPaymentAddressIfAvailable();
		checkoutFacade.setDeliveryModeIfAvailable();
		checkoutFacade.setPaymentDetailsIfAvailable();

		// request is always in the model since superclass put it there
		final Map<String, Object> modelMap = model.asMap();
		final HttpServletRequest request = (HttpServletRequest) modelMap.get(WirecardCheckoutController.REQUEST);

		// check for wirecard response errors saved in session
		getWirecardResonseErrors(request.getSession(), model);

		sessionService.getCurrentSession().setAttribute("jsessionid", request.getSession().getId());

		final WirecardCartData cartData = checkoutFacade.getCheckoutCart();
		if (cartData != null)
		{

			if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
			{
				for (final OrderEntryData entry : cartData.getEntries())
				{
					final String productCode = entry.getProduct().getCode();
					final ProductData product = productFacade.getProductForCodeAndOptions(productCode,
							Arrays.asList(ProductOption.BASIC, ProductOption.PRICE));
					entry.setProduct(product);
				}
			}

			model.addAttribute("cartData", cartData);
			model.addAttribute("allItems", cartData.getEntries());
			model.addAttribute("deliveryAddress", cartData.getDeliveryAddress());
			model.addAttribute("paymentAddress", cartData.getPaymentAddress());
			model.addAttribute("deliveryMode", cartData.getDeliveryMode());
			model.addAttribute("paymentInfoData", cartData.getPaymentInfoData());

			model.addAttribute(new AddressForm());
			model.addAttribute(new PaymentDetailsForm());
			model.addAttribute(new PlaceOrderForm());

			storeCmsPageInModel(model, getContentPageForLabelOrId(CHECKOUT_SUMMARY_CMS_PAGE));
			model.addAttribute(WebConstants.BREADCRUMBS_KEY, simpleBreadcrumbBuilder.getBreadcrumbs("breadcrumb.cart"));
			return ControllerConstants.Views.Pages.Checkout.CheckoutSummaryPage;
		}
		return REDIRECT_PREFIX + "/cart";
	}

	/**
	 * @param session
	 * @param model
	 * 
	 */
	private void getWirecardResonseErrors(final HttpSession session, final Model model)
	{
		final List<String> messageKeys = (List<String>) session
				.getAttribute(WirecardResponseController.WIRECARD_SESSION_MESSAGE_HOLDER);
		if (messageKeys != null)
		{
			LOG.debug(new StringBuilder("Fetching ").append(messageKeys.size()).append(" wirecard errors from session ...")
					.toString());
			for (final String messageKey : messageKeys)
			{
				GlobalMessages.addErrorMessage(model, messageKey);
			}
			session.setAttribute(WirecardResponseController.WIRECARD_SESSION_MESSAGE_HOLDER, null);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/summary/setUpdatePaymentMode.json", method = RequestMethod.POST)
	public Map<String, Object> setPaymentMode(@RequestParam("paymentMode") final String paymentModeCode,
			@RequestParam("paymentInfo") final String paymentInfoCode,
			@RequestParam(value = "anonymizedParams", required = false) final String anonymizedParams,
			@RequestParam(value = "selFinancialInstitute", required = false) final String selFinancialInstitute)
	{

		// first set mode. it will be configured=false.
		// note: we might get "null" as code, this is to be used as null:
		final Map<String, String> params = new HashMap<String, String>();

		if (!StringUtils.isEmpty(anonymizedParams))
		{
			Map anonymizedMap;
			try
			{
				anonymizedMap = new ObjectMapper().readValue(anonymizedParams, HashMap.class);
				params.putAll(anonymizedMap);
			}
			catch (final JsonParseException e)
			{
				LOG.error(e);

			}
			catch (final IOException e)
			{
				LOG.error(e);
			}
		}

		params.put("selFinancialInstitute", selFinancialInstitute);
		final WirecardPaymentModeData data = checkoutFacade.setPaymentModeByCode(paymentModeCode,
				"null".equals(paymentInfoCode) ? null : paymentInfoCode, params);

		// start payment and possibly get a redirect URL (in case of
		// credit-/debitcard registration).
		// if we do not need to redirect, the paymentInfo will be
		// set to configured=true
		final String redirectUrl = checkoutFacade.startPayment();

		final Map<String, Object> result = new HashMap<String, Object>();
		result.put(REDIRECT_URL, redirectUrl);
		result.put("paymentMode", data);
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/summary/getFinancialInstitutes.json", method = RequestMethod.POST)
	public List<FinancialInstitutionData> getFinancialInstitutes(@RequestParam("paymentMode") final String paymentModeCode)
	{
		final List<FinancialInstitutionData> financialInstitutionDatas = checkoutFacade.getFinancialInstitutes(paymentModeCode);
		return financialInstitutionDatas;
	}



	@RequestMapping(value = "/summary/showPaymentDetails", method = RequestMethod.POST)
	public String showPaymentDetails(@RequestParam("paymentMode") final String paymentModeCode, final Model model)
	{
		return "";
	}

	@Override
	@RequestMapping(value = "/summary/placeOrder")
	public String placeOrder(@ModelAttribute("placeOrderForm") final PlaceOrderForm placeOrderForm, final Model model)
			throws CMSItemNotFoundException, InvalidCartException
	{

		LOG.info("Overridden placeOrder!");

		final WirecardCartData cartData = checkoutFacade.getCheckoutCart();

		// validate the cart
		final boolean invalid = validateCart(placeOrderForm, model, cartData);

		final Map<String, Object> modelMap = model.asMap();
		final HttpServletRequest request = (HttpServletRequest) modelMap.get(WirecardCheckoutController.REQUEST);

		if (invalid)
		{
			return checkoutSummary(model);
		}

		// at this point we try to debit or authorize the payment. As a result
		// we might get a redirect URL from the PSP for the customer to enter
		// the payment details. this can even happen when using an already
		// subscribed card, as there may be 3Dsecure passwords to be entered.
		try
		{
			final String orderNumber = checkoutFacade.createDesignatedOrderCode();
			LOG.debug("Order number generated for later use: " + orderNumber);
			final Map<String, String> redirectInfo = checkoutFacade.debitOrAuthorize(request);

			if (redirectInfo != null && StringUtils.isNotBlank(redirectInfo.get(REDIRECT_URL))
					|| StringUtils.isNotBlank(redirectInfo.get(POST_ACTION_URL)))
			{

				// there is a redirect/post url! we cannot finish the order but
				// send the customer away to wirecard payment. we will create the order
				// after we receive the async. response.
				LOG.debug("about to redirect in iframe. session is: " + request.getSession().getId());

				FlashScope.getCurrent(request).put(REDIRECT_URL, redirectInfo.get(REDIRECT_URL));
				FlashScope.getCurrent(request).put("postUrl", redirectInfo.get(POST_ACTION_URL));
				redirectInfo.remove(REDIRECT_URL);
				redirectInfo.remove(POST_ACTION_URL);
				FlashScope.getCurrent(request).put("postParams", redirectInfo);

			}
			else
			{
				return finishPlaceOrder(placeOrderForm, model, request);
			}
			return REDIRECT_PREFIX + "/checkout/summary";
		}
		catch (final WirecardException wirecardException)
		{
			FlashScope.getCurrent(request).put(GlobalMessages.ERROR_MESSAGES_HOLDER,
					Collections.singletonList(wirecardException.getMessageKey()));
			return REDIRECT_PREFIX + "/checkout/summary";
		}
	}

	/**
	 * Checks the cartData for empty objects and adds error messages when needed to the Model.
	 * 
	 * @param placeOrderForm
	 * @param model
	 * @param cartData
	 * @return <code>true</code> if its invalid, <code>false</code> if its valid.
	 */
	protected boolean validateCart(final PlaceOrderForm placeOrderForm, final Model model, final WirecardCartData cartData)
	{

		boolean invalid = false;
		if (cartData == null)
		{
			GlobalMessages.addErrorMessage(model, "checkout.cartdata.null");
			invalid = true;
			return invalid;
		}

		if (cartData.getDeliveryAddress() == null)
		{
			GlobalMessages.addErrorMessage(model, "checkout.deliveryAddress.notSelected");
			invalid = true;
		}

		if (cartData.getPaymentAddress() == null)
		{
			GlobalMessages.addErrorMessage(model, "checkout.paymentAddress.notSelected");
			invalid = true;
		}

		if (cartData.getDeliveryMode() == null)
		{
			GlobalMessages.addErrorMessage(model, "checkout.deliveryMethod.notSelected");
			invalid = true;
		}

		if (cartData.getPaymentInfoData() == null || !cartData.getPaymentInfoData().isConfigured())
		{
			GlobalMessages.addErrorMessage(model, "checkout.paymentMethod.notSelected");
			invalid = true;
		}

		if (!placeOrderForm.isTermsCheck())
		{
			GlobalMessages.addErrorMessage(model, "checkout.error.terms.not.accepted");
			invalid = true;
		}
		return invalid;
	}

	public String finishPlaceOrder(@ModelAttribute("placeOrderForm") final PlaceOrderForm placeOrderForm, final Model model,
			final HttpServletRequest request) throws CMSItemNotFoundException, InvalidCartException
	{
		LOG.debug("start placing order!");
		final OrderData orderData = checkoutFacade.placeOrder();
		if (orderData == null)
		{
			FlashScope.getCurrent(request).put(GlobalMessages.ERROR_MESSAGES_HOLDER,
					Collections.singletonList("checkout.placeOrder.failed"));
			return REDIRECT_PREFIX + "/checkout/summary";
		}
		return REDIRECT_PREFIX + "/checkout/orderConfirmation/" + orderData.getCode();
	}

	@Override
	@ResponseBody
	@RequestMapping(value = "/summary/setDeliveryAddress.json", method = RequestMethod.POST)
	public CartData setDeliveryAddress(@RequestParam(value = "addressId") final String addressId)
	{
		AddressData addressData = null;

		final List<AddressData> deliveryAddresses = userFacade.getAddressBook();
		for (final AddressData deliveryAddress : deliveryAddresses)
		{
			if (deliveryAddress.getId().equals(addressId))
			{
				addressData = deliveryAddress;
				break;
			}
		}

		if (addressData != null)
		{
			if (checkoutFacade.setDeliveryAddress(addressData))
			{
				return checkoutFacade.getCheckoutCart();
			}
		}

		return null;
	}

	// //////////////////

	@ResponseBody
	@RequestMapping(value = "/summary/getPaymentAddresses.json", method = RequestMethod.POST)
	public List<AddressData> getPaymentAddresses()
	{
		final List<AddressData> paymentAddresses = userFacade.getAddressBook();
		return paymentAddresses == null ? Collections.<AddressData> emptyList() : paymentAddresses;
	}

	@ResponseBody
	@RequestMapping(value = "/summary/setPaymentAddress.json", method = RequestMethod.POST)
	public CartData setPaymentAddress(@RequestParam(value = "addressId") final String addressId)
	{
		AddressData addressData = null;
		final List<AddressData> paymentAddresses = userFacade.getAddressBook();
		for (final AddressData paymentAddress : paymentAddresses)
		{
			if (paymentAddress.getId().equals(addressId))
			{
				addressData = paymentAddress;
				break;
			}
		}

		if (addressData != null && checkoutFacade.setPaymentAddress(addressData))
		{
			return checkoutFacade.getCheckoutCart();
		}

		return null;
	}

	@RequestMapping(value = "/summary/getPaymentAddressForm.json", method = RequestMethod.GET)
	public String getPaymentAddressForm(final Model model, @RequestParam(value = "addressId") final String addressId,
			@RequestParam(value = "createUpdateStatus") final String createUpdateStatus)
	{
		AddressData addressData = null;

		final List<AddressData> paymentAddresses = userFacade.getAddressBook();
		for (final AddressData paymentAddress : paymentAddresses)
		{
			if (paymentAddress.getId().equals(addressId))
			{
				addressData = paymentAddress;
				break;
			}
		}

		final AddressForm addressForm = new AddressForm();

		if (addressData != null)
		{
			addressForm.setAddressId(addressData.getId());
			addressForm.setTitleCode(addressData.getTitleCode());
			addressForm.setFirstName(addressData.getFirstName());
			addressForm.setLastName(addressData.getLastName());
			addressForm.setLine1(addressData.getLine1());
			addressForm.setLine2(addressData.getLine2());
			addressForm.setTownCity(addressData.getTown());
			addressForm.setPostcode(addressData.getPostalCode());
			addressForm.setCountryIso(addressData.getCountry().getIsocode());
			addressForm.setShippingAddress(Boolean.valueOf(addressData.isShippingAddress()));
			addressForm.setBillingAddress(Boolean.valueOf(addressData.isBillingAddress()));
		}

		model.addAttribute("edit", Boolean.valueOf(addressData != null));

		model.addAttribute(addressForm);
		model.addAttribute("createUpdateStatus", createUpdateStatus);
		return ControllerConstants.Views.Fragments.Checkout.PaymentAddressFormPopup;
	}

	@RequestMapping(value = "/summary/createUpdatePaymentAddress.json", method = RequestMethod.POST)
	public String createUpdatePaymentAddress(final Model model, @Valid final AddressForm form, final BindingResult bindingResult)
	{
		if (bindingResult.hasErrors())
		{
			model.addAttribute("edit", Boolean.valueOf(StringUtils.isNotBlank(form.getAddressId())));

			return ControllerConstants.Views.Fragments.Checkout.PaymentAddressFormPopup;
		}

		// create delivery address and set it on cart
		final AddressData addressData = new AddressData();
		addressData.setId(form.getAddressId());
		addressData.setTitleCode(form.getTitleCode());
		addressData.setFirstName(form.getFirstName());
		addressData.setLastName(form.getLastName());
		addressData.setLine1(form.getLine1());
		addressData.setLine2(form.getLine2());
		addressData.setTown(form.getTownCity());
		addressData.setPostalCode(form.getPostcode());
		addressData.setCountry(checkoutFacade.getCountryForIsocode(form.getCountryIso()));

		addressData.setShippingAddress(Boolean.TRUE.equals(form.getShippingAddress())
				|| Boolean.TRUE.equals(form.getSaveInAddressBook()));
		addressData.setBillingAddress(Boolean.TRUE.equals(form.getBillingAddress()));

		final AddressData newOrUpdatedAddress = checkoutFacade.createOrUpdateAddress(addressData);

		checkoutFacade.setPaymentAddress(newOrUpdatedAddress);

		model.addAttribute("createUpdateStatus", "Success");
		model.addAttribute("addressId", newOrUpdatedAddress.getId());

		return REDIRECT_PREFIX + "/checkout/summary/getPaymentAddressForm.json";
	}

	@ResponseBody
	@RequestMapping(value = "/summary/getApplicablePaymentModes.json", method = RequestMethod.GET)
	public PaymentModesData getApplicablePaymentModes()
	{
		final PaymentModesData data = new PaymentModesData();
		// for showing the card registered by the user
		data.setModes(checkoutFacade.getApplicablePaymentModes());
		data.setQmoreEnabledGlobal(checkoutFacade.isQmoreEnabledGlobal());

		if (checkoutFacade.isQmoreEnabledGlobal())
		{
			//inits the data storage
			data.setGetJSDataStorageURL(checkoutFacade.initQmoreDataStorage());

		}
		return data;
	}

	@RequestMapping(value = "/paymentCancel", method = RequestMethod.POST)
	public String paymentCancel(final Model model)
	{
		checkoutFacade.deletePaymentInformationFromCart();
		model.addAttribute("redirectURL", "summary");

		return ControllerConstants.Views.Pages.Checkout.CheckoutCloseIFrame;
	}


	@RequestMapping(value = "/paymentFailure", method = RequestMethod.POST)
	public String paymentFailure(final Model model)
	{
		checkoutFacade.deletePaymentInformationFromCart();
		model.addAttribute("redirectURL", "summary");

		return ControllerConstants.Views.Pages.Checkout.CheckoutCloseIFrame;
	}



	@RequestMapping(value = "/paymentSuccess/{orderCode}", method = RequestMethod.POST)
	public String paymentSuccess(@PathVariable(value = "orderCode") final String orderCode, final Model model)
			throws CMSItemNotFoundException
	{
		final Map<String, Object> modelMap = model.asMap();
		final HttpServletRequest request = (HttpServletRequest) modelMap.get(WirecardCheckoutController.REQUEST);
		final String context = request.getContextPath();
		model.addAttribute("redirectURL", context + "/checkout/orderConfirmation/" + orderCode);

		return ControllerConstants.Views.Pages.Checkout.CheckoutCloseIFrame;
	}


}
