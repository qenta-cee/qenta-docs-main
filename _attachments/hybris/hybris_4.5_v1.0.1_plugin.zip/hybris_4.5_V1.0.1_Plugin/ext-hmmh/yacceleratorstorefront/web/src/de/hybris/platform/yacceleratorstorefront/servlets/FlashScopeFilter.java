/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.servlets;


import de.hybris.platform.yacceleratorstorefront.servlets.util.FlashScope;

import java.io.IOException;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.filter.OncePerRequestFilter;


/**
 * Flash scope.
 * Flash scope allows the use of the post/redirect/get design pattern to alleviate many of
 * the problems associated with handling multiple submits or resubmission of data in browser
 * requests to the server.
 *
 * Flash scope is an additional scope to those provided in a standard Java Web application
 * (page, request, session and application). Any attributes held in flash scope will be
 * available for the duration of the current request, and the subsequent request too.
 */
public class FlashScopeFilter extends OncePerRequestFilter
{

	@Override
	@SuppressWarnings("unchecked")
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain filterChain) throws ServletException, IOException
	{
		final HttpSession session = request.getSession(false);
		if (session != null)
		{
			final Map<String, ?> flash = (Map<String, ?>) session.getAttribute(FlashScope.FLASH_SCOPE_ATTRIBUTE);
			if (flash != null)
			{
				for (final Map.Entry<String, ?> entry : flash.entrySet())
				{
					final Object currentValue = request.getAttribute(entry.getKey());
					if (currentValue == null)
					{
						request.setAttribute(entry.getKey(), entry.getValue());
					}
				}
				session.removeAttribute(FlashScope.FLASH_SCOPE_ATTRIBUTE);
			}
		}
		filterChain.doFilter(request, response);
	}

}