/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.security;

import de.hybris.platform.yacceleratorstorefront.constants.WebConstants;

import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.CookieGenerator;
import org.springframework.web.util.UrlPathHelper;


/**
 * Interceptor to additionally secure HTTPS calls. If no secure cookie is found the interceptor will redirect to the
 * configured loginUrl. The secure cookie is first generated after successful login on an HTTPS channel and sent with
 * every following secure request.
 */
public class GUIDInterceptor extends HandlerInterceptorAdapter
{
	private static final Logger LOG = Logger.getLogger(GUIDInterceptor.class);
	private static final String GUID_INTERCEPTOR_ONCE_KEY = "GUIDInterceptor_Once";
	private Set<String> excludeUrls;

	private String loginUrl;

	private RedirectStrategy redirectStrategy;
	private CookieGenerator cookieGenerator;
	private UrlPathHelper urlPathHelper;

	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
			throws Exception //NOPMD
	{
		if (request.getAttribute(GUID_INTERCEPTOR_ONCE_KEY) == null)
		{
			request.setAttribute(GUID_INTERCEPTOR_ONCE_KEY, Boolean.TRUE);
			final String path = urlPathHelper.getServletPath(request);
			if (request.isSecure() && !excludeUrls.contains(path))
			{
				boolean redirect = true;
				final String guid = (String) request.getSession().getAttribute(WebConstants.SECURE_COOKIE);
				if (guid != null && request.getCookies() != null)
				{
					for (final Cookie cookie : request.getCookies())
					{
						if (WebConstants.SECURE_COOKIE.equals(cookie.getName()))
						{
							if (guid.equals(cookie.getValue()))
							{
								redirect = false;
								break;
							}
							else
							{
								LOG.info("Found secure cookie with invalid value. expected [" + guid + "] actual [" + cookie.getValue()
										+ "]. removing.");
								cookieGenerator.removeCookie(response);
							}
						}
					}
				}
				if (redirect)
				{
					LOG.warn((guid == null ? "missing secure token in session" : "no matching guid cookie") + ", redirecting");
					redirectStrategy.sendRedirect(request, response, loginUrl);
					return false;
				}
			}
		}
		return super.preHandle(request, response, handler);
	}

	/**
	 * @param excludeUrls
	 *           the excludeUrls to set
	 */
	@Required
	public void setExcludeUrls(final Set<String> excludeUrls)
	{
		this.excludeUrls = excludeUrls;
	}

	/**
	 * @param loginUrl
	 *           the loginUrl to set
	 */
	@Required
	public void setLoginUrl(final String loginUrl)
	{
		this.loginUrl = loginUrl;
	}

	/**
	 * @param redirectStrategy
	 *           the redirectStrategy to set
	 */
	@Required
	public void setRedirectStrategy(final RedirectStrategy redirectStrategy)
	{
		this.redirectStrategy = redirectStrategy;
	}

	/**
	 * @param cookieGenerator
	 *           the cookieGenerator to set
	 */
	@Required
	public void setCookieGenerator(final CookieGenerator cookieGenerator)
	{
		this.cookieGenerator = cookieGenerator;
	}

	/**
	 * @param urlPathHelper
	 *           the urlPathHelper to set
	 */
	@Required
	public void setUrlPathHelper(final UrlPathHelper urlPathHelper)
	{
		this.urlPathHelper = urlPathHelper;
	}
}
