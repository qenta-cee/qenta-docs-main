/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.breadcrumb.impl;

import de.hybris.platform.yacceleratorstorefront.breadcrumb.Breadcrumb;
import de.hybris.platform.servicelayer.i18n.I18NService;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;


/**
 * AccountBreadcrumbBuilder implementation for account related pages
 */
public class AccountBreadcrumbBuilder
{
	private static final String ACCOUNT_URL = "/my-account";
	private static final String ACCOUNT_TITLE_MESSAGE_KEY = "header.link.account";

	private MessageSource messageSource;
	private I18NService i18nService;

	public List<Breadcrumb> getBreadcrumbs(final String resourceKey) throws IllegalArgumentException
	{
		final List<Breadcrumb> breadcrumbs = new ArrayList<Breadcrumb>();
		breadcrumbs.add(new Breadcrumb(ACCOUNT_URL, getMessageSource().getMessage(ACCOUNT_TITLE_MESSAGE_KEY, null,
				getI18nService().getCurrentLocale()), null));

		if (StringUtils.isNotBlank(resourceKey))
		{
			breadcrumbs.add(new Breadcrumb("#", getMessageSource().getMessage(resourceKey, null,
					getI18nService().getCurrentLocale()), null));
		}

		return breadcrumbs;
	}


	protected I18NService getI18nService()
	{
		return i18nService;
	}

	@Required
	public void setI18nService(final I18NService i18nService)
	{
		this.i18nService = i18nService;
	}

	protected MessageSource getMessageSource()
	{
		return messageSource;
	}

	@Required
	public void setMessageSource(final MessageSource messageSource)
	{
		this.messageSource = messageSource;
	}
}
