/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.servlets.util;

import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.commerceservices.enums.SiteTheme;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.web.servlet.theme.AbstractThemeResolver;


/**
 * Resolve the spring theme name from the CMSSite.
 * The spring theme name is built from the CMSSite UID and the CMSSite Theme.
 */
public class DefaultThemeResolver extends AbstractThemeResolver
{
	private CMSSiteService cmsSiteService;

	@Override
	public String resolveThemeName(final HttpServletRequest arg0)
	{
		// Resolve Theme from CMSSiteService
		final CMSSiteModel currentSite = getCmsSiteService().getCurrentSite();
		if (currentSite != null)
		{
			return combineSiteAndTheme(currentSite.getUid(), getThemeNameForSite(currentSite));
		}

		// No site - no theme
		return null;
	}

	protected String getThemeNameForSite(final CMSSiteModel site)
	{
		final SiteTheme theme = site.getTheme();
		if (theme != null)
		{
			final String themeCode = theme.getCode();
			if (themeCode != null && !themeCode.isEmpty())
			{
				return themeCode;
			}
		}
		return getDefaultThemeName();
	}

	protected String combineSiteAndTheme(final String siteUid, final String themeName)
	{
		return siteUid + "," + themeName;
	}

	@Override
	public void setThemeName(final HttpServletRequest arg0, final HttpServletResponse arg1, final String arg2)
	{
		throw new UnsupportedOperationException("Cannot change theme - use a different theme resolution strategy");
	}

	/**
	 * @return the cmsSiteService
	 */
	protected CMSSiteService getCmsSiteService()
	{
		return cmsSiteService;
	}

	/**
	 * @param cmsSiteService the CMSSiteService to set
	 */
	@Required
	public void setCmsSiteService(final CMSSiteService cmsSiteService)
	{
		this.cmsSiteService = cmsSiteService;
	}
}
