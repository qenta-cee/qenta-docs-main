/**
 * 
 */
package de.hmmh.wirecard.controllers;

import de.hybris.platform.yacceleratorstorefront.controllers.ControllerConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import de.hmmh.paymentfacades.exceptions.WirecardResponseException;
import de.hmmh.paymentfacades.facades.WirecardCheckoutFacade;
import de.hmmh.wirecard.exception.WirecardException;




/**
 * @author Christoph.Meyer
 * 
 *         this controller is not inside the /checkout/ context, as it must be accessible by wirecard without
 *         authentification.
 */
@Controller
@Scope("tenant")
@RequestMapping("/wirecard")
public class WirecardResponseController
{

	public static final String WIRECARD_SESSION_MESSAGE_HOLDER = "wirecardSessionMessageHolder";

	@Autowired
	private transient WirecardCheckoutFacade checkoutFacade;

	private static final Logger LOG = Logger.getLogger(WirecardResponseController.class);

	/**
	 * Asynchronously called by payment provider. The response holds information about the result of the payment process.
	 * 
	 */
	@ResponseBody
	@RequestMapping("/response")
	public ResponseEntity<String> processResponse(final HttpServletRequest request)
	{

		LOG.info(new StringBuilder("received request from : ").append(request.getServletPath()).append(". session is: ")
				.append(request.getSession().getId()).toString());

		final HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Content-Type", "text/html; charset=utf-8");
		try
		{
			checkoutFacade.processAsyncResponse(request.getParameterMap());
		}
		catch (final WirecardResponseException e)
		{
			LOG.warn("unexpected error while processing result.", e);
			addSessionError(request, e.getMessageKey());

		}
		catch (final WirecardException e)
		{
			LOG.warn("unexpected wirecard error while processing result" + e.getStatusString(), e);
			addSessionError(request, e.getMessageKey());
		}

		return new ResponseEntity<String>("Response processed.", responseHeaders, HttpStatus.OK);
	}

	/**
	 * @param request
	 */
	private void addSessionError(final HttpServletRequest request, final String messageKey)
	{
		if (request == null)
		{
			LOG.error("cannot handle response error, request is null!");
		}
		else
		{
			final HttpSession session = request.getSession();
			if (session.getAttribute(WIRECARD_SESSION_MESSAGE_HOLDER) == null)
			{
				session.setAttribute(WIRECARD_SESSION_MESSAGE_HOLDER, Collections.singletonList(messageKey));
			}
			else
			{
				final List<String> messageKeys = new ArrayList<String>(
						(List<String>) session.getAttribute(WIRECARD_SESSION_MESSAGE_HOLDER));
				messageKeys.add(messageKey);
				session.setAttribute(WIRECARD_SESSION_MESSAGE_HOLDER, messageKeys);
			}
		}
	}

	/*
	 * QMORE fallback controller for DataStore store methods for old fashioned browsers that do not support CORS (cross
	 * origin resource sharing)
	 */
	@RequestMapping(value = "/qmoreFallbackResponse", method = RequestMethod.POST)
	public String qmoreFallbackResponse(final Model model, @RequestParam(value = "response") final String responseParams)
	{

		// add a slash before all "
		final String response = responseParams.replace("\"", "\\\"");
		model.addAttribute("responseParams", response);
		return ControllerConstants.Views.Pages.Checkout.QmoreFallbackResponse;
	}
}
