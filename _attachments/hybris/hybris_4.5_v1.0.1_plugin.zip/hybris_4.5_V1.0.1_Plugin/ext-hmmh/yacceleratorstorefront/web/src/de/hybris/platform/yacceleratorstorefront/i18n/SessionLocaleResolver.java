/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */

package de.hybris.platform.yacceleratorstorefront.i18n;

import de.hybris.platform.commercefacades.storesession.StoreSessionFacade;
import de.hybris.platform.commercefacades.storesession.data.LanguageData;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.LocaleEditor;


/**
 * Implementation of {@link SessionLocaleResolver} which falls back to the locale defined by the current site
 */
public class SessionLocaleResolver extends org.springframework.web.servlet.i18n.SessionLocaleResolver
{

	@Autowired
	private StoreSessionFacade storeSessionFacade;

	/**
	 * @see org.springframework.web.servlet.i18n.SessionLocaleResolver#determineDefaultLocale(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	protected Locale determineDefaultLocale(final HttpServletRequest request)
	{
		Locale result = super.determineDefaultLocale(request);
		final LanguageData language = storeSessionFacade.getCurrentLanguage();
		if (language != null)
		{
			final LocaleEditor localeEditor = new LocaleEditor();
			localeEditor.setAsText(language.getIsocode());
			result = (Locale) localeEditor.getValue();
		}
		return result;
	}
}
