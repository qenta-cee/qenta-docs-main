/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.controllers.pages;

import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.commercefacades.storelocator.StoreLocatorFacade;
import de.hybris.platform.commercefacades.storelocator.data.PointOfServiceData;
import de.hybris.platform.commercefacades.storelocator.helpers.DistanceHelper;
import de.hybris.platform.storelocator.exception.GeoLocatorException;
import de.hybris.platform.storelocator.exception.LocationServiceException;
import de.hybris.platform.storelocator.exception.MapServiceException;
import de.hybris.platform.storelocator.impl.GeometryUtils;
import de.hybris.platform.storelocator.location.Location;
import de.hybris.platform.storelocator.location.LocationService;
import de.hybris.platform.storelocator.map.Map;
import de.hybris.platform.storelocator.map.MapService;
import de.hybris.platform.util.Config;
import de.hybris.platform.yacceleratorstorefront.breadcrumb.impl.StorefinderBreadcrumbBuilder;
import de.hybris.platform.yacceleratorstorefront.constants.WebConstants;
import de.hybris.platform.yacceleratorstorefront.controllers.ControllerConstants;
import de.hybris.platform.yacceleratorstorefront.controllers.util.GlobalMessages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * Controller for store locator search and detail pages. Provides display data for these two pages. Search result amount
 * is limited to the {@link StoreLocatorController#LOCATIONS_NUMBER} value. Increasing number of displayed stores is
 * possible by giving proper argument for
 * {@link StoreLocatorController#searchPOS(String, String, Model, HttpServletRequest)} method but is limited to max
 * value of {@link StoreLocatorController#MAX_LOCATIONS_TO_DISPLAY} stores.
 */
@Controller
@Scope("tenant")
@RequestMapping(value = "/store-finder")
public class StoreLocatorController extends AbstractPageController
{
	protected static final Logger LOG = Logger.getLogger(StoreLocatorController.class);

	private static final String STORE_FINDER_CMS_PAGE = "storefinderPage";
	private static final String GOOGLE_API_KEY_ID = "googleApiKey";
	private static final int LOCATIONS_NUMBER = 5;
	private static final int MAX_LOCATIONS_TO_DISPLAY = 100;

	@Autowired
	private LocationService locationService;

	@Autowired
	private StoreLocatorFacade storeLocatorFacade;

	@Autowired
	private DistanceHelper distanceHelper;

	@Autowired
	private MapService mapService;

	@Autowired
	private StorefinderBreadcrumbBuilder storefinderBreadcrumbBuilder;

	@RequestMapping(method = RequestMethod.GET)
	public String searchPOS(@RequestParam(value = "q", defaultValue = "", required = false) final String locationQuery,
			@RequestParam(value = "more", defaultValue = "", required = false) final String seeMore, final Model model,
			final HttpServletRequest request) throws GeoLocatorException, MapServiceException, CMSItemNotFoundException
	{
		addGoogleAPIKey(request);

		Integer limit = Integer.valueOf(LOCATIONS_NUMBER);
		if (StringUtils.isNotBlank(seeMore))
		{
			try
			{
				limit = Integer.valueOf(Math.max(Integer.parseInt(seeMore), limit.intValue()));
			}
			catch (final NumberFormatException numberFormatException)
			{
				LOG.warn("Passed " + seeMore + " is not a valid integer value");
			}
		}

		final Map locationsMap = storeLocatorFacade.getLocationsForQuery(locationQuery, MAX_LOCATIONS_TO_DISPLAY);
		if (locationsMap != null && CollectionUtils.isNotEmpty(locationsMap.getPointsOfInterest()))
		{
			final List<Location> locations = locationsMap.getPointsOfInterest();

			if (locations.size() > limit.intValue())
			{
				model.addAttribute("showSeeMore", Boolean.TRUE);
			}
		}

		if (request.getParameterMap().containsKey("q"))
		{
			if (StringUtils.isBlank(locationQuery))
			{
				GlobalMessages.addErrorMessage(model, "form.global.error");
				model.addAttribute("errorNoResults", "storelocator.error.no.results.subtitle");
			}
		}
		limit = Integer.valueOf(Math.min(MAX_LOCATIONS_TO_DISPLAY, limit.intValue()));
		model.addAttribute("locationQuery", StringEscapeUtils.escapeHtml(locationQuery));
		model.addAttribute("seeMoreLimit", Integer.valueOf(limit.intValue() + LOCATIONS_NUMBER));
		fillStoresMap(locationQuery, model, limit.intValue());

		storeCmsPageInModel(model, getStoreFinderPage());
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				storefinderBreadcrumbBuilder.getBreadcrumbs(getBreadcrumbData(locationQuery, null)));
		return ControllerConstants.Views.Pages.StoreFinder.StoreFinderSearchPage;
	}



	@RequestMapping(value = "/{locationQuery}/{storeLocation}", method = RequestMethod.GET)
	public String displayPOS(@PathVariable("storeLocation") final String storeLocation,
			@PathVariable("locationQuery") final String locationQuery, final Model model, final HttpServletRequest request)
			throws LocationServiceException, CMSItemNotFoundException
	{
		addGoogleAPIKey(request);

		final PointOfServiceData pointOfServiceData = storeLocatorFacade.getPOSForName(storeLocation);
		model.addAttribute("store", pointOfServiceData);
		model.addAttribute("locationQuery", locationQuery);
		model.addAttribute("storeLocation", storeLocation);

		final Location center = locationService.getLocation(locationQuery, null, null, null, null, true);
		final Location dest = locationService.getLocationByName(storeLocation);
		final double distance = GeometryUtils.getElipticalDistanceKM(center.getGPS(), dest.getGPS());

		model.addAttribute("formattedDistance", distanceHelper.getDistanceStringForLocation(storeLocation, distance));
		model.addAttribute("center", center);

		storeCmsPageInModel(model, getStoreFinderPage());
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				storefinderBreadcrumbBuilder.getBreadcrumbs(getBreadcrumbData(locationQuery, storeLocation)));
		return ControllerConstants.Views.Pages.StoreFinder.StoreFinderDetailsPage;
	}

	/*
	 * Finds locations from all base stores assigned to the current cms site and sorts them by distance ascending.
	 */
	protected void fillStoresMap(final String locationQuery, final Model model, final int limit) throws GeoLocatorException,
			MapServiceException
	{
		final Map locationsMap = storeLocatorFacade.getLocationsForQuery(locationQuery, limit);
		if (locationsMap != null && CollectionUtils.isNotEmpty(locationsMap.getPointsOfInterest()))
		{
			final List<PointOfServiceData> posList = new ArrayList<PointOfServiceData>();

			for (final Location location : locationsMap.getPointsOfInterest())
			{
				posList.add(storeLocatorFacade.getPOSForLocation(location));
			}

			model.addAttribute("mapBounds", mapService.getMapBoundsForMap(locationsMap));
			model.addAttribute("locationsMap", locationsMap);
			model.addAttribute("posList", posList);
		}
		else if (StringUtils.isNotEmpty(locationQuery))
		{
			GlobalMessages.addErrorMessage(model, "storelocator.error.no.results.title");
			model.addAttribute("errorNoResults", "storelocator.error.no.results.subtitle");
		}
	}

	protected AbstractPageModel getStoreFinderPage() throws CMSItemNotFoundException
	{
		return getContentPageForLabelOrId(STORE_FINDER_CMS_PAGE);
	}

	protected java.util.Map<String, String> getBreadcrumbData(final String locationQuery, final String storeLocation)
	{
		final java.util.Map<String, String> result = new HashMap<String, String>();
		result.put(StorefinderBreadcrumbBuilder.LOCATION_QUERY_KEY, locationQuery);
		result.put(StorefinderBreadcrumbBuilder.STORE_LOCATION_KEY, storeLocation);
		return result;
	}

	protected void addGoogleAPIKey(final HttpServletRequest request)
	{
		final String host = request.getServerName();
		final String googleApiKey = Config.getParameter(GOOGLE_API_KEY_ID + "." + host);
		if (StringUtils.isEmpty(googleApiKey))
		{
			LOG.warn("No Google API key found for server: " + host);
		}
		request.setAttribute(GOOGLE_API_KEY_ID, googleApiKey);
	}
}
