/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.interceptors;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.propertyeditors.LocaleEditor;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.support.RequestContextUtils;


/**
 * This interceptor acts as a bridge between hybris' current locale and Spring's locale resolver to keep them
 * synchronized between requests.
 */
public class LocaleInterceptor extends HandlerInterceptorAdapter
{
	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
	{
		final LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
		if (localeResolver == null)
		{
			throw new IllegalStateException("No LocaleResolver found: not in a DispatcherServlet request?");
		}
		final String locale = request.getParameter("lang");
		if (!StringUtils.isBlank(locale))
		{
			final LocaleEditor localeEditor = new LocaleEditor();
			localeEditor.setAsText(locale);
			localeResolver.setLocale(request, response, (Locale) localeEditor.getValue());
		}

		return true;
	}

}
