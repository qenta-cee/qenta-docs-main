/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.preview;

import de.hybris.platform.yacceleratorstorefront.servlets.util.FilterSpringUtil;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.cms2.model.pages.CategoryPageModel;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.cms2.model.pages.ProductPageModel;
import de.hybris.platform.cms2.model.preview.PreviewDataModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.commerceservices.url.UrlResolver;
import de.hybris.platform.core.model.product.ProductModel;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;


/**
 * Responsible for generating correct URL for given page.
 */
public class DefaultCMSPageURLMappingHandler implements URLMappingHandler
{
	private Map<String,String> pageMapping;

	/**
	 * Returns the relative URL for the specified page <code>page</code>.
	 * 
	 * @param httpRequest
	 *           HTTP request
	 * @return relative URL for the specified page
	 */
	@Override
	public String getPageUrl(final HttpServletRequest httpRequest, final PreviewDataModel previewDataModel)
	{
		if (previewDataModel != null)
		{
			final AbstractPageModel page = previewDataModel.getPage();

			final Map<String, String> pageMapping = getPageMapping();
			if (pageMapping != null && page != null && page.getUid() != null)
			{
				final String url = pageMapping.get(page.getUid());
				if (url != null && !url.isEmpty())
				{
					return url;
				}
			}

			if (page instanceof ContentPageModel)
			{
				// Construct URL to preview the Page by UID
				return "/preview-content?uid=" + page.getUid();
			}

			if (page instanceof CategoryPageModel)
			{
				return getCategoryModelUrlResolver(httpRequest).resolve(getPreviewValueForCategoryPage(previewDataModel));
			}

			if (page instanceof ProductPageModel)
			{
				return getProductModelUrlResolver(httpRequest).resolve(getPreviewValueForProductPage(previewDataModel));
			}
		}

		return "/";
	}

	protected CategoryModel getPreviewValueForCategoryPage(final PreviewDataModel previewCtx)
	{
		final CMSSiteModel currentSite = previewCtx.getActiveSite();
		CategoryModel ret = previewCtx.getPreviewCategory();

		if (ret == null)
		{
			if (currentSite != null)
			{
				ret = currentSite.getDefaultPreviewCategory();
			}
		}
		return ret;
	}

	protected ProductModel getPreviewValueForProductPage(final PreviewDataModel previewCtx)
	{
		final CMSSiteModel currentSite = previewCtx.getActiveSite();
		ProductModel ret = previewCtx.getPreviewProduct();

		if (ret == null)
		{
			if (currentSite != null)
			{
				ret = currentSite.getDefaultPreviewProduct();
			}
		}
		return ret;
	}

	protected UrlResolver<ProductModel> getProductModelUrlResolver(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "productModelUrlResolver", UrlResolver.class);
	}

	protected UrlResolver<CategoryModel> getCategoryModelUrlResolver(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "categoryModelUrlResolver", UrlResolver.class);
	}

	// Optional
	public void setPageMapping(final Map<String,String> pageMapping)
	{
		this.pageMapping = pageMapping;
	}

	protected Map<String,String> getPageMapping()
	{
		return pageMapping;
	}
}
