/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.servlets;

import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.commercefacades.storesession.StoreSessionFacade;
import de.hybris.platform.yacceleratorstorefront.breadcrumb.BrowseHistory;
import de.hybris.platform.yacceleratorstorefront.breadcrumb.BrowseHistoryEntry;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FilterSpringUtil;

import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;


/**
 * Filter that initializes the session for the yacceleratorstorefront
 */
public class StoreFrontFilter implements Filter
{
	@Override
	public void init(final FilterConfig filterConfig) throws ServletException
	{
		// nothing to do
	}

	@Override
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
			throws IOException, ServletException
	{
		final HttpServletRequest httpRequest = (HttpServletRequest) request;
		final HttpSession session = httpRequest.getSession();
		final String queryString = httpRequest.getQueryString();

		if (session.isNew() || StringUtils.contains(queryString, CMSFilter.CLEAR_CMSSITE_PARAM))
		{
			initDefaults(httpRequest);

			if (httpRequest.isSecure())
			{
				fixSecureHttpJSessionIdCookie(httpRequest, (HttpServletResponse) response, session);
			}
		}

		if ("GET".equals(httpRequest.getMethod()))
		{
			getBrowseHistory(httpRequest).addBrowseHistoryEntry(new BrowseHistoryEntry(httpRequest.getRequestURI(), null));
		}

		chain.doFilter(request, response);
	}

	protected void initDefaults(final HttpServletRequest request)
	{
		final StoreSessionFacade storeSessionFacade = getStoreSessionFacade(request);

		storeSessionFacade.initializeSession(Collections.list((Enumeration<Locale>) request.getLocales()));
	}

	protected StoreSessionFacade getStoreSessionFacade(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "storeSessionFacade", StoreSessionFacade.class);
	}

	protected BrowseHistory getBrowseHistory(final HttpServletRequest httpRequest)
	{
		return FilterSpringUtil.getSpringBean(httpRequest, "browseHistory", BrowseHistory.class);
	}

	@Override
	public void destroy()
	{
		// nothing to do
	}

	protected void fixSecureHttpJSessionIdCookie(final HttpServletRequest httpServletRequest,
			final HttpServletResponse httpServletResponse, final HttpSession session)
	{
		// Fix for issue with Tomcat. If the request that establishes a new session is secure then the
		// JSESSIONID cookie is set as secure only. For our purposes we want to use the same session for
		// both secure and insecure requests. We use a separate secure only cookie to implement security.
		// Here we override the cookie set by Tomcat with one that is not secure only.
		final Cookie sessionCookie = new Cookie("JSESSIONID", session.getId());
		sessionCookie.setMaxAge(-1);
		sessionCookie.setSecure(false);
		sessionCookie.setPath(httpServletRequest.getContextPath());
		httpServletResponse.addCookie(sessionCookie);
	}
}
