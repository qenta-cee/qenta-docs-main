/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.controllers.cms;

import de.hybris.platform.acceleratorcms.model.components.PurchasedProductReferencesComponentModel;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.yacceleratorfacades.suggestion.SimpleSuggestionFacade;
import de.hybris.platform.yacceleratorstorefront.controllers.ControllerConstants;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * Controller for CMS PurchasedProductReferencesComponent
 */
@Controller("PurchasedProductReferencesComponentController")
@Scope("tenant")
@RequestMapping(value = ControllerConstants.Actions.Cms.PurchasedProductReferencesComponent)
public class PurchasedProductReferenceComponentController extends
		AbstractCMSComponentController<PurchasedProductReferencesComponentModel>
{
	@Autowired
	@Qualifier("simpleSuggestionFacade")
	private SimpleSuggestionFacade simpleSuggestionFacade;

	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final PurchasedProductReferencesComponentModel component)
	{
		final List<ProductData> products = simpleSuggestionFacade.getReferencesForPurchasedInCategory(component.getCategory()
				.getCode(), component.getProductReferenceType(), component.getFilterPurchased().booleanValue(), component
				.getMaximumNumberProducts());

		model.addAttribute("title", component.getTitle());
		model.addAttribute("productReferences", products);
	}

	@Override
	protected String getView(final PurchasedProductReferencesComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix
				+ StringUtils.lowerCase(PurchasedProductReferencesComponentModel._TYPECODE);
	}
}
