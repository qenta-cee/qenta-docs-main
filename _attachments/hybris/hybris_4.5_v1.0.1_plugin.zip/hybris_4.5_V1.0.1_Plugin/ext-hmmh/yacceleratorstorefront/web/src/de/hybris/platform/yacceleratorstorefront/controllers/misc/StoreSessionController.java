/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.controllers.misc;

import de.hybris.platform.yacceleratorstorefront.controllers.pages.AbstractPageController;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FlashScope;
import de.hybris.platform.commercefacades.storesession.StoreSessionFacade;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * Controller for store session
 */
@Controller
@Scope("tenant")
@RequestMapping("/s")
public class StoreSessionController extends AbstractPageController
{
	@Autowired
	private StoreSessionFacade storeSessionFacade;

	@Autowired
	private UserFacade userFacade;

	@RequestMapping(value = "/slang", method = RequestMethod.POST)
	public String selectLanguage(@RequestParam("lang") final String lang, final HttpServletRequest request)
	{
		storeSessionFacade.setCurrentLanguage(lang);
		userFacade.syncSessionLanguage();
		return REDIRECT_PREFIX + request.getHeader("Referer");
	}

	@RequestMapping(value = "/scurrency", method = RequestMethod.POST)
	public String selectCurrency(@RequestParam("currency") final String currency, final HttpServletRequest request)
	{
		storeSessionFacade.setCurrentCurrency(currency);
		userFacade.syncSessionCurrency();
		return REDIRECT_PREFIX + request.getHeader("Referer");
	}

	@ExceptionHandler(UnknownIdentifierException.class)
	public String handleUnknownIdentifierException(final UnknownIdentifierException exception, final HttpServletRequest request)
	{
		FlashScope.getCurrent(request).put("message", exception.getMessage());
		return REDIRECT_PREFIX + "/404";
	}
}
