/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.constants;

/**
 * Constants used in the Web tier
 */
public final class WebConstants
{
	private WebConstants()
	{
		//empty
	}

	public static final String SECURE_COOKIE = "acceleratorSecureGUID";
	public static final String MODEL_KEY_ADDITIONAL_BREADCRUMB = "additionalBreadcrumb";
	public static final String BREADCRUMBS_KEY = "breadcrumbs";

	public static final String CONTINUE_URL = "session_continue_url";
}
