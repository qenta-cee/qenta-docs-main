/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */

package de.hybris.platform.yacceleratorstorefront.servlets.util;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


/**
 * Flash scope.
 * Flash scope allows the use of the post/redirect/get design pattern to alleviate many of
 * the problems associated with handling multiple submits or resubmission of data in browser
 * requests to the server.
 *
 * Flash scope is an additional scope to those provided in a standard Java Web application
 * (page, request, session and application). Any attributes held in flash scope will be
 * available for the duration of the current request, and the subsequent request too.
 */
public final class FlashScope
{
	public static final String FLASH_SCOPE_ATTRIBUTE = FlashScope.class.getName();

	private FlashScope()
	{
		// Deliberately empty private constructor to prevent instance construction
	}

	/**
	 * Get the flash scoped map of keys to values for the specified request.
	 *
	 * @param request the request
	 * @return the map of keys to values
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getCurrent(final HttpServletRequest request)
	{
		final HttpSession session = request.getSession();
		Map flash = (Map) session.getAttribute(FLASH_SCOPE_ATTRIBUTE);
		if (flash == null)
		{
			flash = new HashMap();
			session.setAttribute(FLASH_SCOPE_ATTRIBUTE, flash);
		}
		return flash;
	}
}