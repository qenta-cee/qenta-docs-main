/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2011 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.yacceleratorstorefront.security;

import de.hybris.platform.yacceleratorstorefront.controllers.util.GlobalMessages;
import de.hybris.platform.yacceleratorstorefront.servlets.util.FlashScope;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;


public class LoginAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler
{
	private String checkoutFailureUrl;

	protected String getCheckoutFailureUrl()
	{
		return checkoutFailureUrl;
	}

	@Required
	public void setCheckoutFailureUrl(final String checkoutFailureUrl)
	{
		this.checkoutFailureUrl = checkoutFailureUrl;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.web.authentication.AuthenticationFailureHandler#onAuthenticationFailure(javax.servlet
	 * .http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * org.springframework.security.core.AuthenticationException)
	 */
	@Override
	public void onAuthenticationFailure(final HttpServletRequest request, final HttpServletResponse response,
			final AuthenticationException exception) throws IOException, ServletException
	{
		final Map<String,Object> currentFlashScope = FlashScope.getCurrent(request);
		currentFlashScope.put("j_username", request.getParameter("j_username"));
		currentFlashScope.put(GlobalMessages.ERROR_MESSAGES_HOLDER,
				Collections.singletonList("login.error.account.not.found.title"));

		if ("checkout".equals(request.getParameter("login-type")))
		{
			saveException(request, exception);
			logger.debug("Redirecting to " + getCheckoutFailureUrl());
			getRedirectStrategy().sendRedirect(request, response, getCheckoutFailureUrl());
		}
		else
		{
			super.onAuthenticationFailure(request, response, exception);
		}
	}
}
