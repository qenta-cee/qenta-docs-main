function refreshCartTotals(data)
{
	$('#cart_totals_div').html($('#cartTotalsTemplate').tmpl(data));
}

function bindUpdateCartForm(contextPath)
{
	$('.update_cart_form').each(function () {
		var options = {
			type: 'POST',
			dataType: 'json',
			success: function(data) {
				refreshCartTotals(data);
				$('#minicart_data').html($('#miniCartTemplate').tmpl(data));
				bindUpdateCartForm(contextPath);
				bindRemoveItemForm(contextPath);
			},
			error: function(xht, textStatus, ex) {
				alert("Failed to update cart. Error details [" + xht + ", " + textStatus + ", " + ex + "]");
			}
		};

		$(this).ajaxForm(options);
	});
}

function bindRemoveItemForm(contextPath)
{
	$('.remove_product_form').each(function () {
		var options = {
			type: 'POST',
			dataType: 'json',
			success: function(data) {
				refreshCartTotals(data);
				$('#minicart_data').html($('#miniCartTemplate').tmpl(data));
				bindUpdateCartForm(contextPath);
				bindRemoveItemForm(contextPath);
			},
			error: function(xht, textStatus, ex) {
				alert("Failed to update cart. Error details [" + xht + ", " + textStatus + ", " + ex + "]");
			}
		};

		$(this).ajaxForm(options);
	});
}