<?php

abstract class WirecardCEE_Client_QPay_Response_Abstract
    extends WirecardCEE_Client_Response_Abstract
{

}