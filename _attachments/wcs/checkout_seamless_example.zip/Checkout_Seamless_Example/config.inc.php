<?php
  //--------------------------------------------------------------------------------//
  //                                                                                //
  // Wirecard Checkout Seamless Example                                             //
  //                                                                                //
  // Copyright (c) 2013                                                             //
  // Wirecard Central Eastern Europe GmbH                                           //
  // www.wirecard.at                                                                //
  //                                                                                //
  // THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
  // KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
  // IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
  // PARTICULAR PURPOSE.                                                            //
  //                                                                                //
  //--------------------------------------------------------------------------------//
  // THIS EXAMPLE IS FOR DEMONSTRATION PURPOSES ONLY!                               //
  //--------------------------------------------------------------------------------//
  // Please read the integration documentation before modifying this file.          //
  //--------------------------------------------------------------------------------//

  // customer id
  // e.g. D200001 for demonstration purposes only
  // for production mode, please use your personal customer id obtained by Wirecard
  $customerId = "D200001";

  // secret
  // pre-shared key, used to sign the transmitted data
  // e.g. B8AKTPWBRMNBV455FG6M2DANE99WU2 for testing purposes
  // for production mode, please use your personal secret obtained by Wirecard
  $secret = "B8AKTPWBRMNBV455FG6M2DANE99WU2";

  // shop id
  // please use this parameter only if it is enabled by Wirecard
  $shopId = "qmore";

  // session variable name for storing the id of the Wirecard data storage
  $STORAGE_ID = "Wirecard_dataStorageId";

	//--------------------------------------------------------------------------------//
  // Global variables used within this example.
	//--------------------------------------------------------------------------------//

  // URLs for accessing the Wirecard Checkout Platform
  $URL_WIRECARD_CHECKOUT = "https://secure.wirecard-cee.com";
  $URL_DATASTORAGE_INIT = $URL_WIRECARD_CHECKOUT . "/qmore/dataStorage/init";
  $URL_DATASTORAGE_READ = $URL_WIRECARD_CHECKOUT . "/qmore/dataStorage/read";
  $URL_FRONTEND_INIT = $URL_WIRECARD_CHECKOUT . "/qmore/frontend/init";

  // name of iFrame containing the checkout
  $CHECKOUT_WINDOW_NAME = "wirecard_checkout";

	//--------------------------------------------------------------------------------//

?>

