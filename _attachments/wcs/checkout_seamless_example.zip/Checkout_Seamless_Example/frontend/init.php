<?php
  //--------------------------------------------------------------------------------//
  //                                                                                //
  // Wirecard Checkout Seamless Example                                             //
  //                                                                                //
  // Copyright (c) 2013                                                             //
  // Wirecard Central Eastern Europe GmbH                                           //
  // www.wirecard.at                                                                //
  //                                                                                //
  // THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
  // KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
  // IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
  // PARTICULAR PURPOSE.                                                            //
  //                                                                                //
  //--------------------------------------------------------------------------------//
  // THIS EXAMPLE IS FOR DEMONSTRATION PURPOSES ONLY!                               //
  //--------------------------------------------------------------------------------//
  // Please read the integration documentation before modifying this file.          //
  //--------------------------------------------------------------------------------//

  // loads the merchant specific parameters from the config file
	require_once("../config.inc.php");

	session_start();

  //--------------------------------------------------------------------------------//
  // Computes the protocol, servername, port and path for the various return URLs.
  //--------------------------------------------------------------------------------//

  $server_URL = $_SERVER['SERVER_NAME'] . ":" . $_SERVER['SERVER_PORT'] . $_SERVER['REQUEST_URI'];
  $server_URL = substr($server_URL, 0, strrpos($server_URL, "/")) . "/";
  if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") {
    $server_URL = "https://" . $server_URL;
  } else {
    $server_URL = "http://" . $server_URL;
  }

  //--------------------------------------------------------------------------------//
  // Sets the values of all required and optional parameters.
  //--------------------------------------------------------------------------------//

  $requestFingerprintOrder = "";
  $requestFingerprint = "";

  // sets values for parameters
  $language = "en";
  $amount = $_SESSION["amount"];
  $currency = $_SESSION["currency"];
  $paymentType = isset($_POST['paymentType']) ? $_POST['paymentType'] : '';
  $orderDescription = "Jane Doe (33562), Order: 5343643-034";
  $successURL = $server_URL . "return_success.html";
  $cancelURL = $server_URL . "return_cancel.html";
  $failureURL = $server_URL . "return_failure.html";
  $serviceURL = $server_URL . "service.html";
  $pendingURL = $server_URL . "return_pending.html";
  $confirmURL = $server_URL . "confirm.php";
  $consumerUserAgent = $_SERVER['HTTP_USER_AGENT'];
  $consumerIpAddress = $_SERVER['REMOTE_ADDR'];
  $storageId = $_SESSION[$STORAGE_ID];
  $orderIdent = $_SESSION["orderIdent"];
  $windowName = $CHECKOUT_WINDOW_NAME;

  // sets values for custom parameters
  $customField1 = "your custom value 1";
  $customField2 = "your custom value 2";

  //--------------------------------------------------------------------------------//
  // Computes the fingerprint and the fingerprint order.
  //--------------------------------------------------------------------------------//

  $requestFingerprintSeed  = "";
  $requestFingerprintOrder .= "secret,";
  $requestFingerprintSeed  .= $secret;
  $requestFingerprintOrder .= "customerId,";
  $requestFingerprintSeed  .= $customerId;
  $requestFingerprintOrder .= "shopId,";
  $requestFingerprintSeed  .= $shopId;
  $requestFingerprintOrder .= "language,";
  $requestFingerprintSeed  .= $language;
  $requestFingerprintOrder .= "amount,";
  $requestFingerprintSeed  .= $amount;
  $requestFingerprintOrder .= "currency,";
  $requestFingerprintSeed  .= $currency;
  $requestFingerprintOrder .= "orderDescription,";
  $requestFingerprintSeed  .= $orderDescription;
  $requestFingerprintOrder .= "successUrl,";
  $requestFingerprintSeed  .= $successURL;
  $requestFingerprintOrder .= "pendingUrl,";
  $requestFingerprintSeed  .= $pendingURL;
  $requestFingerprintOrder .= "confirmUrl,";
  $requestFingerprintSeed  .= $confirmURL;
  $requestFingerprintOrder .= "consumerUserAgent,";
  $requestFingerprintSeed  .= $consumerUserAgent;
  $requestFingerprintOrder .= "consumerIpAddress,";
  $requestFingerprintSeed  .= $consumerIpAddress;
  $requestFingerprintOrder .= "storageId,";
  $requestFingerprintSeed  .= $storageId;
  $requestFingerprintOrder .= "orderIdent,";
  $requestFingerprintSeed  .= $orderIdent;

  // adds custom parameter values to fingerprint
  $requestFingerprintOrder .= "customField1,";
  $requestFingerprintSeed  .= $customField1;

  // adds fingerprint order to fingerprint
  $requestFingerprintOrder .= "requestFingerprintOrder";
  $requestFingerprintSeed  .= $requestFingerprintOrder;

  // computes the request fingerprint
  $requestFingerprint = hash("sha512", $requestFingerprintSeed);

  //--------------------------------------------------------------------------------//
  // Creates and sends a POST request (server-to-server request) to the
  // Wirecard Checkout Seamless for initiating the checkout.
  //--------------------------------------------------------------------------------//

  // initiates the string containing all POST parameters and
  // adds them as key-value pairs to the post fields
  $postFields = "";

  $postFields .= "customerId=" . $customerId;
  $postFields .= "&secret=" . $secret;
  $postFields .= "&shopId=" . $shopId;
  $postFields .= "&amount=" . $amount;
  $postFields .= "&currency=" . $currency;
  $postFields .= "&paymentType=" . $paymentType;
  $postFields .= "&language=" . $language;
  $postFields .= "&orderDescription=" . $orderDescription;
  $postFields .= "&successUrl=" . $successURL;
  $postFields .= "&cancelUrl=" . $cancelURL;
  $postFields .= "&failureUrl=" . $failureURL;
  $postFields .= "&serviceUrl=" . $serviceURL;
  $postFields .= "&pendingUrl=" . $pendingURL;
  $postFields .= "&confirmUrl=" . $confirmURL;
  $postFields .= "&requestFingerprintOrder=" . $requestFingerprintOrder;
  $postFields .= "&requestFingerprint=" . $requestFingerprint;
  $postFields .= "&consumerUserAgent=" . $consumerUserAgent;
  $postFields .= "&consumerIpAddress=" . $consumerIpAddress;
  $postFields .= "&storageId=" . $storageId;
  $postFields .= "&orderIdent=" . $orderIdent;
  $postFields .= "&windowName=" . $windowName;
  $postFields .= "&customField1=" . $customField1;
  $postFields .= "&customField2=" . $customField2;

  // initializes the libcurl of PHP used for sending a POST request
  // to the Wirecard data storage as a server-to-server request
  // (please be aware that you have to use a web server where a
  // server-to-server request is enabled)
  $curl = curl_init();

	// sets the required options for the POST request via curl
	curl_setopt($curl, CURLOPT_URL, $URL_FRONTEND_INIT);
  curl_setopt($curl, CURLOPT_PORT, 443);
  curl_setopt($curl, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $postFields);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

	// sends a POST request to the Wirecard Checkout Platform and stores the
	// result returned from the Wirecard data storage in a string for later use
	$curlResult = curl_exec($curl);

	// closes the connection to the Wirecard Checkout Platform
	curl_close($curl);

  //--------------------------------------------------------------------------------//
  // Retrieves the value for the redirect URL.
  //--------------------------------------------------------------------------------//

  $redirectURL = "";
  foreach (explode('&', $curlResult) as $keyvalue) {
    $param = explode('=', $keyvalue);
    if (sizeof($param) == 2) {
      $key = urldecode($param[0]);
      if ($key == "redirectUrl") {
        $redirectURL = urldecode($param[1]);
        break;
      }
    }
  }

  //--------------------------------------------------------------------------------//
  // Redirects consumer to payment page.
  //--------------------------------------------------------------------------------//

  if ($redirectURL == "") {
    echo "<pre>";
    echo "Frontend Intitiation failed with errors:\n\n";
    foreach (explode('&', $curlResult) as $keyvalue) {
      $param = explode('=', $keyvalue);
      if (sizeof($param) == 2) {
        $key = urldecode($param[0]);
        $value = urldecode($param[1]);
        echo $key . " = " . $value . "\n";
      }
    }
    echo "</pre>";
  } else {
    header("Location: " . $redirectURL);
  }

?>
