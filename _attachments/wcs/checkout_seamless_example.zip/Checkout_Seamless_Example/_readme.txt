//--------------------------------------------------------------------------------//
//                                                                                //
// Wirecard Checkout Seamless Example                                             //
//                                                                                //
// Copyright (c) 2013                                                             //
// Wirecard Central Eastern Europe GmbH                                           //
// www.wirecard.at                                                                //
//                                                                                //
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
// PARTICULAR PURPOSE.                                                            //
//                                                                                //
//--------------------------------------------------------------------------------//
// THIS EXAMPLE IS FOR DEMONSTRATION PURPOSES ONLY!                               //
//--------------------------------------------------------------------------------//
// Please read the integration documentation before modifying this file.          //
//--------------------------------------------------------------------------------//



INSTALLING AND RUNNING THE EXAMPLE
==================================

This example shows you the usage of the Wirecard Checkout Seamless.

You can test this example in a "demo mode" by copying all files of this folder
to your Webserver via ftp and then access them via your Webbrowser.


Steps to get this example running on your Webserver for testing purposes
------------------------------------------------------------------------

 1) ensure that you have access via ftp or any other tool to upload the files
    to your Webserver
 2) ensure that an up-to-date version PHP is enabled on your Webserver
 3) copy this folder or at least all files in this folder to a proper folder
    on your Webserver
 4) navigate with your favourite Webbrowser to that folder on your Webserver
    and open the file "index.php" if it is not loaded automatically by your
    Webbrowser      



SECURITY RECOMMENDATION
=======================

For production mode we strongly recommend that you only use
https in your Webshop and update all components of your Webserver regulary
whenever security updates are published from your vendors.



WHERE TO GET HELP AND ADDITIONAL INFORMATION?
=============================================

If you have any questions or troubles to get this example up and running
in your Webserver environment, please do not hesitate to contact
our Support Team: support@wirecard.at
