//--------------------------------------------------------------------------------//
//                                                                                //
// Wirecard Central Eastern Europe GmbH                                           //
// www.wirecard.at                                                                //
//                                                                                //
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY         //
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE            //
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A                     //
// PARTICULAR PURPOSE.                                                            //
//                                                                                //
//--------------------------------------------------------------------------------//

This folder contains a simple and standalone example of using the 
Wirecard Checkout Page.

Please be aware that the files confirm.php and logo.png have to be accessible
by the Wirecard Checkout Platform, otherwise you will get some errors.
To fulfill this requirement you typically have to upload this example on a
web server via ftp, because normally your local computer (localhost) is
not accessible via the Internet (even if you run a web server locally).

If you need further information please have a look at our Online Guides via
https://integration.wirecard.at/
where you can find a lot of information regarding our products and how to
integrate them to your systems.



INSTALLING AND RUNNING THE EXAMPLE
==================================

This example shows you a quick and easy integration possibility of the
Wirecard Checkout Page for your web shop.

You can test this example in a "demo mode" by copying all files of this folder
to your Webserver via ftp and then access them via your web browser.

Steps to get this example running on your Webserver for testing purposes
------------------------------------------------------------------------

 1) ensure that you have access via ftp or any other tool to upload the files
    to your web server
 2) ensure that an up-to-date version PHP is enabled on your web server
 3) copy this folder or at least all files in this folder to a proper folder
    on your web server
 4) navigate with your favorite web browser to that folder on your web server
    and open the file "index.php" if it is not loaded automatically by your
    web browser
 5) optionally you can replace in the file "config.inc.php" the "customerId" 
    and the "secret" with your specific values given by Wirecard to switch
    from "demo mode" to "production mode"



SECURITY RECOMMENDATION
=======================

For production mode we strongly recommend that you only use
https in your web shop and update all components of your web server regulary
whenever security updates are published from your vendors.

Please ensure also that the file config.inc.php cannot be accessed from any
web browsers via your web server!



WHERE TO GET HELP AND ADDITIONAL INFORMATION?
=============================================

If you have any questions or troubles to get this example up and running
in your Webserver environment, please do not hesitate to contact
our Support Team: support@wirecard.at
